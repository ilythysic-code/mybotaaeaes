# Discord Currency Bot (yapcord dealer)

## Overview

yapcord dealer is a feature-rich Discord bot that creates an interactive economy system for Discord servers. The bot enables server engagement through a comprehensive currency system where users earn money by chatting, participating in games, and completing various activities. It includes a customizable shop system, lootboxes, gambling features, social interactions, and a unique "Dismegle" random chat matching system (Omegle-style chat on Discord).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Architecture Pattern

The application follows a **modular service-oriented architecture** with clear separation of concerns:

- **Entry Point (`index.ts`)**: Initializes the Discord client, manages bot lifecycle, and coordinates between services
- **Data Layer (`dataManager.ts`)**: Handles all data persistence operations with JSON file storage and automatic save intervals
- **Command Layer (`commands.ts`)**: Processes user commands and implements business logic for all bot features
- **Database Migration (`migrate-to-db.ts`)**: Facilitates transition from JSON storage to PostgreSQL
- **Type Safety (`types.ts`)**: Provides comprehensive TypeScript interfaces for all data structures

### Data Storage Strategy

The application uses a **dual-storage approach**:

1. **Primary Storage (Current)**: JSON file-based persistence (`data/data.json`)
   - Simple, file-based storage for rapid prototyping
   - Auto-save mechanism every 15 seconds
   - Final save on bot shutdown
   - Suitable for single-instance deployment on Replit

2. **Future Storage (Configured)**: PostgreSQL with Drizzle ORM
   - Schema defined in `shared/schema.ts`
   - Migration script available for transitioning from JSON
   - Enables scalability and concurrent access
   - Better suited for production environments

**Rationale**: The JSON approach provides simplicity for development while the PostgreSQL infrastructure is prepared for scaling. The migration path is well-defined.

### Economy System Design

The bot implements a **multi-faceted economy** with several earning mechanisms:

1. **Message-Based Earnings**: Users earn 100 currency per message (multiplied by active boost)
2. **Passive Income**: All users earn 1 currency/second automatically
3. **AFK Mode**: Enhanced passive earning at 5 currency/second when activated
4. **Boost System**: Single active boost per user (higher boosts replace lower ones)
5. **Time-Based Rewards**: Daily, hourly, weekly claims with streak bonuses

**Design Decision**: Multiple earning paths keep users engaged without requiring constant activity, while boosts create monetization opportunities.

### Shop and Inventory Architecture

The shop system uses a **flexible item categorization**:

- **Default Items**: Predefined boosts and utilities
- **Custom Shop Items**: Server-specific items created by administrators
- **Role Shop Items**: Items that grant Discord roles
- **Rotating Shop**: Time-limited items with stock management
- **One-Time Purchase Control**: Server owners can toggle multi-purchase per item

**Inventory System**: Simple string array with fuzzy matching for item names, enabling user-friendly commands like `?use 2x boost`.

### Game and Activity Features

The bot includes multiple engagement systems:

- **Gambling**: Coinflip, scratch cards, slot machines (can be toggled by server owners)
- **Competitive**: Arena duels, RPS challenges, trivia showdown
- **Progression**: Battle pass, achievement system, daily quests
- **Social**: Trading system, Dismegle chat matching with interest-based pairing
- **Utilities**: Mining, treasure hunts, heists

**Architecture**: Each feature is self-contained within the command handler with shared state managed through the data manager.

### Dismegle Chat System

The **Dismegle system** implements random chat matching with:

- Queue-based matching with interest filtering
- Blocked user management
- Session persistence with chat panels
- Activity tracking (chats completed, total chat time)
- Text and video chat options

**Design Choice**: Separate session management from main user data allows for clean state handling and easy session cleanup.

### Permission and Moderation System

Three-tier permission model:

1. **Server Owner**: Full administrative access
2. **Managers**: Delegated administrative command access (assigned by owner)
3. **Regular Users**: Standard command access

**Moderation Features**: User banning, inventory clearing, server reset, gambling toggle, trade locking.

### Technical Stack Decisions

- **Discord.js v14**: Latest stable version with modern Discord API features and improved performance
- **TypeScript**: Type safety prevents runtime errors and improves developer experience
- **Node.js**: Asynchronous runtime ideal for bot operations
- **Drizzle ORM**: Type-safe SQL query builder with excellent TypeScript integration
- **pg (node-postgres)**: Mature PostgreSQL driver for Node.js

**Alternative Considered**: Sequelize was considered but Drizzle provides better TypeScript integration and lighter weight.

### User Experience Design

The bot prioritizes engaging UX through:

- **Visual Appeal**: Extensive emoji usage in embeds and responses
- **Interactivity**: Pagination for shops/lootboxes, button-based interactions
- **Feedback**: Milestone notifications every 100 messages with stats
- **Accessibility**: Fuzzy matching for commands reduces friction

## External Dependencies

### Third-Party Services

1. **Discord API** (via discord.js)
   - Purpose: All bot interactions, message handling, embed rendering
   - Integration: Gateway intents for guilds, messages, and members

2. **PostgreSQL Database**
   - Purpose: Scalable data persistence (configured, not yet primary)
   - Connection: Environment variable `DATABASE_URL`
   - ORM: Drizzle for type-safe queries

3. **Axios**
   - Purpose: HTTP requests (likely for trivia questions or external APIs)
   - Used for: Potential external content fetching

### Environment Variables Required

- `DISCORD_BOT_TOKEN`: Discord bot authentication token
- `DATABASE_URL`: PostgreSQL connection string (for future migration)

### Node.js Packages

- **discord.js**: Discord API wrapper and bot framework
- **drizzle-orm** + **drizzle-kit**: Database ORM and migration tools
- **pg**: PostgreSQL client
- **typescript**: Development language
- **axios**: HTTP client