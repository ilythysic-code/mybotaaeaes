# yapcord dealer

## Overview
yapcord dealer is a Discord bot designed to enhance server engagement through a rich, interactive economy. It features a comprehensive currency system where users earn by chatting, a customizable shop, dynamic lootboxes, and a robust moderation suite. The bot aims to provide a fun, competitive, and manageable in-server economy, offering features from simple currency earning to PvP duels and a Battle Pass, all while giving server owners extensive control over customization and management.

**Data Storage Update (November 22, 2025)**: Migrated from JSON-only storage to PostgreSQL with automatic background sync. All user progress is now persisted to PostgreSQL database and survives republishes.

## User Preferences
I prefer iterative development, where we discuss and refine features in stages. Please ask clarifying questions and provide detailed explanations for complex design choices. I value clean, readable code and robust error handling. Do not make changes to files outside the `src/` directory unless absolutely necessary for bot functionality (e.g., `package.json`). For any significant architectural changes or new feature implementations, please propose the approach before implementing it.

## System Architecture

### UI/UX Decisions
The bot prioritizes an engaging user experience through:
- **Vibrant Emojis**: Extensive use of emojis throughout embeds for a lively and engaging feel.
- **Improved Embed Readability**: Clean formatting, icons, and helpful tips within all bot responses.
- **Interactive Shop/Lootbox Menus**: Shop and lootbox displays utilize interactive pagination for easy navigation.
- **Milestone Notifications**: Users receive pings every 100 messages with their balance, earnings, and boost stats.

### Technical Implementations
- **Currency System**: Users earn currency per message (100 base, multiplied by boosts). All users automatically earn 1 currency/second passive income (2/s with passive income upgrade). AFK mode allows earning 3 currency/second with 3-day maximum.
- **Passive Earnings**: All users automatically earn 1💰 per second (2💰/s with upgrade), always active in the background.
- **Token Shop**: All 5 tokens (mute, nickname, slowmode, voice mute, role color) restock together every hour, giving users access to all moderation tokens consistently.
- **Boost System**: Only one boost can be active per user; higher boosts replace lower ones. Server owners can edit boost prices using `?setprice <boost name> <price>`.
- **One-Time Purchase System**: Shop items are one-time purchases by default, with server owner control to enable multi-purchase for specific items.
- **Inventory System**: Tracks user-owned items, with `?use` functionality for consumption.
- **Lootbox System**: Server-administrators create custom lootboxes with configurable item drop rates. Lootboxes are purchased into inventory and then opened.
- **Manager Delegation**: Server owners can assign managers with administrative command access.
- **Fuzzy Matching**: Commands for items, lootboxes, and users utilize smart fuzzy matching for ease of use (e.g., `?buy 2x boost`).
- **User Blocking**: Users can block others with `?flag @user` to prevent being matched together in Dismegle.
- **Data Persistence** (Nov 22, 2025): All user and server data is synchronized to PostgreSQL database on every save. JSON file maintained for local backups. Database ensures data survival across republishes.

### Feature Specifications
- **Core Economy**: Currency, shop, inventory, boosts.
- **Gambling/Games**: 49+ unique minigames (see Games section below).
- **Progression**: Achievement System, Daily Quests, Battle Pass.
- **Social/Utility**: Trading System, VIP Membership, `?afk` mode, `?give`, `?stats`, `?leaderboard`.
- **Moderation**: User banning/unbanning, inventory clearing, server reset, toggling gambling.

## 🎮 MINIGAMES (49 TOTAL)

**All minigames use `addCurrencyRaw()` to prevent boost exploitation while maintaining fair gameplay.**

### Classic Games (6):
- `?coinflip <amt> <h/t>` - Flip a coin for 2x multiplier
- `?scratch` - Scratch cards with random outcomes
- `?slots <amt>` - 3-reel weighted slot machine
- `?blackjack <amt>` - Dealer vs player card game
- `?lottery <amt>` - Ticket-based instant draw
- `?trivia <amt>` - Answer trivia questions (5min CD)

### Extended Minigames (20):
- `?dice <amt> <high/low>` - Dice roll prediction
- `?guess <amt>` - Number guessing (1-100)
- `?cards <amt> <higher/lower>` - Card comparison game
- `?wheel <amt>` - Lucky spin wheel
- `?predict <amt> <1-100>` - Exact number prediction
- `?horserace <amt> <1-4>` - Pick your horse number
- `?envelope <amt>` - Lucky envelope opening
- `?doubletrouble <amt>` - Double or lose everything
- `?jackpot <amt>` - Jackpot machine (up to 100x)
- `?kingofhill <amt>` - Win 2/3 rounds
- `?goldfish <amt> <1-5>` - Guess the goldfish number
- `?minesweeper <amt>` - Avoid the mines
- `?bombsquad <amt>` - Defuse bombs
- `?lotteryticket <amt>` - Lottery ticket (up to 500x)
- `?roulette <amt> <0-36>` - 37-number roulette
- `?quickpick <amt>` - Match 2 numbers
- `?coinpile <amt> <guess>` - Guess coin pile (±2 tolerance)
- `?daredevil <amt> <difficulty>` - Risk/reward challenge
- `?fortune <amt>` - Fortune wheel (up to 7x)
- `?hilo <amt> <high/low>` - Hi-Lo card game

### NEW Minigames (29):
- `?luckynums <amt> <1-10>` - Match lucky number (8x)
- `?dicetower <amt> <guess>` - Build tower (2.5x)
- `?cardshuffle <amt> <1-52>` - Find the card (3x)
- `?gemrush <amt>` - Collect gems (up to 5.6x)
- `?luckydraw <amt>` - Lucky draw (up to 15x)
- `?coinmult <amt>` - Multiply coins (up to 6x)
- `?mystery <amt>` - Mystery box (up to 5x)
- `?ladder <amt>` - Climb the ladder (up to 2x)
- `?cardcombo <amt>` - Match card combo (3x)
- `?gemhunt <amt> <1-10>` - Hunt for gems (7.5x)
- `?explosive <amt>` - Survive explosions (2.2x)
- `?rainbow <amt>` - Rainbow color match (2.8x)
- `?cosmic <amt>` - Cosmic spin (up to 12x)
- `?stars <amt>` - Lucky stars (up to 5x)
- `?crystal <amt>` - Crystal quest (up to 3.2x)
- `?magicflip <amt>` - Magic flip coins (2.5x)
- `?thunder <amt>` - Thunder roll (up to 4x)
- `?phoenix <amt>` - Phoenix fire (up to 10x)
- `?dragon <amt>` - Dragon's gold (up to 5x)
- `?shadow <amt>` - Shadow luck (up to 6x)
- `?void <amt>` - Void echo (4x)
- `?runes <amt>` - Ancient runes (5x)
- `?quantum <amt>` - Quantum leap (2.2x)
- `?nebula <amt>` - Nebula hunt (3.5x)
- `?infinity <amt>` - Infinity loop (up to 7x)
- `?eclipse <amt>` - Eclipse gamble (up to 8x)
- `?frostbite <amt>` - Frostbite survival (2.5x)
- `?inferno <amt>` - Inferno blaze (up to 2.8x)
- `?tiger <amt>` - Tiger's pounce (6x)

### PvP Challenges (3):
- `?duel @user <wager>` - Battle another player
- `?faceoff @user <wager>` - Quick draw showdown
- `?rps @user <wager>` - Rock-Paper-Scissors duel

**All games:**
- Default bets range from 1,000-5,000 currency
- Multipliers range from 1.5x-500x based on difficulty
- NO boost multipliers applied (prevents exploitation)
- Balance checked before gameplay
- Instant results with embed feedback

### System Design Choices
- **Node.js with TypeScript**: Provides type safety and modern JavaScript features.
- **Discord.js v14**: Chosen for robust Discord API interaction.
- **JSON File Storage**: Simple and effective for data persistence in a Replit environment.

## External Dependencies
- **Discord API**: Utilized via `discord.js` for all bot interactions and functionalities.
- **Node.js**: The runtime environment for the bot.
- **TypeScript**: The primary language for development.

## 🎲 DISMEGLE SYSTEM - Random Chat Matching

**Omegle-style random chat experience on Discord!**

### Features:
- **4 Chat Modes**: 1-on-1 text, group text (4 users), 1-on-1 voice, group voice (4 users)
- **Private Channels**: Auto-created private text and voice channels with proper permissions
- **Smart Queue System**: Automatic matching algorithm pairs users in real-time
- **Currency Rewards**: Earn based on chat duration (100 base + 50 per minute)
- **Session Tracking**: Tracks chats completed and total chat time per user
- **Server Toggle**: Owners can enable/disable with `?dismegle on/off`

### Commands:
- `?panel` - Create interactive Dismegle panel with buttons (Manager/Owner only)
- `?tag add [tags]` or `?interests add [tags]` - Add interests for better matching (e.g., cooking, anime, gaming)
- `?tag remove [tag]` or `?interests remove [tag]` - Remove an interest
- `?tag clear` or `?interests clear` - Clear all interests
- `?flag @user` - Block a user from matching with you (toggle on/off)
- `?flag list` - View your blocked users
- `?flag clear` - Unblock all users
- `?save` - Export chat logs to your DMs
- `?findchat` - Queue for 1-on-1 text chat (or use panel buttons)
- `?findgroup` - Queue for group text chat (requires 4 users)
- `?findvoice` - Queue for 1-on-1 voice chat (or use panel buttons)
- `?findgroupvoice` - Queue for group voice chat (requires 4 users)
- `?leave` or `?end` - Exit current chat session and earn rewards
- `?help dismegle` - View comprehensive Dismegle guide

### System Toggles (Owner Only):
- `?currencysystem on/off` - Toggle currency earning from messages
- `?dismegle on/off` - Toggle all Dismegle random chat features

### How It Works:
1. Server owner/manager creates panel with `?panel` command
2. Users click buttons on the panel to join queues (or use `?findchat`/`?findvoice` commands)
3. Users add interests with `?interests add cooking, anime, gaming, etc.`
4. Bot matches users based on shared interests (smart matching algorithm)
5. Creates private thread in panel channel named after matched users (e.g., "Alice & Bob")
6. For voice chats, also creates voice channel in "Dismegle Voice" category
7. Users chat in thread, all messages are logged
8. Use `?save` to export chat logs to DMs
9. Use `?leave` to end session and earn currency rewards
10. Threads are archived and locked 10 seconds after session ends

## 🎨 STICKER CREATOR

**Transform GIFs and images into animated Discord stickers!**

### Features:
- **Automatic Conversion**: Downloads and converts images to Discord-compatible animated GIF format
- **Smart Resizing**: Automatically resizes to 320x320 pixels while maintaining aspect ratio
- **Auto Compression**: Intelligently reduces FPS to meet Discord's 512KB size limit
- **Tenor/Giphy Support**: Works with direct links and popular GIF platforms
- **Custom Names**: Name your stickers anything you want (up to 30 characters)
- **Permission Check**: Requires "Manage Expressions" permission
- **Animated Support**: Preserves animation in GIFs for animated stickers!

### Usage:
```
?sticker <url> <name>
```

### Examples:
```
?sticker https://tenor.com/view/cat-dancing-gif funny_cat
?sticker https://i.imgur.com/example.gif cool_sticker
?sticker https://media.giphy.com/media/example/giphy.gif awesome
```

### Requirements:
- User must have "Manage Expressions" permission
- Valid URL to a GIF, PNG, JPG, JPEG, or WEBP file
- Supported platforms: Tenor, Giphy, or direct image links

## 🎫 ROTATING TOKEN SHOP SYSTEM

**Hourly rotating shop for special tokens with temporary effects!**

### Features:
- **Rotating Stock**: Shop restocks every hour with 1-2 random tokens for variety
- **Owner Configuration**: Server owners control pricing and durations
- **Two Token Types**: Mute Token (timeout users) and Nickname Token (change nicknames)
- **Temporary Effects**: All effects auto-revert after the configured duration
- **Persistent Timers**: Nickname changes persist across bot restarts
- **Permission-Based**: Bot needs proper permissions to timeout/change nicknames
- **Bonus Chance**: 22% chance for mute duration to double (5s → 10s)

### Token Types:
1. **🔇 Mute Token** - Timeout a user for a configurable duration (22% chance for bonus 10s)
2. **📝 Nickname Token** - Change a user's nickname temporarily (auto-reverts)
3. **⏱️ Slowmode Token** - Set maximum slowmode (6 hours) on a text channel temporarily
4. **🎤 Voice Mute Token** - Server-mute a user in voice channels temporarily
5. **🎨 Role Color Token** - Create a custom colored role for yourself temporarily

### Owner Commands:
- `?tokenconfig` - View current shop configuration and restock timer
- `?tokenconfig on/off` - Enable/disable the token shop
- `?tokenconfig mute price <amount>` - Set mute token price
- `?tokenconfig mute duration <time>` - Set mute token duration (e.g., `5s` or `1m`)
- `?tokenconfig nickname price <amount>` - Set nickname token price  
- `?tokenconfig nickname duration <time>` - Set nickname token duration (e.g., `1m` or `10m`)

### User Commands:
- `?tokenshop` - View dedicated token shop with available tokens and restock timer
- `?buy <token name>` - Purchase tokens from shop (if available)
- `?use token mute @user` - Use mute token to timeout a user
- `?use token changename @user <new name>` - Use nickname token to change someone's nickname
- `?use token slowmode #channel` - Use slowmode token to set max slowmode on a channel
- `?use token voicemute @user` - Use voice mute token to server-mute someone in voice
- `?use token rolecolor <#hex>` - Use role color token to create a custom colored role (e.g., #FF5733)
- `?inventory` - View your owned tokens
- `?shop` - View all items including current rotating tokens

### How It Works:
1. Shop is enabled by default (owner can disable with `?tokenconfig off`)
2. Owner sets prices and durations (default: both 20k💰, mute 5s, nickname 1m)
3. Shop automatically restocks every hour with 1-2 random tokens
4. Users buy tokens when available (stock varies each hour)
5. Tokens are stored in inventory after purchase
6. Users activate tokens with `?use token` commands
7. Effects automatically revert after the duration expires
8. Nickname effects persist even if bot restarts

### Default Configuration:
- Mute Token: 20,000 currency, 5 seconds duration (22% chance for 10s)
- Nickname Token: 20,000 currency, 1 minute duration
- Restock: Every hour with 1-2 random tokens
- Status: **ENABLED by default** (owner can disable with `?tokenconfig off`)

## Recent Updates
- **Nov 18, 2025**: **🎫 3 NEW TOKENS ADDED!** - Slowmode Token (max slowmode on channels), Voice Mute Token (server-mute in voice), and Role Color Token (custom colored roles)
- **Nov 18, 2025**: **📚 HELP COMMAND UPDATED!** - Fixed AFK rate display (1/sec, not 5/sec), added passive income info, documented all 5 token types, and clarified that `?setprice` works for boosts
- **Nov 18, 2025**: **🗑️ INVESTMENT REMOVAL!** - Completely removed the investment feature from the bot (no longer available)
- **Nov 18, 2025**: **💸 PASSIVE EARNINGS!** - All users now earn 1💰 per second automatically (2💰/s with passive income upgrade, always active, no command needed)
- **Nov 18, 2025**: **🎫 ROTATING TOKEN SHOP!** - Added `?tokenshop` command and hourly rotating shop with 1-2 random tokens (Mute & Nickname), owner-configurable prices/durations, 22% bonus chance for mute, ENABLED by default
- **Nov 18, 2025**: **🎮 PVP GAME MODE UPDATES!**
  - ✊ IMPROVED: `?rps` now uses button-based choice selection with 5s reveal delay (30s timeout, auto-refund)
  - 🔫 IMPROVED: `?faceoff` reaction timeout reduced from 5s to 2s for faster gameplay
- **Nov 17, 2025**: **🎮 NEW PVP GAME MODES!**
  - 🔫 NEW: `?faceoff @user (amount)` - Quick draw reaction duel (3-20s delay, 25% bomb trap chance)
  - ✊ NEW: `?rps @user (amount)` - Rock Paper Scissors duel with private button choices
- **Nov 17, 2025**: **🚀 MASSIVE MONEY SYSTEM UPDATE!**
  - ❌ Threads no longer earn currency (anti-farm protection)
  - ⏰ NEW: `?hourly` - Hourly rewards with boost multipliers
  - ⛏️ NEW: `?mine` - Passive income mining system with upgrades
  - 🔥 NEW: `?streak` - Daily activity streaks with multipliers
  - 💰 NEW: `?heist` - High-risk, high-reward robberies (60% success)
  - 🎰 NEW: `?spin` - Lucky wheel with jackpot prizes
  - ✨ Shop UI completely redesigned with vibrant colors & better UX
- **Nov 17, 2025**: **🚫 USER BLOCKING!** - Added `?flag` command to block users from Dismegle matching (bidirectional blocking)
- **Nov 17, 2025**: **🏷️ TAG ALIAS!** - `?tag` now works as an alias for `?interests` command for easier tagging
- **Nov 17, 2025**: **⏱️ AUTO-SAVE UPDATE!** - Changed auto-save interval from 10 seconds to 15 seconds
- **Nov 17, 2025**: **🎨 STICKER CREATOR!** - Added `?sticker` command to create animated Discord stickers from GIFs with automatic compression and FPS reduction
- **Nov 17, 2025**: **🎛️ INTERACTIVE DISMEGLE PANEL!** - Added `?panel` command (Manager/Owner only) with buttons for easy queue joining
- **Nov 17, 2025**: **🧵 THREAD-BASED SESSIONS!** - Chat sessions now use private threads named after matched users (e.g., "Alice & Bob")
- **Nov 17, 2025**: **🎯 INTEREST MATCHING!** - Added `?interests` command system with smart matching algorithm based on shared interests
- **Nov 17, 2025**: **💾 CHAT LOG EXPORT!** - Added `?save` command to export complete chat history to DMs with timestamps
- **Nov 17, 2025**: **🎲 DISMEGLE SYSTEM ADDED!** - Complete Omegle-style random chat matching with 4 modes, queue system, private channels, and currency rewards
- **Nov 17, 2025**: **⚙️ SYSTEM TOGGLES** - Server owners can now disable currency earning (`?currencysystem off`) and Dismegle features (`?dismegle off`)
- **Nov 17, 2025**: **🎉 10 NEW FEATURES!** - Trivia, Achievements, Duels, Treasure Hunts, Trading, Quests, Battle Pass, Scratch Cards, VIP