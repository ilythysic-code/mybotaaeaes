import { pgTable, varchar, integer, bigint, boolean, text, jsonb, serial, timestamp, real } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  balance: bigint('balance', { mode: 'number' }).notNull().default(0),
  boost: real('boost').notNull().default(1),
  inventory: jsonb('inventory').$type<string[]>().notNull().default([]),
  messageCount: integer('message_count').notNull().default(0),
  afkStartTime: bigint('afk_start_time', { mode: 'number' }),
  purchasedItems: jsonb('purchased_items').$type<string[]>().notNull().default([]),
  lastDaily: bigint('last_daily', { mode: 'number' }),
  lastWork: bigint('last_work', { mode: 'number' }),
  lastWeekly: bigint('last_weekly', { mode: 'number' }),
  dailyStreak: integer('daily_streak').default(0),
  lastStreakClaim: bigint('last_streak_claim', { mode: 'number' }),
  lastTrivia: bigint('last_trivia', { mode: 'number' }),
  triviaStreak: integer('trivia_streak').default(0),
  achievements: jsonb('achievements').$type<string[]>().default([]),
  title: varchar('title', { length: 255 }),
  battlePassXP: integer('battle_pass_xp').default(0),
  battlePassLevel: integer('battle_pass_level').default(0),
  lastQuest: bigint('last_quest', { mode: 'number' }),
  completedQuests: integer('completed_quests').default(0),
  vipTier: integer('vip_tier').default(0),
  vipExpiry: bigint('vip_expiry', { mode: 'number' }),
  tradeLocked: boolean('trade_locked').default(false),
  scratchCardsWon: integer('scratch_cards_won').default(0),
  duelsWon: integer('duels_won').default(0),
  duelsLost: integer('duels_lost').default(0),
  treasureHuntsCompleted: integer('treasure_hunts_completed').default(0),
  activeChatSession: varchar('active_chat_session', { length: 255 }),
  chatsCompleted: integer('chats_completed').default(0),
  totalChatTime: integer('total_chat_time').default(0),
  interests: jsonb('interests').$type<string[]>().default([]),
  blockedUsers: jsonb('blocked_users').$type<string[]>().default([]),
  lastHourly: bigint('last_hourly', { mode: 'number' }),
  miningLevel: integer('mining_level').default(1),
  lastMine: bigint('last_mine', { mode: 'number' }),
  activityStreak: integer('activity_streak').default(1),
  lastActivity: bigint('last_activity', { mode: 'number' }),
  lastHeist: bigint('last_heist', { mode: 'number' }),
  lastSpin: bigint('last_spin', { mode: 'number' }),
});

export const lootboxes = pgTable('lootboxes', {
  id: varchar('id', { length: 255 }).primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  price: bigint('price', { mode: 'number' }).notNull(),
});

export const lootboxItems = pgTable('lootbox_items', {
  id: serial('id').primaryKey(),
  lootboxId: varchar('lootbox_id', { length: 255 }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  chance: integer('chance').notNull(),
});

export const customShopItems = pgTable('custom_shop_items', {
  id: varchar('id', { length: 255 }).primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  price: bigint('price', { mode: 'number' }).notNull(),
  emoji: varchar('emoji', { length: 50 }).notNull(),
  multiPurchase: boolean('multi_purchase').notNull().default(false),
});

export const roleShopItems = pgTable('role_shop_items', {
  id: varchar('id', { length: 255 }).primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  roleId: varchar('role_id', { length: 255 }).notNull(),
  roleName: varchar('role_name', { length: 255 }).notNull(),
  price: bigint('price', { mode: 'number' }).notNull(),
});

export const rotatingShopConfigs = pgTable('rotating_shop_configs', {
  guildId: varchar('guild_id', { length: 255 }).primaryKey(),
  enabled: boolean('enabled').notNull().default(true),
  muteTokenPrice: bigint('mute_token_price', { mode: 'number' }).notNull().default(20000),
  muteTokenDuration: bigint('mute_token_duration', { mode: 'number' }).notNull().default(5000),
  nicknameTokenPrice: bigint('nickname_token_price', { mode: 'number' }).notNull().default(20000),
  nicknameTokenDuration: bigint('nickname_token_duration', { mode: 'number' }).notNull().default(60000),
  currentTokens: jsonb('current_tokens').$type<string[]>().notNull().default([]),
  lastRestock: bigint('last_restock', { mode: 'number' }).notNull().default(0),
});

export const managers = pgTable('managers', {
  id: serial('id').primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  userId: varchar('user_id', { length: 255 }).notNull(),
});

export const bannedUsers = pgTable('banned_users', {
  id: serial('id').primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  userId: varchar('user_id', { length: 255 }).notNull(),
});

export const defaultItemOverrides = pgTable('default_item_overrides', {
  id: serial('id').primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  itemId: varchar('item_id', { length: 255 }).notNull(),
  multiPurchase: boolean('multi_purchase').notNull(),
});

export const serverSettings = pgTable('server_settings', {
  guildId: varchar('guild_id', { length: 255 }).primaryKey(),
  currencySystemEnabled: boolean('currency_system_enabled').notNull().default(true),
  dismegleEnabled: boolean('dismegle_enabled').notNull().default(true),
  coinflipEnabled: boolean('coinflip_enabled').notNull().default(true),
  baseCurrencyPerMessage: integer('base_currency_per_message').notNull().default(100),
  baseEarningsExpiry: bigint('base_earnings_expiry', { mode: 'number' }),
});

export const duelChallenges = pgTable('duel_challenges', {
  id: varchar('id', { length: 255 }).primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  challengerId: varchar('challenger_id', { length: 255 }).notNull(),
  targetId: varchar('target_id', { length: 255 }).notNull(),
  wager: bigint('wager', { mode: 'number' }).notNull(),
  expiresAt: bigint('expires_at', { mode: 'number' }).notNull(),
});

export const faceoffChallenges = pgTable('faceoff_challenges', {
  id: varchar('id', { length: 255 }).primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  challengerId: varchar('challenger_id', { length: 255 }).notNull(),
  targetId: varchar('target_id', { length: 255 }).notNull(),
  wager: bigint('wager', { mode: 'number' }).notNull(),
  expiresAt: bigint('expires_at', { mode: 'number' }).notNull(),
  messageId: varchar('message_id', { length: 255 }),
  startTime: bigint('start_time', { mode: 'number' }),
  isBomb: boolean('is_bomb').default(false),
});

export const rpsChallenges = pgTable('rps_challenges', {
  id: varchar('id', { length: 255 }).primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  challengerId: varchar('challenger_id', { length: 255 }).notNull(),
  targetId: varchar('target_id', { length: 255 }).notNull(),
  wager: bigint('wager', { mode: 'number' }).notNull(),
  expiresAt: bigint('expires_at', { mode: 'number' }).notNull(),
  challengerChoice: varchar('challenger_choice', { length: 20 }),
  targetChoice: varchar('target_choice', { length: 20 }),
});

export const tradeOffers = pgTable('trade_offers', {
  id: varchar('id', { length: 255 }).primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  senderId: varchar('sender_id', { length: 255 }).notNull(),
  receiverId: varchar('receiver_id', { length: 255 }).notNull(),
  senderOffer: jsonb('sender_offer').$type<{ currency: number; items: string[] }>().notNull(),
  receiverOffer: jsonb('receiver_offer').$type<{ currency: number; items: string[] }>().notNull(),
  expiresAt: bigint('expires_at', { mode: 'number' }).notNull(),
  status: varchar('status', { length: 20 }).notNull().default('pending'),
});

export const dailyQuests = pgTable('daily_quests', {
  guildId: varchar('guild_id', { length: 255 }).primaryKey(),
  quests: jsonb('quests').$type<Array<{
    id: string;
    type: string;
    requirement: number;
    reward: number;
    description: string;
  }>>().notNull(),
  lastRefresh: bigint('last_refresh', { mode: 'number' }).notNull(),
});

export const chatSessions = pgTable('chat_sessions', {
  id: varchar('id', { length: 255 }).primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  type: varchar('type', { length: 50 }).notNull(),
  users: jsonb('users').$type<string[]>().notNull(),
  channelId: varchar('channel_id', { length: 255 }).notNull(),
  voiceChannelId: varchar('voice_channel_id', { length: 255 }),
  startTime: bigint('start_time', { mode: 'number' }).notNull(),
  lastActivityTime: bigint('last_activity_time', { mode: 'number' }).notNull(),
  categoryId: varchar('category_id', { length: 255 }),
  messages: jsonb('messages').$type<Array<{ userId: string; username: string; content: string; timestamp: number }>>().default([]),
  isThread: boolean('is_thread').default(false),
  threadId: varchar('thread_id', { length: 255 }),
});

export const matchQueue = pgTable('match_queue', {
  id: serial('id').primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  type: varchar('type', { length: 50 }).notNull(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  queuedAt: bigint('queued_at', { mode: 'number' }).notNull(),
});

export const dismeglePanels = pgTable('dismegle_panels', {
  guildId: varchar('guild_id', { length: 255 }).primaryKey(),
  channelId: varchar('channel_id', { length: 255 }).notNull(),
  messageId: varchar('message_id', { length: 255 }).notNull(),
});

export const activeEffects = pgTable('active_effects', {
  id: varchar('id', { length: 255 }).primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  targetUserId: varchar('target_user_id', { length: 255 }).notNull(),
  type: varchar('type', { length: 20 }).notNull(),
  appliedBy: varchar('applied_by', { length: 255 }).notNull(),
  expiresAt: bigint('expires_at', { mode: 'number' }).notNull(),
  originalNickname: varchar('original_nickname', { length: 255 }),
});

export const roleBoosts = pgTable('role_boosts', {
  id: serial('id').primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  roleId: varchar('role_id', { length: 255 }).notNull(),
  multiplier: real('multiplier').notNull().default(1),
});

export const disabledCommands = pgTable('disabled_commands', {
  id: serial('id').primaryKey(),
  guildId: varchar('guild_id', { length: 255 }).notNull(),
  commandName: varchar('command_name', { length: 100 }).notNull(),
  disabledAt: bigint('disabled_at', { mode: 'number' }).notNull(),
});
