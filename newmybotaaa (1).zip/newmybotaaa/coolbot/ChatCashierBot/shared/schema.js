"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.activeEffects = exports.dismeglePanels = exports.matchQueue = exports.chatSessions = exports.dailyQuests = exports.tradeOffers = exports.rpsChallenges = exports.faceoffChallenges = exports.duelChallenges = exports.serverSettings = exports.defaultItemOverrides = exports.bannedUsers = exports.managers = exports.rotatingShopConfigs = exports.roleShopItems = exports.customShopItems = exports.lootboxItems = exports.lootboxes = exports.investmentBonds = exports.users = void 0;
const pg_core_1 = require("drizzle-orm/pg-core");
exports.users = (0, pg_core_1.pgTable)('users', {
    id: (0, pg_core_1.serial)('id').primaryKey(),
    userId: (0, pg_core_1.varchar)('user_id', { length: 255 }).notNull(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    balance: (0, pg_core_1.bigint)('balance', { mode: 'number' }).notNull().default(0),
    boost: (0, pg_core_1.integer)('boost').notNull().default(1),
    inventory: (0, pg_core_1.jsonb)('inventory').$type().notNull().default([]),
    messageCount: (0, pg_core_1.integer)('message_count').notNull().default(0),
    afkStartTime: (0, pg_core_1.bigint)('afk_start_time', { mode: 'number' }),
    purchasedItems: (0, pg_core_1.jsonb)('purchased_items').$type().notNull().default([]),
    lastDaily: (0, pg_core_1.bigint)('last_daily', { mode: 'number' }),
    lastWork: (0, pg_core_1.bigint)('last_work', { mode: 'number' }),
    lastWeekly: (0, pg_core_1.bigint)('last_weekly', { mode: 'number' }),
    dailyStreak: (0, pg_core_1.integer)('daily_streak').default(0),
    lastStreakClaim: (0, pg_core_1.bigint)('last_streak_claim', { mode: 'number' }),
    lastTrivia: (0, pg_core_1.bigint)('last_trivia', { mode: 'number' }),
    triviaStreak: (0, pg_core_1.integer)('trivia_streak').default(0),
    achievements: (0, pg_core_1.jsonb)('achievements').$type().default([]),
    title: (0, pg_core_1.varchar)('title', { length: 255 }),
    battlePassXP: (0, pg_core_1.integer)('battle_pass_xp').default(0),
    battlePassLevel: (0, pg_core_1.integer)('battle_pass_level').default(0),
    lastQuest: (0, pg_core_1.bigint)('last_quest', { mode: 'number' }),
    completedQuests: (0, pg_core_1.integer)('completed_quests').default(0),
    vipTier: (0, pg_core_1.integer)('vip_tier').default(0),
    vipExpiry: (0, pg_core_1.bigint)('vip_expiry', { mode: 'number' }),
    tradeLocked: (0, pg_core_1.boolean)('trade_locked').default(false),
    scratchCardsWon: (0, pg_core_1.integer)('scratch_cards_won').default(0),
    duelsWon: (0, pg_core_1.integer)('duels_won').default(0),
    duelsLost: (0, pg_core_1.integer)('duels_lost').default(0),
    treasureHuntsCompleted: (0, pg_core_1.integer)('treasure_hunts_completed').default(0),
    activeChatSession: (0, pg_core_1.varchar)('active_chat_session', { length: 255 }),
    chatsCompleted: (0, pg_core_1.integer)('chats_completed').default(0),
    totalChatTime: (0, pg_core_1.integer)('total_chat_time').default(0),
    interests: (0, pg_core_1.jsonb)('interests').$type().default([]),
    blockedUsers: (0, pg_core_1.jsonb)('blocked_users').$type().default([]),
    lastHourly: (0, pg_core_1.bigint)('last_hourly', { mode: 'number' }),
    miningLevel: (0, pg_core_1.integer)('mining_level').default(1),
    lastMine: (0, pg_core_1.bigint)('last_mine', { mode: 'number' }),
    activityStreak: (0, pg_core_1.integer)('activity_streak').default(1),
    lastActivity: (0, pg_core_1.bigint)('last_activity', { mode: 'number' }),
    lastHeist: (0, pg_core_1.bigint)('last_heist', { mode: 'number' }),
    lastSpin: (0, pg_core_1.bigint)('last_spin', { mode: 'number' }),
});
exports.investmentBonds = (0, pg_core_1.pgTable)('investment_bonds', {
    id: (0, pg_core_1.varchar)('id', { length: 255 }).primaryKey(),
    userId: (0, pg_core_1.varchar)('user_id', { length: 255 }).notNull(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    amount: (0, pg_core_1.bigint)('amount', { mode: 'number' }).notNull(),
    startTime: (0, pg_core_1.bigint)('start_time', { mode: 'number' }).notNull(),
    duration: (0, pg_core_1.bigint)('duration', { mode: 'number' }).notNull(),
    returnRate: (0, pg_core_1.integer)('return_rate').notNull(),
});
exports.lootboxes = (0, pg_core_1.pgTable)('lootboxes', {
    id: (0, pg_core_1.varchar)('id', { length: 255 }).primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    name: (0, pg_core_1.varchar)('name', { length: 255 }).notNull(),
    price: (0, pg_core_1.bigint)('price', { mode: 'number' }).notNull(),
});
exports.lootboxItems = (0, pg_core_1.pgTable)('lootbox_items', {
    id: (0, pg_core_1.serial)('id').primaryKey(),
    lootboxId: (0, pg_core_1.varchar)('lootbox_id', { length: 255 }).notNull(),
    name: (0, pg_core_1.varchar)('name', { length: 255 }).notNull(),
    chance: (0, pg_core_1.integer)('chance').notNull(),
});
exports.customShopItems = (0, pg_core_1.pgTable)('custom_shop_items', {
    id: (0, pg_core_1.varchar)('id', { length: 255 }).primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    name: (0, pg_core_1.varchar)('name', { length: 255 }).notNull(),
    price: (0, pg_core_1.bigint)('price', { mode: 'number' }).notNull(),
    emoji: (0, pg_core_1.varchar)('emoji', { length: 50 }).notNull(),
    multiPurchase: (0, pg_core_1.boolean)('multi_purchase').notNull().default(false),
});
exports.roleShopItems = (0, pg_core_1.pgTable)('role_shop_items', {
    id: (0, pg_core_1.varchar)('id', { length: 255 }).primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    roleId: (0, pg_core_1.varchar)('role_id', { length: 255 }).notNull(),
    roleName: (0, pg_core_1.varchar)('role_name', { length: 255 }).notNull(),
    price: (0, pg_core_1.bigint)('price', { mode: 'number' }).notNull(),
});
exports.rotatingShopConfigs = (0, pg_core_1.pgTable)('rotating_shop_configs', {
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).primaryKey(),
    enabled: (0, pg_core_1.boolean)('enabled').notNull().default(true),
    muteTokenPrice: (0, pg_core_1.bigint)('mute_token_price', { mode: 'number' }).notNull().default(20000),
    muteTokenDuration: (0, pg_core_1.bigint)('mute_token_duration', { mode: 'number' }).notNull().default(5000),
    nicknameTokenPrice: (0, pg_core_1.bigint)('nickname_token_price', { mode: 'number' }).notNull().default(20000),
    nicknameTokenDuration: (0, pg_core_1.bigint)('nickname_token_duration', { mode: 'number' }).notNull().default(60000),
    currentTokens: (0, pg_core_1.jsonb)('current_tokens').$type().notNull().default([]),
    lastRestock: (0, pg_core_1.bigint)('last_restock', { mode: 'number' }).notNull().default(0),
});
exports.managers = (0, pg_core_1.pgTable)('managers', {
    id: (0, pg_core_1.serial)('id').primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    userId: (0, pg_core_1.varchar)('user_id', { length: 255 }).notNull(),
});
exports.bannedUsers = (0, pg_core_1.pgTable)('banned_users', {
    id: (0, pg_core_1.serial)('id').primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    userId: (0, pg_core_1.varchar)('user_id', { length: 255 }).notNull(),
});
exports.defaultItemOverrides = (0, pg_core_1.pgTable)('default_item_overrides', {
    id: (0, pg_core_1.serial)('id').primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    itemId: (0, pg_core_1.varchar)('item_id', { length: 255 }).notNull(),
    multiPurchase: (0, pg_core_1.boolean)('multi_purchase').notNull(),
});
exports.serverSettings = (0, pg_core_1.pgTable)('server_settings', {
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).primaryKey(),
    currencySystemEnabled: (0, pg_core_1.boolean)('currency_system_enabled').notNull().default(true),
    dismegleEnabled: (0, pg_core_1.boolean)('dismegle_enabled').notNull().default(true),
    coinflipEnabled: (0, pg_core_1.boolean)('coinflip_enabled').notNull().default(true),
});
exports.duelChallenges = (0, pg_core_1.pgTable)('duel_challenges', {
    id: (0, pg_core_1.varchar)('id', { length: 255 }).primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    challengerId: (0, pg_core_1.varchar)('challenger_id', { length: 255 }).notNull(),
    targetId: (0, pg_core_1.varchar)('target_id', { length: 255 }).notNull(),
    wager: (0, pg_core_1.bigint)('wager', { mode: 'number' }).notNull(),
    expiresAt: (0, pg_core_1.bigint)('expires_at', { mode: 'number' }).notNull(),
});
exports.faceoffChallenges = (0, pg_core_1.pgTable)('faceoff_challenges', {
    id: (0, pg_core_1.varchar)('id', { length: 255 }).primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    challengerId: (0, pg_core_1.varchar)('challenger_id', { length: 255 }).notNull(),
    targetId: (0, pg_core_1.varchar)('target_id', { length: 255 }).notNull(),
    wager: (0, pg_core_1.bigint)('wager', { mode: 'number' }).notNull(),
    expiresAt: (0, pg_core_1.bigint)('expires_at', { mode: 'number' }).notNull(),
    messageId: (0, pg_core_1.varchar)('message_id', { length: 255 }),
    startTime: (0, pg_core_1.bigint)('start_time', { mode: 'number' }),
    isBomb: (0, pg_core_1.boolean)('is_bomb').default(false),
});
exports.rpsChallenges = (0, pg_core_1.pgTable)('rps_challenges', {
    id: (0, pg_core_1.varchar)('id', { length: 255 }).primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    challengerId: (0, pg_core_1.varchar)('challenger_id', { length: 255 }).notNull(),
    targetId: (0, pg_core_1.varchar)('target_id', { length: 255 }).notNull(),
    wager: (0, pg_core_1.bigint)('wager', { mode: 'number' }).notNull(),
    expiresAt: (0, pg_core_1.bigint)('expires_at', { mode: 'number' }).notNull(),
    challengerChoice: (0, pg_core_1.varchar)('challenger_choice', { length: 20 }),
    targetChoice: (0, pg_core_1.varchar)('target_choice', { length: 20 }),
});
exports.tradeOffers = (0, pg_core_1.pgTable)('trade_offers', {
    id: (0, pg_core_1.varchar)('id', { length: 255 }).primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    senderId: (0, pg_core_1.varchar)('sender_id', { length: 255 }).notNull(),
    receiverId: (0, pg_core_1.varchar)('receiver_id', { length: 255 }).notNull(),
    senderOffer: (0, pg_core_1.jsonb)('sender_offer').$type().notNull(),
    receiverOffer: (0, pg_core_1.jsonb)('receiver_offer').$type().notNull(),
    expiresAt: (0, pg_core_1.bigint)('expires_at', { mode: 'number' }).notNull(),
    status: (0, pg_core_1.varchar)('status', { length: 20 }).notNull().default('pending'),
});
exports.dailyQuests = (0, pg_core_1.pgTable)('daily_quests', {
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).primaryKey(),
    quests: (0, pg_core_1.jsonb)('quests').$type().notNull(),
    lastRefresh: (0, pg_core_1.bigint)('last_refresh', { mode: 'number' }).notNull(),
});
exports.chatSessions = (0, pg_core_1.pgTable)('chat_sessions', {
    id: (0, pg_core_1.varchar)('id', { length: 255 }).primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    type: (0, pg_core_1.varchar)('type', { length: 50 }).notNull(),
    users: (0, pg_core_1.jsonb)('users').$type().notNull(),
    channelId: (0, pg_core_1.varchar)('channel_id', { length: 255 }).notNull(),
    voiceChannelId: (0, pg_core_1.varchar)('voice_channel_id', { length: 255 }),
    startTime: (0, pg_core_1.bigint)('start_time', { mode: 'number' }).notNull(),
    lastActivityTime: (0, pg_core_1.bigint)('last_activity_time', { mode: 'number' }).notNull(),
    categoryId: (0, pg_core_1.varchar)('category_id', { length: 255 }),
    messages: (0, pg_core_1.jsonb)('messages').$type().default([]),
    isThread: (0, pg_core_1.boolean)('is_thread').default(false),
    threadId: (0, pg_core_1.varchar)('thread_id', { length: 255 }),
});
exports.matchQueue = (0, pg_core_1.pgTable)('match_queue', {
    id: (0, pg_core_1.serial)('id').primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    type: (0, pg_core_1.varchar)('type', { length: 50 }).notNull(),
    userId: (0, pg_core_1.varchar)('user_id', { length: 255 }).notNull(),
    queuedAt: (0, pg_core_1.bigint)('queued_at', { mode: 'number' }).notNull(),
});
exports.dismeglePanels = (0, pg_core_1.pgTable)('dismegle_panels', {
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).primaryKey(),
    channelId: (0, pg_core_1.varchar)('channel_id', { length: 255 }).notNull(),
    messageId: (0, pg_core_1.varchar)('message_id', { length: 255 }).notNull(),
});
exports.activeEffects = (0, pg_core_1.pgTable)('active_effects', {
    id: (0, pg_core_1.varchar)('id', { length: 255 }).primaryKey(),
    guildId: (0, pg_core_1.varchar)('guild_id', { length: 255 }).notNull(),
    targetUserId: (0, pg_core_1.varchar)('target_user_id', { length: 255 }).notNull(),
    type: (0, pg_core_1.varchar)('type', { length: 20 }).notNull(),
    appliedBy: (0, pg_core_1.varchar)('applied_by', { length: 255 }).notNull(),
    expiresAt: (0, pg_core_1.bigint)('expires_at', { mode: 'number' }).notNull(),
    originalNickname: (0, pg_core_1.varchar)('original_nickname', { length: 255 }),
});
