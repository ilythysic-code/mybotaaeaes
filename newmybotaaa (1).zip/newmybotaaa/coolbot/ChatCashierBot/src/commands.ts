import { Message, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ChannelType, AttachmentBuilder, StickerFormatType, MessageFlags } from 'discord.js';
import { getRandomWYRQuestion, getWYRQuestionByCategory } from './wyrQuestions';
import { DataManager } from './dataManager';
import { Lootbox, LootboxItem, ShopItem, CustomShopItem, UserData, GuildData } from './types';
import axios from 'axios';
import * as fs from 'fs';
import * as path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execPromise = promisify(exec);

export class CommandHandler {
  constructor(private dataManager: DataManager) {
  }

  private generateEmojiForItem(itemName: string): string {
    const name = itemName.toLowerCase();
    
    const emojiMap: { [key: string]: string[] } = {
      vip: ['👑', '💎', '⭐', '🌟', '✨'],
      premium: ['💎', '👑', '🌟', '⭐', '💫'],
      boost: ['🚀', '⚡', '💨', '🔥', '💪'],
      pass: ['🎫', '🎟️', '🔑', '🗝️'],
      badge: ['🏅', '🎖️', '🏆', '🥇', '⭐'],
      role: ['🎭', '👤', '🎪', '🌈'],
      access: ['🔓', '🔑', '🗝️', '🚪'],
      ticket: ['🎫', '🎟️', '📜'],
      special: ['✨', '⭐', '🌟', '💫', '🎊'],
      legendary: ['👑', '💎', '🏆', '🌟'],
      rare: ['💎', '💠', '🔷', '🔶'],
      epic: ['🌟', '⭐', '💫', '✨'],
      gold: ['🥇', '💰', '🏆', '👑'],
      silver: ['🥈', '⚪', '🌙'],
      bronze: ['🥉', '🟤'],
      power: ['⚡', '🔋', '💪', '🔥'],
      speed: ['💨', '⚡', '🏃', '🚀'],
      star: ['⭐', '🌟', '✨', '💫'],
      heart: ['❤️', '💖', '💗', '💝'],
      crown: ['👑', '🌟', '💎'],
      diamond: ['💎', '💠', '🔷'],
      fire: ['🔥', '🌶️', '💥'],
      ice: ['❄️', '🧊', '💠'],
      thunder: ['⚡', '🌩️', '💥'],
      magic: ['✨', '🔮', '⭐', '🌟'],
      shield: ['🛡️', '⚔️', '🔰'],
      sword: ['⚔️', '🗡️', '🔪'],
      gift: ['🎁', '🎀', '🎉'],
      potion: ['🧪', '⚗️', '💊'],
      key: ['🔑', '🗝️'],
      coin: ['🪙', '💰', '💵'],
      gem: ['💎', '💠', '🔷'],
      ring: ['💍', '⭕'],
      trophy: ['🏆', '🥇', '🏅'],
      medal: ['🏅', '🥇', '🎖️'],
      flag: ['🚩', '🏁', '🎌'],
      book: ['📖', '📚', '📕'],
      scroll: ['📜', '📋'],
      music: ['🎵', '🎶', '🎼'],
      art: ['🎨', '🖼️', '🖌️'],
    };

    for (const [keyword, emojis] of Object.entries(emojiMap)) {
      if (name.includes(keyword)) {
        return emojis[Math.floor(Math.random() * emojis.length)];
      }
    }

    const defaultEmojis = ['🎁', '✨', '🌟', '💫', '🎊', '🎉', '💝', '🎀', '🏷️', '📦'];
    return defaultEmojis[Math.floor(Math.random() * defaultEmojis.length)];
  }

  private isOwnerOrManager(message: Message): boolean {
    if (!message.guild) return false;
    const isOwner = message.guild.ownerId === message.author.id;
    const isManager = this.dataManager.isManager(message.guild.id, message.author.id);
    return isOwner || isManager;
  }

  private findBestMatch<T extends {id: string, name: string}>(searchTerm: string, items: T[]): T | null {
    if (items.length === 0) return null;
    
    const search = searchTerm.toLowerCase().trim();
    
    // Exact ID match
    let match = items.find(i => i.id === search);
    if (match) return match;
    
    // Exact name match
    match = items.find(i => i.name.toLowerCase() === search);
    if (match) return match;
    
    // Calculate similarity scores for all items
    const scored = items.map(item => {
      const itemName = item.name.toLowerCase();
      let score = 0;
      
      // Exact match gets highest score
      if (itemName === search) {
        score = 1000;
      }
      // Name starts with search term
      else if (itemName.startsWith(search)) {
        score = 500;
      }
      // Name contains search term
      else if (itemName.includes(search)) {
        score = 300;
      }
      // Check word matches
      else {
        const searchWords = search.split(' ');
        const itemWords = itemName.split(' ');
        let wordMatches = 0;
        
        for (const searchWord of searchWords) {
          for (const itemWord of itemWords) {
            if (itemWord.includes(searchWord) || searchWord.includes(itemWord)) {
              wordMatches++;
            }
          }
        }
        
        if (wordMatches > 0) {
          score = wordMatches * 100;
        }
      }
      
      // Bonus for shorter names (more likely to be what user wants)
      if (score > 0) {
        score += (100 - Math.min(itemName.length, 100));
      }
      
      return { item, score };
    });
    
    // Sort by score (highest first)
    scored.sort((a, b) => b.score - a.score);
    
    // Return best match if score is good enough
    if (scored[0].score > 0) {
      return scored[0].item;
    }
    
    return null;
  }

  private async safeReply(message: Message, content: any): Promise<Message> {
    return await message.reply(content);
  }

  async handleCommand(message: Message): Promise<void> {
    if (!message.content.startsWith('?') || message.author.bot) return;
    if (!message.guild) return;

    const args = message.content.slice(1).trim().split(/ +/);
    const command = args.shift()?.toLowerCase();

    if (!command) return;

    console.log(`[CMD] Processing: ${command} | MsgID: ${message.id} | User: ${message.author.tag} | BotID: ${message.client.user?.id}`);

    // Check if user is banned (allow help and unban commands)
    if (this.dataManager.isBanned(message.guild.id, message.author.id)) {
      if (command !== 'help') {
        await this.safeReply(message, '🚫 You are banned from using this bot in this server.');
        return;
      }
    }

    // Check if command is disabled (but always allow disable/enable for server owner)
    if (command !== 'disable' && command !== 'enable' && this.dataManager.isCommandDisabled(message.guild.id, command)) {
      await this.safeReply(message, `🚫 The \`${command}\` command has been disabled by the server owner!`);
      return;
    }

    try {
      switch (command) {
        case 'help':
          await this.handleHelp(message, args);
          break;
        case 'balance':
        case 'bal':
          await this.handleBalance(message);
          break;
        case 'gift':
          await this.handleGift(message, args);
          break;
        case 'shop':
          await this.handleShop(message);
          break;
        case 'tokenshop':
          await this.handleTokenShop(message);
          break;
        case 'buy':
          await this.handleBuy(message, args);
          break;
        case 'inventory':
        case 'inv':
          await this.handleInventory(message);
          break;
        case 'createlootbox':
          await this.handleCreateLootbox(message, args);
          break;
        case 'addlootboxitem':
        case 'ali':
          await this.handleAddLootboxItem(message, args);
          break;
        case 'lootboxes':
          await this.handleListLootboxes(message);
          break;
        case 'openlootbox':
        case 'open':
          await this.handleOpenLootbox(message, args);
          break;
        case 'deletelootbox':
          await this.handleDeleteLootbox(message, args);
          break;
        case 'additem':
          await this.handleAddItem(message, args);
          break;
        case 'removeitem':
          await this.handleRemoveItem(message, args);
          break;
        case 'role':
          await this.handleAddRole(message, args);
          break;
        case 'removerole':
          await this.handleRemoveRole(message, args);
          break;
        case 'edititem':
          await this.handleEditItem(message, args);
          break;
        case 'editlootbox':
        case 'eli':
          await this.handleEditLootbox(message, args);
          break;
        case 'removelootboxitem':
        case 'rli':
          await this.handleRemoveLootboxItem(message, args);
          break;
        case 'addmanager':
          await this.handleAddManager(message, args);
          break;
        case 'removemanager':
          await this.handleRemoveManager(message, args);
          break;
        case 'managers':
          await this.handleListManagers(message);
          break;
        case 'lootbox':
          await this.handleLootboxCommand(message, args);
          break;
        case 'giftlootbox':
          await this.handleGiftLootbox(message, args);
          break;
        case 'afk':
          await this.handleAFK(message);
          break;
        case 'deleteallitems':
          await this.handleDeleteAllItems(message);
          break;
        case 'ban':
          await this.handleBan(message, args);
          break;
        case 'unban':
          await this.handleUnban(message, args);
          break;
        case 'clearinventory':
          await this.handleClearInventory(message, args);
          break;
        case 'multipurchase':
          await this.handleMultiPurchase(message, args);
          break;
        case 'setprice':
        case 'editprice':
        case 'setitemprice':
          await this.handleSetItemPrice(message, args);
          break;
        case 'use':
          await this.handleUse(message, args);
          break;
        case 'leaderboard':
        case 'lb':
        case 'top':
          await this.handleLeaderboard(message);
          break;
        case 'daily':
          await this.handleDaily(message);
          break;
        case 'work':
          await this.handleWork(message);
          break;
        case 'coinflip':
        case 'cf':
          await this.handleCoinflip(message, args);
          break;
        case 'guess':
        case 'numguess':
          await this.handleNumberGuess(message, args);
          break;
        case 'wouldyourather':
        case 'wyr':
          await this.handleWouldYouRather(message, args);
          break;
        case 'lotteryticket':
          await this.handleLotteryTicket(message, args);
          break;
        case 'give':
        case 'transfer':
          await this.handleGiveUser(message, args);
          break;
        case 'stats':
          await this.handleStats(message, args);
          break;
        case 'cooldowns':
        case 'cd':
          await this.handleCooldowns(message);
          break;
        case 'weekly':
          await this.handleWeekly(message);
          break;
        case 'hourly':
          await this.handleHourly(message);
          break;
        case 'mine':
          await this.handleMine(message);
          break;
        case 'streak':
          await this.handleStreak(message);
          break;
        case 'heist':
          await this.handleHeist(message);
          break;
        case 'spin':
          await this.handleSpin(message);
          break;
        case 'pay':
          await this.handlePay(message, args);
          break;
        case 'togglecoinflip':
          await this.handleToggleCoinflip(message);
          break;
        case 'resetserver':
          await this.handleResetServer(message);
          break;
        case 'fixboosts':
          await this.handleFixBoosts(message);
          break;
        case 'fixpromotioncount':
          await this.handleFixPromotionCount(message);
          break;
        case 'trivia':
          await this.handleTrivia(message);
          break;
        case 'achievements':
        case 'badges':
          await this.handleAchievements(message);
          break;
        case 'settitle':
          await this.handleSetTitle(message, args);
          break;
        case 'duel':
          await this.handleDuel(message, args);
          break;
        case 'accept':
          await this.handleAcceptDuel(message, args);
          break;
        case 'faceoff':
          await this.handleFaceoff(message, args);
          break;
        case 'acceptfaceoff':
          await this.handleAcceptFaceoff(message, args);
          break;
        case 'rps':
          await this.handleRps(message, args);
          break;
        case 'acceptrps':
          await this.handleAcceptRps(message, args);
          break;
        case 'treasure':
        case 'hunt':
          await this.handleTreasureHunt(message);
          break;
        case 'trade':
          await this.handleTrade(message, args);
          break;
        case 'accepttrade':
          await this.handleAcceptTrade(message, args);
          break;
        case 'quests':
          await this.handleQuests(message);
          break;
        case 'battlepass':
        case 'bp':
          await this.handleBattlePass(message);
          break;
        case 'scratch':
          await this.handleScratchCard(message);
          break;
        case 'slots':
          await this.handleSlots(message, args);
          break;
        case 'blackjack':
        case 'bj':
          await this.handleBlackjack(message, args);
          break;
        case 'lottery':
          await this.handleLottery(message, args);
          break;
        case 'vip':
          await this.handleVIP(message, args);
          break;
        case 'currencysystem':
          await this.handleCurrencySystem(message, args);
          break;
        case 'base':
          await this.handleBase(message, args);
          break;
        case 'dismegle':
          await this.handleDismegleToggle(message, args);
          break;
        case 'tokenconfig':
          await this.handleTokenConfig(message, args);
          break;
        case 'findchat':
          await this.handleFindChat(message);
          break;
        case 'findgroup':
          await this.handleFindGroup(message);
          break;
        case 'findvoice':
          await this.handleFindVoice(message);
          break;
        case 'findgroupvoice':
          await this.handleFindGroupVoice(message);
          break;
        case 'leave':
        case 'end':
          await this.handleLeaveChat(message);
          break;
        case 'panel':
          await this.handlePanel(message);
          break;
        case 'save':
          await this.handleSaveChat(message);
          break;
        case 'interests':
        case 'tag':
          await this.handleInterests(message, args);
          break;
        case 'flag':
          await this.handleFlag(message, args);
          break;
        case 'code':
          await this.handleCode(message, args);
          break;
        case 'sticker':
          await this.handleSticker(message, args);
          break;
        case 'setstaff':
          await this.handleSetStaff(message, args);
          break;
        case 'staffshop':
          await this.handleStaffShop(message);
          break;
        case 'setpromotionprice':
          await this.handleSetPromotionPrice(message, args);
          break;
        case 'setpromotioncooldown':
          await this.handleSetPromotionCooldown(message, args);
          break;
        case 'giftpromotion':
          await this.handleGiftPromotion(message, args);
          break;
        case 'customboost':
          await this.handleCustomBoost(message, args);
          break;
        case 'disable':
          await this.handleDisableCommand(message, args);
          break;
        case 'enable':
          await this.handleEnableCommand(message, args);
          break;
        case 'backups':
          await this.handleListBackups(message);
          break;
        case 'restore':
          await this.handleRestore(message, args);
          break;
        default:
          break;
      }
    } catch (error) {
      console.error('Error handling command:', error);
      await this.safeReply(message, 'An error occurred while processing your command.');
    }
  }

  private async handleHelp(message: Message, args: string[] = []): Promise<void> {
    if (args.length > 0 && args[0].toLowerCase() === 'dismegle') {
      await this.handleDismegleHelp(message);
      return;
    }
    
    const isOwner = message.guild?.ownerId === message.author.id;
    const isManager = this.isOwnerOrManager(message);
    
    const currentBase = this.getCurrentBaseEarnings(message.guild!.id);
    const embed = new EmbedBuilder()
      .setColor(0x00D9FF)
      .setTitle('✦ 💎 YAPCORD DEALER - FULL COMMAND LIST 💎 ✦')
      .setDescription(
        `╔═══════════════════════════════════════╗\n` +
        `║  💬 **Earn ${currentBase} currency per message!** \n` +
        `║  ⚡ **Boosts multiply your earnings**   \n` +
        `║  💸 **+1💰/second passive income**       \n` +
        `╚═══════════════════════════════════════╝`
      )
      .addFields(
        { 
          name: '\u200b',
          value: '```💰 CURRENCY & INCOME COMMANDS```',
          inline: false
        },
        { 
          name: '⏰ Daily/Timed Rewards', 
          value: 
            '╰─➤ `?daily` • Daily rewards (+streaks)\n' +
            '╰─➤ `?weekly` • 5000 currency bonus\n' +
            '╰─➤ `?hourly` • Hourly rewards\n' +
            '╰─➤ `?work` • Random earnings (1hr CD)\n' +
            '╰─➤ `?afk` • Earn 3/sec (3-day max)', 
          inline: true
        },
        { 
          name: '💎 Special Earnings', 
          value: 
            '╰─➤ `?mine` • Mining system\n' +
            '╰─➤ `?streak` • Daily streak bonuses\n' +
            '╰─➤ `?heist` • High-risk robbery\n' +
            '╰─➤ `?spin` • Lucky wheel jackpot\n' +
            '╰─➤ `?treasure` • Treasure maps', 
          inline: true
        },
        { 
          name: '💸 Transfers & Codes', 
          value: 
            '╰─➤ `?give @user <amt>` • Give currency\n' +
            '╰─➤ `?pay @user <amt>` • Pay currency\n' +
            '╰─➤ `?trade @user <you> <them>` • Trade\n' +
            '╰─➤ `?accepttrade` • Accept trade\n' +
            '╰─➤ `?code claim <name>` • Claim code', 
          inline: true
        },
        { 
          name: '\u200b',
          value: '```🛍️ SHOPPING & ITEMS```',
          inline: false
        },
        { 
          name: '🏪 Shops', 
          value: 
            '╰─➤ `?shop` • Browse items\n' +
            '╰─➤ `?tokenshop` • Token shop\n' +
            '╰─➤ `?buy <name>` • Purchase items\n' +
            '╰─➤ `?inventory` • View items\n' +
            '╰─➤ `?use <item>` • Use items', 
          inline: true
        },
        { 
          name: '🎁 Lootboxes', 
          value: 
            '╰─➤ `?lootboxes` • View all boxes\n' +
            '╰─➤ `?lootbox open <name>` • Open\n' +
            '╰─➤ `?open <name>` • Open box (alias)', 
          inline: true
        },
        { 
          name: '\u200b',
          value: '```🎮 GAMBLING & GAMES```',
          inline: false
        },
        { 
          name: '🎲 Classic Games', 
          value: 
            '╰─➤ `?coinflip <amt> <h/t>` • Flip coin\n' +
            '╰─➤ `?scratch` • Scratch cards\n' +
            '╰─➤ `?slots <amt>` • Slot machine\n' +
            '╰─➤ `?blackjack <amt>` • Blackjack\n' +
            '╰─➤ `?lottery buy <#>` • Buy tickets\n' +
            '╰─➤ `?trivia` • Trivia quiz (5min CD)', 
          inline: true
        },
        { 
          name: '🎮 Extended Minigames (20)', 
          value: 
            '`?dice` `?guess` `?cards` `?wheel` `?predict` `?horserace`\n' +
            '`?envelope` `?doubletrouble` `?jackpot` `?kingofhill` `?goldfish`\n' +
            '`?minesweeper` `?bombsquad` `?lotteryticket` `?roulette` `?quickpick`\n' +
            '`?coinpile` `?daredevil` `?hilo`', 
          inline: false
        },
        { 
          name: '🌟 NEW Minigames (29)', 
          value: 
            '`?dicetower` `?cardshuffle` `?gemrush`\n' +
            '`?mystery` `?ladder` `?cardcombo`\n' +
            '`?explosive` `?rainbow` `?crystal`\n' +
            '`?magicflip` `?thunder` `?phoenix` `?dragon` `?shadow`\n' +
            '`?void` `?runes` `?quantum` `?nebula` `?infinity`\n' +
            '`?eclipse` `?frostbite` `?inferno` `?tiger`', 
          inline: false
        },
        { 
          name: '⚔️ PvP Duels', 
          value: 
            '╰─➤ `?duel @user <wager>` • Battle\n' +
            '╰─➤ `?faceoff @user <wager>` • Quick draw\n' +
            '╰─➤ `?rps @user <wager>` • Rock/Paper/Scissors\n' +
            '╰─➤ `?accept` • Accept challenge\n' +
            '╰─➤ `?acceptfaceoff` • Accept faceoff\n' +
            '╰─➤ `?acceptrps` • Accept RPS', 
          inline: true
        },
        { 
          name: '\u200b',
          value: '```🏆 PROGRESSION & STATS```',
          inline: false
        },
        {
          name: '📊 Your Info',
          value: 
            '╰─➤ `?balance` • View balance\n' +
            '╰─➤ `?stats` • Your statistics\n' +
            '╰─➤ `?cooldowns` • View cooldowns\n' +
            '╰─➤ `?leaderboard` • Top players',
          inline: true
        },
        { 
          name: '🎖️ Achievements', 
          value: 
            '╰─➤ `?achievements` • View badges\n' +
            '╰─➤ `?settitle <name>` • Equip title\n' +
            '╰─➤ `?quests` • Daily quests\n' +
            '╰─➤ `?battlepass` • Battle Pass', 
          inline: true
        },
        { 
          name: '👑 VIP', 
          value: 
            '╰─➤ `?vip` • VIP info\n' +
            '╰─➤ `?vip buy <7d|30d>` • Buy VIP', 
          inline: true
        }
      );

    if (isManager) {
      embed.addFields({ 
        name: '\u200b',
        value: '```⚙️ MANAGER COMMANDS```', 
        inline: false 
      });
      embed.addFields({
        name: '🛍️ Shop Management',
        value: 
          '╰─➤ `?additem <name> <price>` • Create item\n' +
          '╰─➤ `?edititem <name> <field> <value>` • Edit item\n' +
          '╰─➤ `?removeitem <name>` • Delete item',
        inline: true
      });
      embed.addFields({
        name: '🎁 Lootbox Management',
        value: 
          '╰─➤ `?createlootbox <name> <price>`\n' +
          '╰─➤ `?eli <name> <field> <value>` • Edit lootbox\n' +
          '╰─➤ `?ali <box> <item> <%>` • Add item\n' +
          '╰─➤ `?rli <box> <item>` • Remove item\n' +
          '╰─➤ `?deletelootbox <name>`',
        inline: true
      });
      embed.addFields({
        name: '💎 Admin Tools',
        value: 
          '╰─➤ `?gift @user <amount>` • Gift currency\n' +
          '╰─➤ `?giftlootbox @user <box>` • Gift box\n' +
          '╰─➤ `?deleteallitems` • ⚠️ Delete all\n' +
          '╰─➤ `?role <@role> <price>` • Add role to shop\n' +
          '╰─➤ `?removerole <@role>` • Remove role',
        inline: true
      });
    }

    embed.addFields({
      name: '🎫 Token Shop System',
      value: 
        '╰─➤ `?tokenshop` • View rotating tokens (restocks hourly)\n' +
        '╰─➤ `?use token timeout @user` • Timeout user temporarily\n' +
        '╰─➤ `?use token changename @user <name>` • Change nickname\n' +
        '╰─➤ `?use token slowmode #channel` • Max slowmode\n' +
        '╰─➤ `?use token voicemute @user` • Server-mute in voice\n' +
        '╰─➤ `?use token rolecolor <#hex>` • Custom colored role\n' +
        '```💡 All 5 tokens restock every hour!```',
      inline: false
    });

    embed.addFields({
      name: '🎲 Dismegle - Random Chat',
      value: 
        '╰─➤ `?panel` • Create interactive Dismegle panel\n' +
        '╰─➤ `?interests add [tags]` • Add interests for better matching\n' +
        '╰─➤ `?save` • Export chat log to your DMs\n' +
        '╰─➤ `?help dismegle` • View all Dismegle commands!',
      inline: false
    });

    embed.addFields({
      name: '🎨 Sticker Creator',
      value: '╰─➤ `?sticker <url> <name>` • Create animated sticker from GIF',
      inline: false
    });

    embed.setFooter({ text: '✨ Need help? Most commands use fuzzy name matching - no IDs needed!' });

    const embeds = [embed];

    // If owner, create separate embed for owner commands (to avoid exceeding 25-field limit)
    if (isOwner) {
      const ownerEmbed = new EmbedBuilder()
        .setColor(0xFFD700)
        .setTitle('👑 OWNER ONLY COMMANDS')
        .addFields(
          { 
            name: '👥 Manager System',
            value: 
              '╰─➤ `?addmanager @user` • Add manager\n' +
              '╰─➤ `?removemanager @user` • Remove manager\n' +
              '╰─➤ `?managers` • List all managers',
            inline: true
          },
          { 
            name: '🔧 Moderation',
            value: 
              '╰─➤ `?ban @user` • Ban from bot\n' +
              '╰─➤ `?unban @user` • Unban user\n' +
              '╰─➤ `?clearinventory @user` • Reset user\n' +
              '╰─➤ `?multipurchase <item> <on/off>`\n' +
              '╰─➤ `?setprice <item> <price>` • Edit prices\n' +
              '╰─➤ `?togglecoinflip` • Toggle gambling\n' +
              '╰─➤ `?resetserver` • ⚠️ Reset ALL users',
            inline: true
          },
          {
            name: '⚙️ System Toggles',
            value:
              '╰─➤ `?currencysystem <on/off>` • Toggle chat earnings\n' +
              '╰─➤ `?dismegle <on/off>` • Toggle Dismegle features\n' +
              '╰─➤ `?tokenconfig <on/off>` • Toggle token shop',
            inline: false
          }
        );
      embeds.push(ownerEmbed);
    }

    await this.safeReply(message, { embeds });
  }

  private async handleDismegleHelp(message: Message): Promise<void> {
    const embed = new EmbedBuilder()
      .setColor(0xFF1493)
      .setTitle('🎲 DISMEGLE - Random Chat Experience')
      .setDescription(
        '**Omegle-style random matching on Discord!**\n\n' +
        'Get matched with random users for private conversations.\n' +
        'Earn currency for each chat session!\n\n' +
        '```✨ AVAILABLE MODES```'
      )
      .addFields(
        {
          name: '💬 Text Chats',
          value:
            '╰─➤ `?findchat` • 1-on-1 text chat\n' +
            '╰─➤ `?findgroup` • Group text (4 users)',
          inline: true
        },
        {
          name: '🎤 Voice Chats',
          value:
            '╰─➤ `?findvoice` • 1-on-1 voice chat\n' +
            '╰─➤ `?findgroupvoice` • Group voice (4 users)',
          inline: true
        },
        {
          name: '🎯 How It Works',
          value:
            '1️⃣ Use a match command\n' +
            '2️⃣ Wait for your match\n' +
            '3️⃣ Chat in private channel\n' +
            '4️⃣ Use `?leave` to end & earn rewards!',
          inline: false
        },
        {
          name: '💰 Rewards',
          value:
            '• Earn currency based on chat duration\n' +
            '• Minimum 100 💰 per session\n' +
            '• +50 💰 per minute chatted\n' +
            '• Stats tracked automatically!',
          inline: false
        },
        {
          name: '⚙️ Commands',
          value: '╰─➤ `?leave` or `?end` • Exit current chat',
          inline: false
        }
      )
      .setFooter({ text: '🔒 Safe, moderated, and fun! Server owners can toggle with ?dismegle on/off' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleBalance(message: Message): Promise<void> {
    const user = this.dataManager.getUser(message.guild!.id, message.author.id);
    const currentBase = this.getCurrentBaseEarnings(message.guild!.id);
    const baseWithBoost = currentBase * user.boost;
    
    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle(`💵 ${message.author.username}'s Balance`)
      .addFields(
        { name: '💰 Currency', value: `\`${user.balance.toLocaleString()}\` 💵`, inline: true },
        { name: '⚡ Boost Multiplier', value: `\`${user.boost}x\` 🚀`, inline: true },
        { name: '📊 Earnings per Message', value: `Base: \`${currentBase}\` 💵\nWith Boost: \`${baseWithBoost}\` 💵`, inline: false }
      )
      .setFooter({ text: `💬 Send messages to earn ${currentBase} currency each (before boosts)! 🎉` });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleGift(message: Message, args: string[]): Promise<void> {
    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can gift currency!');
      return;
    }

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?gift <@user> <amount>');
      return;
    }

    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      await this.safeReply(message, '❌ Please mention a valid user!');
      return;
    }

    const amount = parseInt(args[1]);
    if (isNaN(amount) || amount <= 0) {
      await this.safeReply(message, '❌ Please provide a valid positive amount!');
      return;
    }

    this.dataManager.addCurrencyRaw(message.guild!.id, targetUser.id, amount);
    
    const embed = new EmbedBuilder()
      .setColor(0xFFD700)
      .setTitle('🎁 Currency Gifted!')
      .setDescription(`✨ ${message.author} gifted **${amount.toLocaleString()}** 💰 currency to ${targetUser}! 🎉`);

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleShop(message: Message): Promise<void> {
    const shopItems = this.dataManager.getDefaultShopItems(message.guild!.id);
    const customItems = this.dataManager.getCustomShopItems(message.guild!.id);
    const roleItems = this.dataManager.getRoleShopItems(message.guild!.id);
    const lootboxes = this.dataManager.getLootboxes(message.guild!.id);
    const user = this.dataManager.getUser(message.guild!.id, message.author.id);
    const tokenConfig = this.dataManager.getRotatingShopConfig(message.guild!.id);

    const ITEMS_PER_PAGE = 6;
    
    // Check if restock is needed (every hour)
    const now = Date.now();
    const HOUR_MS = 60 * 60 * 1000;
    if (tokenConfig.enabled && (now - tokenConfig.lastRestock >= HOUR_MS || tokenConfig.currentTokens.length === 0)) {
      // Restock: All 5 tokens available every hour
      const allTokenTypes = ['token_mute', 'token_nickname', 'token_slowmode', 'token_voice_mute', 'token_role_color'];
      
      this.dataManager.setRotatingShopConfig(message.guild!.id, {
        currentTokens: allTokenTypes,
        lastRestock: now
      });
      
      tokenConfig.currentTokens = allTokenTypes;
      tokenConfig.lastRestock = now;
    }
    
    // Note: Rotating tokens (Timeout, Nickname, Slowmode, Voice Mute, Role Color) 
    // are NOT included in the main shop - they are only available via ?tokenshop
    // This prevents fuzzy matching confusion and ensures proper hourly purchase limits
    
    const allShopItems = [
      ...shopItems,
      ...customItems,
      ...roleItems.map(r => ({
        id: r.id,
        name: r.roleName,
        price: r.price,
        emoji: '🎭',
        isRole: true,
        roleId: r.roleId,
        roleName: r.roleName,
        multiPurchase: false
      }))
    ];

    const itemPages: any[][] = [];
    for (let i = 0; i < allShopItems.length; i += ITEMS_PER_PAGE) {
      itemPages.push(allShopItems.slice(i, i + ITEMS_PER_PAGE));
    }

    const totalPages = itemPages.length > 0 ? itemPages.length + 1 : 1;
    let currentPage = 0;

    const createEmbed = (page: number) => {
      const isLootboxPage = page >= itemPages.length;
      const colors = [0xFF1493, 0x00D9FF, 0xFF6B6B, 0xFFD700, 0x9B59B6, 0x00FF7F];
      const pageColor = colors[page % colors.length];
      
      const embed = new EmbedBuilder()
        .setColor(isLootboxPage ? 0xFF6600 : pageColor)
        .setTitle(isLootboxPage ? '✦ 🎰 MYSTERY LOOTBOXES 🎁 ✦' : '✦ 💎 PREMIUM MEGA SHOP 🛍️ ✦');
      
      let descriptionText = 
        `\`\`\`diff\n` +
        `+ YOUR WALLET\n` +
        `\`\`\`\n` +
        `💰 **Balance:** \`${user.balance.toLocaleString()}\` currency\n` +
        `⚡ **Boost:** \`${user.boost}x\` multiplier\n` +
        `🎯 **VIP:** ${user.vipTier ? `Tier ${user.vipTier} 👑` : 'None'}\n`;
      
      // Add rotating shop timer if enabled
      if (tokenConfig.enabled && tokenConfig.lastRestock > 0) {
        const timeUntilRestock = (tokenConfig.lastRestock + HOUR_MS) - now;
        const minutesLeft = Math.floor(timeUntilRestock / 60000);
        const secondsLeft = Math.floor((timeUntilRestock % 60000) / 1000);
        descriptionText += `🎫 **Token Shop:** Restocks in \`${minutesLeft}m ${secondsLeft}s\`\n`;
      }
      
      descriptionText += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
      
      embed.setDescription(descriptionText);

      if (page < itemPages.length) {
        const pageItems = itemPages[page];
        
        pageItems.forEach((item, index) => {
          const canAfford = user.balance >= item.price;
          const owned = user.purchasedItems?.includes(item.id);
          const memberHasRole = item.isRole ? message.guild!.members.cache.get(message.author.id)?.roles.cache.has(item.roleId) : false;
          const isOwned = owned || memberHasRole;
          
          const priceDisplay = canAfford ? `\`${item.price.toLocaleString()}\` 💰` : `~~${item.price.toLocaleString()}~~ 💰`;
          const statusIcon = isOwned ? '✅' : canAfford ? '🟢' : '🔴';
          const statusText = isOwned ? '**OWNED**' : canAfford ? '**AVAILABLE**' : '**LOCKED**';
          
          const itemEmoji = item.isRole ? '🎭' : ('emoji' in item ? item.emoji : '⚡');
          const displayName = item.isRole ? item.roleName : item.name;
          const description = 'description' in item ? `\n> *${item.description}*` : '';
          
          embed.addFields({ 
            name: `${statusIcon} ${itemEmoji} ${displayName}`,
            value: 
              `${description}\n` +
              `💵 **Price:** ${priceDisplay}\n` +
              `📊 **Status:** ${statusText}` +
              (item.isRole ? `\n🎭 **Type:** Role` : '') +
              (isOwned ? '' : canAfford ? '\n✨ **Ready to buy!**' : '\n⚠️ **Insufficient funds**'),
            inline: true
          });
        });

        if (pageItems.length === 0) {
          embed.addFields({ 
            name: '\u200b',
            value: '```yaml\n📭 SHOP EMPTY\n```\n*Check back later for new items!*\n*Managers can add items with* `?additem`', 
            inline: false 
          });
        } else {
          embed.addFields({
            name: '\u200b',
            value: 
              `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
              `🛒 **Quick Buy:** Use dropdown menu below\n` +
              `💬 **Or Type:** \`?buy <item name>\`\n` +
              `🎁 **Inventory:** \`?inventory\` to view owned items`,
            inline: false
          });
        }

        embed.setFooter({ 
          text: `💎 Page ${page + 1}/${totalPages} • ${allShopItems.length} items available`,
          iconURL: message.author.displayAvatarURL()
        });
      } else {
        if (lootboxes.length > 0) {
          lootboxes.forEach((lb, index) => {
            const canAfford = user.balance >= lb.price;
            const itemCount = lb.items.length;
            const statusIcon = canAfford ? '🟢' : '🔴';
            const priceDisplay = canAfford ? `\`${lb.price.toLocaleString()}\` 💰` : `~~${lb.price.toLocaleString()}~~ 💰`;
            const rarityEmojis = ['⭐', '💎', '🌟', '✨', '🔥'];
            const boxEmoji = rarityEmojis[index % rarityEmojis.length];
            
            embed.addFields({ 
              name: `${statusIcon} ${boxEmoji} ${lb.name}`,
              value: 
                `🎲 **Contains:** ${itemCount} ${itemCount === 1 ? 'item' : 'items'}\n` +
                `💵 **Price:** ${priceDisplay}\n` +
                `📊 **Status:** ${canAfford ? '**AVAILABLE**' : '**LOCKED**'}\n` +
                (canAfford ? '✨ **Ready to purchase!**' : '⚠️ **Insufficient funds**'),
              inline: true
            });
          });
          
          embed.addFields({
            name: '\u200b',
            value: 
              `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
              `🛒 **Buy:** Use dropdown or \`?buy <lootbox>\`\n` +
              `🎰 **Open:** \`?lootbox open <name>\` after buying\n` +
              `📋 **Drop Rates:** \`?lootboxes\` for full details`,
            inline: false
          });
        } else {
          embed.addFields({ 
            name: '\u200b',
            value: '```yaml\n🎰 NO LOOTBOXES AVAILABLE\n```\n*Managers can create them with* `?createlootbox`\n*Add mystery items for users to unbox!*', 
            inline: false 
          });
        }

        embed.setFooter({ 
          text: `💎 Page ${totalPages}/${totalPages} • ${lootboxes.length} lootboxes available`,
          iconURL: message.author.displayAvatarURL()
        });
      }

      return embed;
    };

    const createButtons = (page: number) => {
      const row = new ActionRowBuilder<ButtonBuilder>()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('prev')
            .setLabel('◀ Previous')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(page === 0),
          new ButtonBuilder()
            .setCustomId('page')
            .setLabel(`${page + 1}/${totalPages}`)
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(true),
          new ButtonBuilder()
            .setCustomId('next')
            .setLabel('Next ▶')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(page === totalPages - 1)
        );
      return row;
    };

    const createSelectMenu = (page: number) => {
      if (page < itemPages.length) {
        const pageItems = itemPages[page];
        if (pageItems.length === 0) return null;

        const options = pageItems.map(item => {
          const canAfford = user.balance >= item.price;
          const owned = user.purchasedItems?.includes(item.id);
          const emoji = 'emoji' in item ? item.emoji : '⚡';
          const displayName = item.isRole ? item.roleName : item.name;
          const label = displayName.length > 100 ? displayName.substring(0, 97) + '...' : displayName;
          const description = `${item.price.toLocaleString()} currency ${owned ? '• OWNED' : canAfford ? '• Available' : '• Locked'}`;
          
          return new StringSelectMenuOptionBuilder()
            .setLabel(label)
            .setValue(item.id)
            .setDescription(description.length > 100 ? description.substring(0, 97) + '...' : description)
            .setEmoji(emoji);
        });

        const menu = new StringSelectMenuBuilder()
          .setCustomId('buy_item')
          .setPlaceholder('🛒 Select an item to purchase...')
          .addOptions(options);

        return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);
      } else {
        if (lootboxes.length === 0) return null;

        const options = lootboxes.slice(0, 25).map(lb => {
          const canAfford = user.balance >= lb.price;
          const label = lb.name.length > 100 ? lb.name.substring(0, 97) + '...' : lb.name;
          const description = `${lb.price.toLocaleString()} currency • ${lb.items.length} items ${canAfford ? '• Available' : '• Locked'}`;
          
          return new StringSelectMenuOptionBuilder()
            .setLabel(label)
            .setValue(lb.id)
            .setDescription(description.length > 100 ? description.substring(0, 97) + '...' : description)
            .setEmoji('🎁');
        });

        const menu = new StringSelectMenuBuilder()
          .setCustomId('buy_lootbox')
          .setPlaceholder('🎁 Select a lootbox to purchase...')
          .addOptions(options);

        return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);
      }
    };

    const components: any[] = [createButtons(currentPage)];
    const selectMenu = createSelectMenu(currentPage);
    if (selectMenu) components.push(selectMenu);

    const response = await this.safeReply(message, {
      embeds: [createEmbed(currentPage)],
      components: components
    });

    const collector = response.createMessageComponentCollector({
      time: 120000
    });

    collector.on('collect', async (interaction) => {
      if (interaction.user.id !== message.author.id) {
        await interaction.reply({ content: '❌ This is not your shop menu!', flags: MessageFlags.Ephemeral });
        return;
      }

      if (interaction.isButton()) {
        if (interaction.customId === 'prev') {
          currentPage = Math.max(0, currentPage - 1);
        } else if (interaction.customId === 'next') {
          currentPage = Math.min(totalPages - 1, currentPage + 1);
        }

        const newComponents: any[] = [createButtons(currentPage)];
        const newSelectMenu = createSelectMenu(currentPage);
        if (newSelectMenu) newComponents.push(newSelectMenu);

        await interaction.update({
          embeds: [createEmbed(currentPage)],
          components: newComponents
        });
      } else if (interaction.isStringSelectMenu()) {
        const selectedId = interaction.values[0];
        const updatedUser = this.dataManager.getUser(message.guild!.id, message.author.id);

        if (interaction.customId === 'buy_item') {
          const item = allShopItems.find(i => i.id === selectedId);
          
          if (!item) {
            await interaction.reply({ content: '❌ Item not found!', flags: MessageFlags.Ephemeral });
            return;
          }

          const owned = updatedUser.purchasedItems?.includes(item.id);
          const canBuyMultiple = item.multiPurchase;

          if (owned && !canBuyMultiple) {
            await interaction.reply({ content: `❌ You already own **${item.name}**! This item can only be purchased once.`, flags: MessageFlags.Ephemeral });
            return;
          }

          if (updatedUser.balance < item.price) {
            await interaction.reply({ content: `❌ You need **${item.price.toLocaleString()}** 💰 but only have **${updatedUser.balance.toLocaleString()}** 💰!`, flags: MessageFlags.Ephemeral });
            return;
          }

          this.dataManager.removeCurrency(message.guild!.id, message.author.id, item.price);
          
          if ('isRole' in item && item.isRole) {
            try {
              const member = await message.guild!.members.fetch(message.author.id);
              const role = message.guild!.roles.cache.get((item as any).roleId);
              
              if (role) {
                await member.roles.add(role);
              }
            } catch (error) {
              console.error('Error assigning role:', error);
            }
          } else if ('type' in item && item.type === 'boost' && 'value' in item) {
            updatedUser.boost = item.value as number;
          } else {
            const emoji = 'emoji' in item ? item.emoji : '🎁';
            this.dataManager.addToInventory(message.guild!.id, message.author.id, `${emoji} ${item.name}`);
          }

          if (!canBuyMultiple && !owned) {
            if (!updatedUser.purchasedItems) updatedUser.purchasedItems = [];
            updatedUser.purchasedItems.push(item.id);
          }

          const purchaseEmbed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('✅ Purchase Successful!')
            .setDescription(`You bought **${item.name}** for **${item.price.toLocaleString()}** 💰!\n\n💰 **New balance:** ${(updatedUser.balance).toLocaleString()}`)
            .setFooter({ text: 'Thank you for your purchase!' });

          await interaction.reply({ embeds: [purchaseEmbed], flags: MessageFlags.Ephemeral });

          const newComponents: any[] = [createButtons(currentPage)];
          const newSelectMenu = createSelectMenu(currentPage);
          if (newSelectMenu) newComponents.push(newSelectMenu);

          await response.edit({
            embeds: [createEmbed(currentPage)],
            components: newComponents
          });
        } else if (interaction.customId === 'buy_lootbox') {
          const lootbox = lootboxes.find(lb => lb.id === selectedId);
          
          if (!lootbox) {
            await interaction.reply({ content: '❌ Lootbox not found!', flags: MessageFlags.Ephemeral });
            return;
          }

          if (updatedUser.balance < lootbox.price) {
            await interaction.reply({ content: `❌ You need **${lootbox.price.toLocaleString()}** 💰 but only have **${updatedUser.balance.toLocaleString()}** 💰!`, flags: MessageFlags.Ephemeral });
            return;
          }

          this.dataManager.removeCurrency(message.guild!.id, message.author.id, lootbox.price);
          this.dataManager.addToInventory(message.guild!.id, message.author.id, `🎁 ${lootbox.name} (Lootbox)`);

          const purchaseEmbed = new EmbedBuilder()
            .setColor(0x9B59B6)
            .setTitle('🎁 Lootbox Purchased!')
            .setDescription(`You bought **${lootbox.name}** for **${lootbox.price.toLocaleString()}** 💰!\n\n💰 **New balance:** ${updatedUser.balance.toLocaleString()}\n\n🎰 Use \`?lootbox open ${lootbox.name}\` to open it!`)
            .setFooter({ text: 'Good luck!' });

          await interaction.reply({ embeds: [purchaseEmbed], flags: MessageFlags.Ephemeral });

          const newComponents: any[] = [createButtons(currentPage)];
          const newSelectMenu = createSelectMenu(currentPage);
          if (newSelectMenu) newComponents.push(newSelectMenu);

          await response.edit({
            embeds: [createEmbed(currentPage)],
            components: newComponents
          });
        }
      }
    });

    collector.on('end', async () => {
      try {
        await response.edit({ components: [] });
      } catch (error) {
        // Message might be deleted
      }
    });
  }

  private async handleTokenShop(message: Message): Promise<void> {
    if (!message.guild) return;

    const tokenConfig = this.dataManager.getRotatingShopConfig(message.guild.id);
    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    if (!tokenConfig.enabled) {
      await this.safeReply(message, '❌ The token shop is currently disabled! Server owner can enable it with `?tokenconfig on`');
      return;
    }

    // Check if restock is needed (every hour)
    const now = Date.now();
    const HOUR_MS = 60 * 60 * 1000;
    if (now - tokenConfig.lastRestock >= HOUR_MS || tokenConfig.currentTokens.length === 0) {
      // Restock: All 5 tokens available every hour
      const allTokenTypes = ['token_mute', 'token_nickname', 'token_slowmode', 'token_voice_mute', 'token_role_color'];
      
      this.dataManager.setRotatingShopConfig(message.guild.id, {
        currentTokens: allTokenTypes,
        lastRestock: now
      });
      
      tokenConfig.currentTokens = allTokenTypes;
      tokenConfig.lastRestock = now;
    }

    const timeUntilRestock = (tokenConfig.lastRestock + HOUR_MS) - now;
    const minutesLeft = Math.floor(timeUntilRestock / 60000);
    const secondsLeft = Math.floor((timeUntilRestock % 60000) / 1000);

    const muteDuration = tokenConfig.muteTokenDuration;
    const nicknameDuration = tokenConfig.nicknameTokenDuration;
    
    const muteTimeText = muteDuration >= 60000 
      ? `${Math.floor(muteDuration / 60000)} minute${Math.floor(muteDuration / 60000) !== 1 ? 's' : ''}`
      : `${Math.floor(muteDuration / 1000)} second${Math.floor(muteDuration / 1000) !== 1 ? 's' : ''}`;
    
    const nicknameTimeText = nicknameDuration >= 60000
      ? `${Math.floor(nicknameDuration / 60000)} minute${Math.floor(nicknameDuration / 60000) !== 1 ? 's' : ''}`
      : `${Math.floor(nicknameDuration / 1000)} second${Math.floor(nicknameDuration / 1000) !== 1 ? 's' : ''}`;

    const embed = new EmbedBuilder()
      .setColor(0x9B59B6)
      .setTitle('🎫 Rotating Token Shop')
      .setDescription(
        `💰 **Your Balance:** ${user.balance.toLocaleString()}\n` +
        `🔄 **Next Restock:** \`${minutesLeft}m ${secondsLeft}s\`\n` +
        `📦 **Stock:** All 5 tokens available every hour!\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━━`
      )
      .setFooter({ text: 'Use ?buy <token name> to purchase | Prices and durations configurable by owner' });

    const tokenFields = [];
    
    if (tokenConfig.currentTokens.includes('token_mute')) {
      const canAfford = user.balance >= tokenConfig.muteTokenPrice;
      tokenFields.push({
        name: '🔇 Timeout Token',
        value: 
          `💰 **Price:** ${tokenConfig.muteTokenPrice.toLocaleString()}\n` +
          `⏱️ **Duration:** ${muteTimeText}\n` +
          `🎲 **Bonus:** 22% chance for 10s\n` +
          `📝 **Effect:** Timeout any user\n` +
          `${canAfford ? '✅ Available' : '🔒 Locked - Need more currency'}`,
        inline: true
      });
    }

    if (tokenConfig.currentTokens.includes('token_nickname')) {
      const canAfford = user.balance >= tokenConfig.nicknameTokenPrice;
      tokenFields.push({
        name: '📝 Nickname Token',
        value: 
          `💰 **Price:** ${tokenConfig.nicknameTokenPrice.toLocaleString()}\n` +
          `⏱️ **Duration:** ${nicknameTimeText}\n` +
          `📝 **Effect:** Change anyone's nickname\n` +
          `⏮️ **Auto-Revert:** Returns to original\n` +
          `${canAfford ? '✅ Available' : '🔒 Locked - Need more currency'}`,
        inline: true
      });
    }

    if (tokenConfig.currentTokens.includes('token_slowmode')) {
      const slowmodeDuration = tokenConfig.slowmodeTokenDuration;
      const slowmodeTimeText = slowmodeDuration >= 60000
        ? `${Math.floor(slowmodeDuration / 60000)} minute${Math.floor(slowmodeDuration / 60000) !== 1 ? 's' : ''}`
        : `${Math.floor(slowmodeDuration / 1000)} second${Math.floor(slowmodeDuration / 1000) !== 1 ? 's' : ''}`;
      const canAfford = user.balance >= tokenConfig.slowmodeTokenPrice;
      tokenFields.push({
        name: '⏱️ Slowmode Token',
        value: 
          `💰 **Price:** ${tokenConfig.slowmodeTokenPrice.toLocaleString()}\n` +
          `⏱️ **Duration:** ${slowmodeTimeText}\n` +
          `📝 **Effect:** Max slowmode on any channel\n` +
          `⏮️ **Auto-Revert:** Returns to original\n` +
          `${canAfford ? '✅ Available' : '🔒 Locked - Need more currency'}`,
        inline: true
      });
    }

    if (tokenConfig.currentTokens.includes('token_voice_mute')) {
      const voiceMuteDuration = tokenConfig.voiceMuteTokenDuration;
      const voiceMuteTimeText = voiceMuteDuration >= 60000
        ? `${Math.floor(voiceMuteDuration / 60000)} minute${Math.floor(voiceMuteDuration / 60000) !== 1 ? 's' : ''}`
        : `${Math.floor(voiceMuteDuration / 1000)} second${Math.floor(voiceMuteDuration / 1000) !== 1 ? 's' : ''}`;
      const canAfford = user.balance >= tokenConfig.voiceMuteTokenPrice;
      tokenFields.push({
        name: '🎤 Voice Mute Token',
        value: 
          `💰 **Price:** ${tokenConfig.voiceMuteTokenPrice.toLocaleString()}\n` +
          `⏱️ **Duration:** ${voiceMuteTimeText}\n` +
          `📝 **Effect:** Server-mute in voice chat\n` +
          `⏮️ **Auto-Revert:** Unmutes automatically\n` +
          `${canAfford ? '✅ Available' : '🔒 Locked - Need more currency'}`,
        inline: true
      });
    }

    if (tokenConfig.currentTokens.includes('token_role_color')) {
      const roleColorDuration = tokenConfig.roleColorTokenDuration;
      const roleColorTimeText = roleColorDuration >= 60000
        ? `${Math.floor(roleColorDuration / 60000)} minute${Math.floor(roleColorDuration / 60000) !== 1 ? 's' : ''}`
        : `${Math.floor(roleColorDuration / 1000)} second${Math.floor(roleColorDuration / 1000) !== 1 ? 's' : ''}`;
      const canAfford = user.balance >= tokenConfig.roleColorTokenPrice;
      tokenFields.push({
        name: '🎨 Role Color Token',
        value: 
          `💰 **Price:** ${tokenConfig.roleColorTokenPrice.toLocaleString()}\n` +
          `⏱️ **Duration:** ${roleColorTimeText}\n` +
          `📝 **Effect:** Custom colored role\n` +
          `⏮️ **Auto-Delete:** Role removed after\n` +
          `${canAfford ? '✅ Available' : '🔒 Locked - Need more currency'}`,
        inline: true
      });
    }

    if (tokenFields.length === 0) {
      embed.addFields({
        name: '⚠️ No Tokens Available',
        value: 'Waiting for restock...',
        inline: false
      });
    } else {
      embed.addFields(...tokenFields);
    }

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleBuy(message: Message, args: string[]): Promise<void> {
    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?buy <item name>');
      return;
    }

    const searchTerm = args.join(' ');

    // Check if buying promotion from staff shop
    if (searchTerm.toLowerCase() === 'promotion') {
      await this.handleBuyPromotion(message);
      return;
    }

    const shopItems = this.dataManager.getDefaultShopItems(message.guild!.id);
    const customItems = this.dataManager.getCustomShopItems(message.guild!.id);
    const roleItems = this.dataManager.getRoleShopItems(message.guild!.id);
    const lootboxes = this.dataManager.getLootboxes(message.guild!.id);
    const tokenConfig = this.dataManager.getRotatingShopConfig(message.guild!.id);

    const tokenItems = [];
    if (tokenConfig.enabled) {
      const muteDuration = tokenConfig.muteTokenDuration;
      const muteTimeText = muteDuration >= 60000 
        ? `${Math.floor(muteDuration / 60000)} minute${Math.floor(muteDuration / 60000) !== 1 ? 's' : ''}`
        : `${Math.floor(muteDuration / 1000)} second${Math.floor(muteDuration / 1000) !== 1 ? 's' : ''}`;
      
      const nicknameMinutes = Math.floor(tokenConfig.nicknameTokenDuration / 60000);
      const slowmodeMinutes = Math.floor(tokenConfig.slowmodeTokenDuration / 60000);
      const voiceMuteMinutes = Math.floor(tokenConfig.voiceMuteTokenDuration / 60000);
      const roleColorMinutes = Math.floor(tokenConfig.roleColorTokenDuration / 60000);
      
      tokenItems.push({
        id: 'token_mute',
        name: 'Timeout Token',
        description: `Timeout a user for ${muteTimeText} (22% chance for 10s)`,
        price: tokenConfig.muteTokenPrice,
        emoji: '🔇'
      });
      
      tokenItems.push({
        id: 'token_nickname',
        name: 'Nickname Token',
        description: `Change a user's nickname for ${nicknameMinutes} minutes`,
        price: tokenConfig.nicknameTokenPrice,
        emoji: '📝'
      });
      
      tokenItems.push({
        id: 'token_slowmode',
        name: 'Slowmode Token',
        description: `Set max slowmode on any channel for ${slowmodeMinutes} minutes`,
        price: tokenConfig.slowmodeTokenPrice,
        emoji: '⏱️'
      });
      
      tokenItems.push({
        id: 'token_voice_mute',
        name: 'Voice Mute Token',
        description: `Server-mute a user in voice for ${voiceMuteMinutes} minutes`,
        price: tokenConfig.voiceMuteTokenPrice,
        emoji: '🎤'
      });
      
      tokenItems.push({
        id: 'token_role_color',
        name: 'Role Color Token',
        description: `Get a custom colored role for ${roleColorMinutes} minutes`,
        price: tokenConfig.roleColorTokenPrice,
        emoji: '🎨'
      });
    }

    // Try to find best match in shop items
    const item = this.findBestMatch(searchTerm, shopItems);
    
    // Try to find best match in custom items
    const customItem = this.findBestMatch(searchTerm, customItems);
    
    // Try to find best match in role items
    const roleItem = this.findBestMatch(searchTerm, roleItems.map(r => ({ ...r, name: r.roleName })));
    
    // Try to find best match in lootboxes
    const lootbox = this.findBestMatch(searchTerm, lootboxes);
    
    // Try to find best match in tokens
    const token = this.findBestMatch(searchTerm, tokenItems);

    // Determine which item to purchase based on best match
    let selectedItem = null;
    let selectedCustomItem = null;
    let selectedRoleItem = null;
    let selectedLootbox = null;
    let selectedToken = null;
    
    const candidates = [];
    if (item) candidates.push({ type: 'item', data: item });
    if (customItem) candidates.push({ type: 'custom', data: customItem });
    if (roleItem) candidates.push({ type: 'role', data: roleItem });
    if (lootbox) candidates.push({ type: 'lootbox', data: lootbox });
    if (token) candidates.push({ type: 'token', data: token });
    
    if (candidates.length === 0) {
      const allItems = [
        ...shopItems.map(i => i.name), 
        ...customItems.map(i => i.name),
        ...lootboxes.map(l => l.name)
      ];
      const suggestions = allItems.slice(0, 3).join(', ');
      await this.safeReply(message, `❌ Item not found! Use \`?shop\` to see available items.\n💡 Available: ${suggestions}`);
      return;
    }
    
    // Pick the best match
    if (candidates.length === 1) {
      const candidate = candidates[0];
      if (candidate.type === 'item') selectedItem = candidate.data;
      else if (candidate.type === 'custom') selectedCustomItem = candidate.data;
      else if (candidate.type === 'role') selectedRoleItem = candidate.data;
      else if (candidate.type === 'token') selectedToken = candidate.data;
      else selectedLootbox = candidate.data;
    } else {
      // Multiple matches - pick the one with the best name match
      let bestScore = -1;
      let bestCandidate = null;
      
      for (const candidate of candidates) {
        const name = candidate.data.name.toLowerCase();
        let score = 0;
        
        if (name === searchTerm.toLowerCase()) score = 100;
        else if (name.startsWith(searchTerm.toLowerCase())) score = 80;
        else if (name.includes(searchTerm.toLowerCase())) score = 50;
        
        if (score > bestScore) {
          bestScore = score;
          bestCandidate = candidate;
        }
      }
      
      if (bestCandidate) {
        if (bestCandidate.type === 'item') selectedItem = bestCandidate.data;
        else if (bestCandidate.type === 'custom') selectedCustomItem = bestCandidate.data;
        else if (bestCandidate.type === 'role') selectedRoleItem = bestCandidate.data;
        else if (bestCandidate.type === 'token') selectedToken = bestCandidate.data;
        else selectedLootbox = bestCandidate.data;
      }
    }

    // Handle token purchase
    if (selectedToken) {
      const tokenData = selectedToken as any;
      const user = this.dataManager.getUser(message.guild!.id, message.author.id);
      const currentTokenConfig = this.dataManager.getRotatingShopConfig(message.guild!.id);

      // Verify token is currently available in rotating shop
      if (!currentTokenConfig.enabled) {
        await this.safeReply(message, '❌ Token shop is currently disabled!');
        return;
      }

      if (!currentTokenConfig.currentTokens.includes(tokenData.id)) {
        await this.safeReply(message, `❌ **${tokenData.name}** is not currently available in the rotating shop! Check back after the next restock.`);
        return;
      }

      const cooldownCheck = this.dataManager.isTokenOnCooldown(message.guild!.id, message.author.id, tokenData.id);
      if (cooldownCheck.onCooldown && cooldownCheck.timeLeft) {
        const minutesLeft = Math.floor(cooldownCheck.timeLeft / 60000);
        const secondsLeft = Math.floor((cooldownCheck.timeLeft % 60000) / 1000);
        await this.safeReply(message, `❌ You can only buy one **${tokenData.name}** per hour!\n\n⏰ **Cooldown:** ${minutesLeft}m ${secondsLeft}s remaining`);
        return;
      }

      if (user.balance < tokenData.price) {
        await this.safeReply(message, `❌ Insufficient funds! You need **${tokenData.price.toLocaleString()}** currency but only have **${user.balance.toLocaleString()}**.`);
        return;
      }

      if (!this.dataManager.removeCurrency(message.guild!.id, message.author.id, tokenData.price)) {
        await this.safeReply(message, '❌ Transaction failed!');
        return;
      }

      this.dataManager.addToInventory(message.guild!.id, message.author.id, tokenData.id);
      this.dataManager.recordTokenPurchase(message.guild!.id, message.author.id, tokenData.id);

      const newBalance = this.dataManager.getUser(message.guild!.id, message.author.id).balance;
      
      const timeUntilRestock = (currentTokenConfig.lastRestock + 3600000) - Date.now();
      const minutesLeft = Math.floor(timeUntilRestock / 60000);
      
      const embed = new EmbedBuilder()
        .setColor(0x9B59B6)
        .setTitle('✅ Token Purchased!')
        .setDescription(`${tokenData.emoji} You purchased a **${tokenData.name}**!\n\n📝 ${tokenData.description}\n\n💡 Use \`?use ${tokenData.id.replace('token_', 'token ')} @user\` to activate!\n\n⏰ Shop restocks in **${minutesLeft} minutes**`)
        .setFooter({ text: `💰 New balance: ${newBalance.toLocaleString()} currency` });

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    // Handle role purchase
    if (selectedRoleItem) {
      const roleData = selectedRoleItem as any;
      const user = this.dataManager.getUser(message.guild!.id, message.author.id);
      
      // Check if user already has the role
      const member = await message.guild!.members.fetch(message.author.id);
      if (member.roles.cache.has(roleData.roleId)) {
        await this.safeReply(message, `❌ You already have the **${roleData.roleName}** role!`);
        return;
      }

      // Check if already purchased
      if (this.dataManager.hasUserPurchased(message.guild!.id, message.author.id, roleData.id)) {
        await this.safeReply(message, `❌ You've already purchased the **${roleData.roleName}** role!`);
        return;
      }

      if (user.balance < roleData.price) {
        await this.safeReply(message, `❌ Insufficient funds! You need **${roleData.price.toLocaleString()}** currency but only have **${user.balance.toLocaleString()}**.`);
        return;
      }

      if (!this.dataManager.removeCurrency(message.guild!.id, message.author.id, roleData.price)) {
        await this.safeReply(message, '❌ Transaction failed!');
        return;
      }

      // Assign the role
      try {
        const role = message.guild!.roles.cache.get(roleData.roleId);
        if (role) {
          await member.roles.add(role);
          this.dataManager.markItemAsPurchased(message.guild!.id, message.author.id, roleData.id);

          const newBalance = this.dataManager.getUser(message.guild!.id, message.author.id).balance;
          const embed = new EmbedBuilder()
            .setColor(role.color || 0x5865F2)
            .setTitle('✅ Role Purchased!')
            .setDescription(`🎭 You purchased the **${roleData.roleName}** role!\n\n✨ The role has been assigned to you!`)
            .setFooter({ text: `💰 New balance: ${newBalance.toLocaleString()} currency` });

          await this.safeReply(message, { embeds: [embed] });
          return;
        } else {
          await this.safeReply(message, '❌ Role not found! Please contact an administrator.');
          // Refund
          this.dataManager.addCurrencyRaw(message.guild!.id, message.author.id, roleData.price);
          return;
        }
      } catch (error) {
        console.error('Error assigning role:', error);
        await this.safeReply(message, '❌ Failed to assign role! Please contact an administrator.');
        // Refund
        this.dataManager.addCurrencyRaw(message.guild!.id, message.author.id, roleData.price);
        return;
      }
    }

    // Handle lootbox purchase
    if (selectedLootbox) {
      const lootboxData = selectedLootbox as Lootbox;
      const user = this.dataManager.getUser(message.guild!.id, message.author.id);
      
      if (user.balance < lootboxData.price) {
        await this.safeReply(message, `❌ Insufficient funds! You need **${lootboxData.price.toLocaleString()}** currency but only have **${user.balance.toLocaleString()}**.`);
        return;
      }

      if (lootboxData.items.length === 0) {
        await this.safeReply(message, '❌ This lootbox is empty! Ask an admin to add items to it.');
        return;
      }

      if (!this.dataManager.removeCurrency(message.guild!.id, message.author.id, lootboxData.price)) {
        await this.safeReply(message, '❌ Transaction failed!');
        return;
      }

      this.dataManager.addToInventory(message.guild!.id, message.author.id, `🎁 ${lootboxData.name}`);
      
      const newBalance = this.dataManager.getUser(message.guild!.id, message.author.id).balance;
      
      const embed = new EmbedBuilder()
        .setColor(0x9B59B6)
        .setTitle('✅ Lootbox Purchased!')
        .setDescription(`🎁 You purchased **${lootboxData.name}**!\n\n🎒 It has been added to your inventory.\n💡 Use \`?lootbox open ${lootboxData.name}\` to open it!`)
        .setFooter({ text: `💰 New balance: ${newBalance.toLocaleString()} currency` });

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    // Use the selected item
    const finalItem = selectedItem as ShopItem | null;
    const finalCustomItem = selectedCustomItem as CustomShopItem | null;

    const user = this.dataManager.getUser(message.guild!.id, message.author.id);
    const price = finalItem ? finalItem.price : (finalCustomItem as CustomShopItem).price;
    const itemName = finalItem ? finalItem.name : (finalCustomItem as CustomShopItem).name;
    const itemEmoji = finalCustomItem ? (finalCustomItem as CustomShopItem).emoji : '⚡';
    const itemId = finalItem ? finalItem.id : (finalCustomItem as CustomShopItem).id;
    const multiPurchase = finalItem ? (finalItem as ShopItem).multiPurchase : (finalCustomItem as CustomShopItem).multiPurchase;
    
    const shopItemData = finalItem as ShopItem;
    
    // Special handling for boost items - only one boost at a time, no downgrades
    if (finalItem && shopItemData.type === 'boost' && shopItemData.value) {
      // Check if user already has a boost
      if (user.boost > 1) {
        // User has a boost already
        if (shopItemData.value <= user.boost) {
          await this.safeReply(message, `❌ You already have a **${user.boost}x** boost! You can't downgrade or buy the same boost.\n\n💡 Only higher boosts can be purchased.`);
          return;
        }
        // Allow upgrade - user wants higher boost
      }
    } else {
      // Non-boost items - check one-time purchase restriction
      if (!multiPurchase && this.dataManager.hasUserPurchased(message.guild!.id, message.author.id, itemId)) {
        await this.safeReply(message, `❌ You've already purchased **${itemName}**! This is a one-time purchase item.\n\n💡 Server owner can enable multi-purchase with \`?multipurchase ${itemName} on\``);
        return;
      }
    }
    
    if (user.balance < price) {
      await this.safeReply(message, `❌ Insufficient funds! You need **${price.toLocaleString()}** currency but only have **${user.balance.toLocaleString()}**.`);
      return;
    }

    if (!this.dataManager.removeCurrency(message.guild!.id, message.author.id, price)) {
      await this.safeReply(message, '❌ Transaction failed!');
      return;
    }

    const newBalance = this.dataManager.getUser(message.guild!.id, message.author.id).balance;

    // Mark item as purchased
    this.dataManager.markItemAsPurchased(message.guild!.id, message.author.id, itemId);

    if (finalItem && shopItemData.type === 'boost' && shopItemData.value) {
      this.dataManager.updateUser(message.guild!.id, message.author.id, { boost: shopItemData.value });
      const currentBase = this.getCurrentBaseEarnings(message.guild!.id);
      
      const embed = new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('✅ Purchase Successful!')
        .setDescription(`🎉 You purchased **${shopItemData.name}**!\n\n⚡ Your currency boost is now **${shopItemData.value}x** 🚀\n💬 You'll now earn **${currentBase * shopItemData.value}** currency per message!`)
        .setFooter({ text: `💰 New balance: ${newBalance.toLocaleString()} currency` });

      await this.safeReply(message, { embeds: [embed] });
    } else {
      const fullItemName = finalCustomItem ? `${itemEmoji} ${itemName}` : itemName;
      this.dataManager.addToInventory(message.guild!.id, message.author.id, fullItemName);
      
      const embed = new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('✅ Purchase Successful!')
        .setDescription(`🎉 You purchased ${itemEmoji} **${itemName}**!\n\n🎒 Check your inventory with \`?inventory\`\n💡 Use \`?use ${itemName}\` to consume it!`)
        .setFooter({ text: `💰 New balance: ${newBalance.toLocaleString()} currency` });

      await this.safeReply(message, { embeds: [embed] });
    }
  }

  private async handleInventory(message: Message): Promise<void> {
    const user = this.dataManager.getUser(message.guild!.id, message.author.id);
    
    const embed = new EmbedBuilder()
      .setColor(0xE67E22)
      .setTitle(`🎒 ${message.author.username}'s Inventory`)
      .setDescription(
        user.inventory.length > 0 
          ? `✨ You have **${user.inventory.length}** item(s):\n\n` + user.inventory.map((item, i) => `${i + 1}. ${item}`).join('\n')
          : '📭 Your inventory is empty!\n\n🎲 Open lootboxes to get items!'
      )
      .setFooter({ text: user.inventory.length > 0 ? '🎉 Keep opening lootboxes for more items!' : '💡 Use ?lootboxes to see what you can open!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleCreateLootbox(message: Message, args: string[]): Promise<void> {
    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can create lootboxes!');
      return;
    }

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?createlootbox <name> <price>');
      return;
    }

    const price = parseInt(args[args.length - 1]);
    const name = args.slice(0, -1).join(' ');

    if (isNaN(price) || price <= 0) {
      await this.safeReply(message, '❌ Please provide a valid positive price!');
      return;
    }

    // Auto-generate ID from name
    const id = name.toLowerCase().replace(/[^a-z0-9]/g, '_') + '_' + Date.now();

    const lootbox: Lootbox = {
      id,
      guildId: message.guild!.id,
      name,
      price,
      items: []
    };

    this.dataManager.addLootbox(lootbox);
    
    const embed = new EmbedBuilder()
      .setColor(0x3498DB)
      .setTitle('✅ Lootbox Created!')
      .setDescription(`🎁 **${name}** has been created!\n\n💵 Price: **${price.toLocaleString()}** currency\n\n➕ Use \`?addlootboxitem ${name}\` to add items to it!`);

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleAddLootboxItem(message: Message, args: string[]): Promise<void> {
    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can modify lootboxes!');
      return;
    }

    if (args.length < 3) {
      await this.safeReply(message, 'Usage: ?ali <lootbox name> <item_name> <chance%>');
      return;
    }

    const chance = parseFloat(args[args.length - 1]);
    if (isNaN(chance) || chance <= 0 || chance > 100) {
      await this.safeReply(message, '❌ Please provide a valid chance between 0 and 100!');
      return;
    }

    // Parse lootbox name and item name
    const lootboxes = this.dataManager.getLootboxes(message.guild!.id);
    
    // Try to find lootbox by testing exact matches first, then fuzzy
    let lootbox = null;
    let lootboxWordCount = 0;
    
    // First pass: look for exact name matches only
    for (let i = 1; i <= args.length - 2; i++) {
      const searchTerm = args.slice(0, i).join(' ').toLowerCase();
      const exactMatch = lootboxes.find(lb => lb.name.toLowerCase() === searchTerm);
      if (exactMatch) {
        lootbox = exactMatch;
        lootboxWordCount = i;
        break; // Stop at first exact match
      }
    }
    
    // Second pass: if no exact match, use fuzzy matching on shortest possible match
    if (!lootbox) {
      for (let i = 1; i <= args.length - 2; i++) {
        const searchTerm = args.slice(0, i).join(' ');
        const match = this.findBestMatch(searchTerm, lootboxes);
        if (match) {
          lootbox = match;
          lootboxWordCount = i;
          break; // Stop at first fuzzy match
        }
      }
    }
    
    if (!lootbox) {
      await this.safeReply(message, '❌ Lootbox not found! Use `?lootboxes` to see available lootboxes.');
      return;
    }

    // Item name is everything between lootbox name and chance percentage
    const itemName = args.slice(lootboxWordCount, -1).join(' ');
    if (!itemName) {
      await this.safeReply(message, '❌ Please provide an item name!');
      return;
    }

    lootbox.items.push({ name: itemName, chance });
    this.dataManager.removeLootbox(message.guild!.id, lootbox.id);
    this.dataManager.addLootbox(lootbox);

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('✅ Item Added to Lootbox!')
      .setDescription(`🎁 **${itemName}** with **${chance}%** chance has been added to **${lootbox.name}**! ✨`);

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleListLootboxes(message: Message): Promise<void> {
    const lootboxes = this.dataManager.getLootboxes(message.guild!.id);
    const user = this.dataManager.getUser(message.guild!.id, message.author.id);

    if (lootboxes.length === 0) {
      await this.safeReply(message, '📭 No lootboxes available in this server yet!\n\nAdmins can create lootboxes with `?createlootbox`');
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(0xF39C12)
      .setTitle('🎁 Available Lootboxes')
      .setDescription(`💰 **Your balance:** ${user.balance.toLocaleString()} currency\n\n🎲 Use \`?open <lootbox_id>\` to open\n`);

    lootboxes.forEach(lb => {
      const itemsList = lb.items.map(i => `🎁 ${i.name} - **${i.chance}%**`).join('\n') || '📭 Empty';
      const lootboxInfo = `💵 **Price:** \`${lb.price.toLocaleString()}\` currency\n✨ **Possible Items:**\n${itemsList}`;
      embed.addFields({
        name: `🎁 ${lb.name} [${lb.id}]`,
        value: lootboxInfo,
        inline: false
      });
    });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleOpenLootbox(message: Message, args: string[]): Promise<void> {
    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?open <lootbox_id>');
      return;
    }

    const lootboxId = args[0];
    const lootbox = this.dataManager.getLootbox(message.guild!.id, lootboxId);

    if (!lootbox) {
      await this.safeReply(message, '❌ Lootbox not found!');
      return;
    }

    if (lootbox.items.length === 0) {
      await this.safeReply(message, '❌ This lootbox has no items!');
      return;
    }

    const user = this.dataManager.getUser(message.guild!.id, message.author.id);
    
    if (user.balance < lootbox.price) {
      await this.safeReply(message, `❌ Insufficient funds! You need **${lootbox.price}** currency but only have **${user.balance}**.`);
      return;
    }

    if (!this.dataManager.removeCurrency(message.guild!.id, message.author.id, lootbox.price)) {
      await this.safeReply(message, '❌ Transaction failed!');
      return;
    }

    const totalChance = lootbox.items.reduce((sum, item) => sum + item.chance, 0);
    const roll = Math.random() * totalChance;
    
    let currentChance = 0;
    let wonItem: LootboxItem | null = null;
    
    for (const item of lootbox.items) {
      currentChance += item.chance;
      if (roll <= currentChance) {
        wonItem = item;
        break;
      }
    }

    if (wonItem) {
      this.dataManager.addToInventory(message.guild!.id, message.author.id, wonItem.name);
      
      const newBalance = this.dataManager.getUser(message.guild!.id, message.author.id).balance;
      
      const embed = new EmbedBuilder()
        .setColor(0xFFD700)
        .setTitle('🎉 Lootbox Opened!')
        .setDescription(`🎁 You opened **${lootbox.name}**!\n\n✨🎊 **You won: ${wonItem.name}** 🎊✨\n\n🎒 The item has been added to your inventory!`)
        .setFooter({ text: `💰 New balance: ${newBalance.toLocaleString()} currency | Keep opening for more! 🎲` });

      await this.safeReply(message, { embeds: [embed] });
    } else {
      await this.safeReply(message, '❌ Something went wrong with the lootbox!');
    }
  }

  private async handleDeleteLootbox(message: Message, args: string[]): Promise<void> {
    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can delete lootboxes!');
      return;
    }

    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?deletelootbox <lootbox name>');
      return;
    }

    const searchTerm = args.join(' ');
    const lootboxes = this.dataManager.getLootboxes(message.guild!.id);
    const lootbox = this.findBestMatch(searchTerm, lootboxes);
    
    if (!lootbox) {
      await this.safeReply(message, '❌ Lootbox not found! Use `?lootboxes` to see available lootboxes.');
      return;
    }
    
    if (this.dataManager.removeLootbox(message.guild!.id, lootbox.id)) {
      await this.safeReply(message, `✅ Lootbox **${lootbox.name}** has been deleted!`);
    } else {
      await this.safeReply(message, '❌ Failed to delete lootbox!');
    }
  }

  private async handleAddItem(message: Message, args: string[]): Promise<void> {
    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can add shop items!');
      return;
    }

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?additem <name> <price>');
      return;
    }

    const price = parseInt(args[args.length - 1]);
    let name = args.slice(0, -1).join(' ');
    
    // Remove surrounding quotes if present
    name = name.replace(/^["'](.*)["']$/, '$1');

    if (isNaN(price) || price <= 0) {
      await this.safeReply(message, '❌ Please provide a valid positive price!');
      return;
    }

    const id = name.toLowerCase().replace(/\s+/g, '_');
    const emoji = this.generateEmojiForItem(name);
    
    const existing = this.dataManager.getCustomShopItem(message.guild!.id, id);
    if (existing) {
      await this.safeReply(message, '❌ An item with this name already exists!');
      return;
    }

    this.dataManager.addCustomShopItem({
      id,
      guildId: message.guild!.id,
      name,
      price,
      emoji,
      multiPurchase: false
    });

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('✅ Shop Item Added!')
      .setDescription(`${emoji} **${name}** has been added to the shop!\n\n🆔 ID: \`${id}\`\n💵 Price: **${price.toLocaleString()}** currency\n🔒 One-time purchase (server owner can enable multi-purchase)\n\n💳 Users can now buy it with \`?buy ${name}\``);

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleRemoveItem(message: Message, args: string[]): Promise<void> {
    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can remove shop items!');
      return;
    }

    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?removeitem <item name>');
      return;
    }

    const searchTerm = args.join(' ');
    const customItems = this.dataManager.getCustomShopItems(message.guild!.id);
    
    const item = this.findBestMatch(searchTerm, customItems);
    
    if (!item) {
      await this.safeReply(message, '❌ Item not found! Use `?shop` to see custom items.');
      return;
    }
    
    if (this.dataManager.removeCustomShopItem(message.guild!.id, item.id)) {
      await this.safeReply(message, `✅ Shop item **${item.name}** has been removed!`);
    } else {
      await this.safeReply(message, '❌ Failed to remove item!');
    }
  }

  private async handleEditItem(message: Message, args: string[]): Promise<void> {
    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can edit shop items!');
      return;
    }

    if (args.length < 3) {
      await this.safeReply(message, 'Usage: ?edititem <item name> <name|price> <new_value>');
      return;
    }

    const field = args[args.length - 2].toLowerCase();
    const value = args[args.length - 1];
    const searchTerm = args.slice(0, -2).join(' ');

    if (!value || (field !== 'name' && field !== 'price')) {
      await this.safeReply(message, '❌ Usage: ?edititem <item name> <name|price> <new_value>');
      return;
    }

    const customItems = this.dataManager.getCustomShopItems(message.guild!.id);
    const item = this.findBestMatch(searchTerm, customItems);
    
    if (!item) {
      await this.safeReply(message, '❌ Item not found! Only custom items can be edited.');
      return;
    }

    if (field === 'name') {
      if (this.dataManager.updateCustomShopItem(message.guild!.id, item.id, { name: value })) {
        const embed = new EmbedBuilder()
          .setColor(0x2ECC71)
          .setTitle('✅ Item Updated!')
          .setDescription(`${item.emoji} **${item.name}**\n\n📝 Name changed to: **${value}**`);
        await this.safeReply(message, { embeds: [embed] });
      }
    } else if (field === 'price') {
      const newPrice = parseInt(value);
      if (isNaN(newPrice) || newPrice <= 0) {
        await this.safeReply(message, '❌ Please provide a valid positive price!');
        return;
      }
      if (this.dataManager.updateCustomShopItem(message.guild!.id, item.id, { price: newPrice })) {
        const embed = new EmbedBuilder()
          .setColor(0x2ECC71)
          .setTitle('✅ Item Updated!')
          .setDescription(`${item.emoji} **${item.name}**\n\n💵 Price changed to: **${newPrice.toLocaleString()}** currency`);
        await this.safeReply(message, { embeds: [embed] });
      }
    }
  }

  private async handleEditLootbox(message: Message, args: string[]): Promise<void> {
    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can edit lootboxes!');
      return;
    }

    if (args.length < 3) {
      await this.safeReply(message, 'Usage: ?eli <lootbox name> <name|price> <new_value>');
      return;
    }

    const field = args[args.length - 2].toLowerCase();
    const value = args[args.length - 1];
    const searchTerm = args.slice(0, -2).join(' ');

    if (!value || (field !== 'name' && field !== 'price')) {
      await this.safeReply(message, '❌ Usage: ?eli <lootbox name> <name|price> <new_value>');
      return;
    }

    const lootboxes = this.dataManager.getLootboxes(message.guild!.id);
    const lootbox = this.findBestMatch(searchTerm, lootboxes);
    
    if (!lootbox) {
      await this.safeReply(message, '❌ Lootbox not found! Use `?lootboxes` to see available lootboxes.');
      return;
    }

    if (field === 'name') {
      if (this.dataManager.updateLootbox(message.guild!.id, lootbox.id, { name: value })) {
        const embed = new EmbedBuilder()
          .setColor(0x2ECC71)
          .setTitle('✅ Lootbox Updated!')
          .setDescription(`🎁 **${lootbox.name}**\n\n📝 Name changed to: **${value}**`);
        await this.safeReply(message, { embeds: [embed] });
      }
    } else if (field === 'price') {
      const newPrice = parseInt(value);
      if (isNaN(newPrice) || newPrice <= 0) {
        await this.safeReply(message, '❌ Please provide a valid positive price!');
        return;
      }
      if (this.dataManager.updateLootbox(message.guild!.id, lootbox.id, { price: newPrice })) {
        const embed = new EmbedBuilder()
          .setColor(0x2ECC71)
          .setTitle('✅ Lootbox Updated!')
          .setDescription(`🎁 **${lootbox.name}**\n\n💵 Price changed to: **${newPrice.toLocaleString()}** currency`);
        await this.safeReply(message, { embeds: [embed] });
      }
    }
  }

  private async handleRemoveLootboxItem(message: Message, args: string[]): Promise<void> {
    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can modify lootboxes!');
      return;
    }

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?rli <lootbox name> <item_name>');
      return;
    }

    // Try to find the lootbox first using fuzzy matching on the first few words
    const lootboxes = this.dataManager.getLootboxes(message.guild!.id);
    let lootbox = null;
    let itemStartIndex = 1;
    
    // Try matching with progressively more words
    for (let i = 1; i <= args.length - 1; i++) {
      const searchTerm = args.slice(0, i).join(' ');
      const match = this.findBestMatch(searchTerm, lootboxes);
      if (match) {
        lootbox = match;
        itemStartIndex = i;
      }
    }
    
    if (!lootbox) {
      await this.safeReply(message, '❌ Lootbox not found! Use `?lootboxes` to see available lootboxes.');
      return;
    }

    const itemName = args.slice(itemStartIndex).join(' ');
    if (!itemName) {
      await this.safeReply(message, '❌ Please provide an item name!');
      return;
    }

    if (this.dataManager.removeLootboxItem(message.guild!.id, lootbox.id, itemName)) {
      const embed = new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('✅ Item Removed!')
        .setDescription(`🎁 **${lootbox.name}**\n\n🗑️ Removed item: **${itemName}**`);
      await this.safeReply(message, { embeds: [embed] });
    } else {
      await this.safeReply(message, '❌ Item not found in this lootbox!');
    }
  }

  private async handleAddManager(message: Message, args: string[]): Promise<void> {
    if (!message.guild) {
      await this.safeReply(message, '❌ This command can only be used in a server!');
      return;
    }

    if (!message.guild.ownerId || message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can add managers!');
      return;
    }

    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?addmanager <@user>');
      return;
    }

    const mentionedUser = message.mentions.users.first();
    if (!mentionedUser) {
      await this.safeReply(message, '❌ Please mention a user to add as manager!');
      return;
    }

    if (mentionedUser.id === message.author.id) {
      await this.safeReply(message, '❌ You are already the server owner!');
      return;
    }

    if (mentionedUser.bot) {
      await this.safeReply(message, '❌ Bots cannot be managers!');
      return;
    }

    if (this.dataManager.addManager(message.guild!.id, mentionedUser.id)) {
      const embed = new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('✅ Manager Added!')
        .setDescription(`👤 **${mentionedUser.username}** is now a manager!\n\n⚙️ They can now use all owner commands.`);
      await this.safeReply(message, { embeds: [embed] });
    } else {
      await this.safeReply(message, '❌ This user is already a manager!');
    }
  }

  private async handleRemoveManager(message: Message, args: string[]): Promise<void> {
    if (!message.guild) {
      await this.safeReply(message, '❌ This command can only be used in a server!');
      return;
    }

    if (!message.guild.ownerId || message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can remove managers!');
      return;
    }

    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?removemanager <@user>');
      return;
    }

    const mentionedUser = message.mentions.users.first();
    if (!mentionedUser) {
      await this.safeReply(message, '❌ Please mention a user to remove from managers!');
      return;
    }

    if (this.dataManager.removeManager(message.guild!.id, mentionedUser.id)) {
      const embed = new EmbedBuilder()
        .setColor(0xE74C3C)
        .setTitle('✅ Manager Removed!')
        .setDescription(`👤 **${mentionedUser.username}** is no longer a manager.`);
      await this.safeReply(message, { embeds: [embed] });
    } else {
      await this.safeReply(message, '❌ This user is not a manager!');
    }
  }

  private async handleListManagers(message: Message): Promise<void> {
    if (!message.guild) {
      await this.safeReply(message, '❌ This command can only be used in a server!');
      return;
    }

    if (!message.guild.ownerId || message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can view managers!');
      return;
    }

    const managers = this.dataManager.getManagers(message.guild.id);
    
    const embed = new EmbedBuilder()
      .setColor(0x3498DB)
      .setTitle('👥 Server Managers')
      .setDescription(
        managers.length > 0 
          ? `✨ Current managers:\n\n` + managers.map((id, i) => `${i + 1}. <@${id}>`).join('\n')
          : '📭 No managers assigned yet!\n\n💡 Use `?addmanager @user` to add one!'
      )
      .setFooter({ text: 'Managers can use all owner commands' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleLootboxCommand(message: Message, args: string[]): Promise<void> {
    if (args.length < 1) {
      await this.safeReply(message, 'Usage: `?lootbox open <name>` or `?lootbox open all`');
      return;
    }

    const subcommand = args[0].toLowerCase();

    if (subcommand === 'open') {
      if (args.length < 2) {
        await this.safeReply(message, 'Usage: `?lootbox open <name>` or `?lootbox open all`');
        return;
      }

      const target = args.slice(1).join(' ').toLowerCase();

      if (target === 'all') {
        await this.handleOpenAllLootboxes(message);
      } else {
        await this.handleOpenLootboxByName(message, args.slice(1).join(' '));
      }
    } else {
      await this.safeReply(message, '❌ Unknown subcommand! Use `?lootbox open <name>` or `?lootbox open all`');
    }
  }

  private async handleOpenLootboxByName(message: Message, searchTerm: string): Promise<void> {
    const user = this.dataManager.getUser(message.guild!.id, message.author.id);
    const lootboxes = this.dataManager.getLootboxes(message.guild!.id);
    
    if (lootboxes.length === 0) {
      await this.safeReply(message, '❌ No lootboxes available! Ask an admin to create some.');
      return;
    }

    const lootbox = this.findBestMatch(searchTerm, lootboxes);
    
    if (!lootbox) {
      const suggestions = lootboxes.slice(0, 3).map(l => l.name).join(', ');
      await this.safeReply(message, `❌ Lootbox not found!\n\n💡 Available lootboxes: ${suggestions}\n\nUse \`?lootboxes\` to see all lootboxes.`);
      return;
    }

    const lootboxInInventory = `🎁 ${lootbox.name}`;
    const inventoryIndex = user.inventory.indexOf(lootboxInInventory);
    
    if (inventoryIndex === -1) {
      await this.safeReply(message, `❌ You don't have **${lootbox.name}** in your inventory!\n\n💡 Buy it first with \`?buy ${lootbox.name}\``);
      return;
    }

    if (lootbox.items.length === 0) {
      await this.safeReply(message, '❌ This lootbox is empty! Ask an admin to add items to it.');
      return;
    }

    user.inventory.splice(inventoryIndex, 1);

    const totalChance = lootbox.items.reduce((sum: number, item: LootboxItem) => sum + item.chance, 0);
    const roll = Math.random() * totalChance;
    
    let currentChance = 0;
    let wonItem: LootboxItem | null = null;
    
    for (const item of lootbox.items) {
      currentChance += item.chance;
      if (roll <= currentChance) {
        wonItem = item;
        break;
      }
    }

    if (wonItem) {
      this.dataManager.addToInventory(message.guild!.id, message.author.id, wonItem.name);
      
      const embed = new EmbedBuilder()
        .setColor(0xFFD700)
        .setTitle('🎉 Lootbox Opened!')
        .setDescription(`🎁 You opened **${lootbox.name}**!\n\n✨🎊 **You won: ${wonItem.name}** 🎊✨\n\n🎒 The item has been added to your inventory!`)
        .setFooter({ text: `Keep opening for more! 🎲` });

      await this.safeReply(message, { embeds: [embed] });
    } else {
      await this.safeReply(message, '❌ Something went wrong with the lootbox!');
    }
  }

  private async handleOpenAllLootboxes(message: Message): Promise<void> {
    const user = this.dataManager.getUser(message.guild!.id, message.author.id);
    const lootboxes = this.dataManager.getLootboxes(message.guild!.id);
    
    if (lootboxes.length === 0) {
      await this.safeReply(message, '❌ No lootboxes available! Ask an admin to create some.');
      return;
    }

    const lootboxesInInventory: { lootbox: Lootbox; inventoryItem: string }[] = [];
    
    for (const lootbox of lootboxes) {
      const lootboxItem = `🎁 ${lootbox.name}`;
      if (user.inventory.includes(lootboxItem) && lootbox.items.length > 0) {
        lootboxesInInventory.push({ lootbox, inventoryItem: lootboxItem });
      }
    }
    
    if (lootboxesInInventory.length === 0) {
      await this.safeReply(message, `❌ You don't have any lootboxes in your inventory!\n\n💡 Buy some with \`?buy <lootbox_name>\` or use \`?shop\` to see what's available.`);
      return;
    }

    const openedBoxes: { name: string; item: string }[] = [];

    for (const { lootbox, inventoryItem } of lootboxesInInventory) {
      const currentUser = this.dataManager.getUser(message.guild!.id, message.author.id);
      const inventoryIndex = currentUser.inventory.indexOf(inventoryItem);
      
      if (inventoryIndex === -1) {
        continue;
      }

      currentUser.inventory.splice(inventoryIndex, 1);

      const totalChance = lootbox.items.reduce((sum: number, item: LootboxItem) => sum + item.chance, 0);
      const roll = Math.random() * totalChance;
      
      let currentChance = 0;
      let wonItem: LootboxItem | null = null;
      
      for (const item of lootbox.items) {
        currentChance += item.chance;
        if (roll <= currentChance) {
          wonItem = item;
          break;
        }
      }

      if (wonItem) {
        this.dataManager.addToInventory(message.guild!.id, message.author.id, wonItem.name);
        openedBoxes.push({ name: lootbox.name, item: wonItem.name });
      }
    }

    if (openedBoxes.length === 0) {
      await this.safeReply(message, '❌ No lootboxes could be opened!');
      return;
    }
    
    const itemsList = openedBoxes.map((box, i) => `${i + 1}. 🎁 **${box.name}** → ✨ ${box.item}`).join('\n');
    
    const embed = new EmbedBuilder()
      .setColor(0xFFD700)
      .setTitle('🎊 Mass Lootbox Opening!')
      .setDescription(`🎉 You opened **${openedBoxes.length}** lootbox${openedBoxes.length !== 1 ? 'es' : ''}!\n\n${itemsList}`)
      .setFooter({ text: `All items added to inventory! 🎒` });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleGiftLootbox(message: Message, args: string[]): Promise<void> {
    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can gift lootboxes!');
      return;
    }

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: `?giftlootbox @user <lootbox_name>`');
      return;
    }

    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      await this.safeReply(message, '❌ Please mention a valid user!');
      return;
    }

    if (targetUser.bot) {
      await this.safeReply(message, '❌ You cannot gift lootboxes to bots!');
      return;
    }

    const lootboxName = args.slice(1).join(' ');
    const lootboxes = this.dataManager.getLootboxes(message.guild!.id);
    
    if (lootboxes.length === 0) {
      await this.safeReply(message, '❌ No lootboxes available! Create some first with `?createlootbox`.');
      return;
    }

    const lootbox = this.findBestMatch(lootboxName, lootboxes);
    
    if (!lootbox) {
      const suggestions = lootboxes.slice(0, 3).map(l => l.name).join(', ');
      await this.safeReply(message, `❌ Lootbox not found!\n\n💡 Available lootboxes: ${suggestions}`);
      return;
    }

    if (lootbox.items.length === 0) {
      await this.safeReply(message, '❌ This lootbox is empty! Add items to it first.');
      return;
    }

    this.dataManager.addToInventory(message.guild!.id, targetUser.id, `🎁 ${lootbox.name}`);
    
    const embed = new EmbedBuilder()
      .setColor(0x9B59B6)
      .setTitle('🎁 Lootbox Gifted!')
      .setDescription(`✨ ${message.author} gifted **${lootbox.name}** to ${targetUser}!\n\n🎒 It has been added to their inventory.\n💡 They can open it with \`?lootbox open ${lootbox.name}\``)
      .setFooter({ text: `Gifted by ${message.author.username} | Free gift - no currency spent! 💝` });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleAFK(message: Message): Promise<void> {
    const user = this.dataManager.getUser(message.guild!.id, message.author.id);
    
    if (user.afkStartTime) {
      await this.safeReply(message, '❌ You are already AFK!');
      return;
    }

    user.afkStartTime = Date.now();
    this.dataManager.updateUser(message.guild!.id, message.author.id, { afkStartTime: user.afkStartTime });
    
    const embed = new EmbedBuilder()
      .setColor(0x95A5A6)
      .setTitle('💤 AFK Mode Activated')
      .setDescription(`😴 ${message.author.username} is now AFK!\n\n💰 You'll earn **3 currency/second** while away.\n⏰ **Max AFK duration:** 3 days\n\n💡 Send any message to return and collect your earnings!`)
      .setFooter({ text: 'AFK earnings are not affected by boost multipliers' });

    await this.safeReply(message, { embeds: [embed] });
  }

  public checkAFKReturn(guildId: string, userId: string): { wasAFK: boolean; earned: number; duration: number } {
    const user = this.dataManager.getUser(guildId, userId);
    
    if (!user.afkStartTime) {
      return { wasAFK: false, earned: 0, duration: 0 };
    }

    const rawDuration = Math.floor((Date.now() - user.afkStartTime) / 1000);
    const afkDuration = Math.min(rawDuration, 259200); // Max 3 days (259200 seconds)
    const earnedAmount = afkDuration * 3; // 3 currency per second
    
    user.balance += earnedAmount;
    user.afkStartTime = undefined;
    this.dataManager.updateUser(guildId, userId, { afkStartTime: undefined });
    
    return { wasAFK: true, earned: earnedAmount, duration: afkDuration };
  }

  private async handleDeleteAllItems(message: Message): Promise<void> {
    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can delete all items!');
      return;
    }

    const customItems = this.dataManager.getCustomShopItems(message.guild!.id);
    const lootboxes = this.dataManager.getLootboxes(message.guild!.id);
    const roleItems = this.dataManager.getRoleShopItems(message.guild!.id);
    const rotatingItems = this.dataManager.getRotatingShopItems(message.guild!.id);
    
    if (customItems.length === 0 && lootboxes.length === 0 && roleItems.length === 0 && rotatingItems.length === 0) {
      await this.safeReply(message, '❌ There are no custom items, roles, or lootboxes to delete!');
      return;
    }

    for (const item of customItems) {
      this.dataManager.removeCustomShopItem(message.guild!.id, item.id);
    }

    for (const lootbox of lootboxes) {
      this.dataManager.removeLootbox(message.guild!.id, lootbox.id);
    }

    for (const roleItem of roleItems) {
      this.dataManager.removeRoleShopItem(message.guild!.id, roleItem.roleId);
    }

    for (const rotatingItem of rotatingItems) {
      this.dataManager.removeRotatingShopItem(message.guild!.id, rotatingItem.id);
    }

    const embed = new EmbedBuilder()
      .setColor(0xE74C3C)
      .setTitle('🗑️ All Items Deleted!')
      .setDescription(
        `✅ Successfully deleted:\n\n` +
        `🛍️ **${customItems.length}** custom shop item(s)\n` +
        `🎁 **${lootboxes.length}** lootbox(es)\n` +
        `🎭 **${roleItems.length}** role shop item(s)\n` +
        `🔄 **${rotatingItems.length}** rotating shop item(s)\n\n` +
        `💡 Default shop items (boosts) are still available.`
      )
      .setFooter({ text: 'This action cannot be undone!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleBan(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can ban users!');
      return;
    }

    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?ban <@user>');
      return;
    }

    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      await this.safeReply(message, '❌ Please mention a valid user!');
      return;
    }

    if (targetUser.id === message.author.id) {
      await this.safeReply(message, '❌ You cannot ban yourself!');
      return;
    }

    if (this.dataManager.banUser(message.guild.id, targetUser.id)) {
      const embed = new EmbedBuilder()
        .setColor(0xE74C3C)
        .setTitle('🚫 User Banned')
        .setDescription(`${targetUser} has been banned from using this bot.\n\n💡 Use \`?unban @user\` to remove the ban.`);

      await this.safeReply(message, { embeds: [embed] });
    } else {
      await this.safeReply(message, '❌ User is already banned!');
    }
  }

  private async handleUnban(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can unban users!');
      return;
    }

    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?unban <@user>');
      return;
    }

    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      await this.safeReply(message, '❌ Please mention a valid user!');
      return;
    }

    if (this.dataManager.unbanUser(message.guild.id, targetUser.id)) {
      const embed = new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('✅ User Unbanned')
        .setDescription(`${targetUser} can now use this bot again.`);

      await this.safeReply(message, { embeds: [embed] });
    } else {
      await this.safeReply(message, '❌ User is not banned!');
    }
  }

  private async handleClearInventory(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can clear inventories!');
      return;
    }

    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?clearinventory <@user>');
      return;
    }

    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      await this.safeReply(message, '❌ Please mention a valid user!');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, targetUser.id);
    const itemCount = user.inventory.length;
    const balance = user.balance;

    if (itemCount === 0 && balance === 0) {
      await this.safeReply(message, `❌ ${targetUser.username} already has no items or currency!`);
      return;
    }

    this.dataManager.clearInventory(message.guild.id, targetUser.id);
    
    const embed = new EmbedBuilder()
      .setColor(0xE67E22)
      .setTitle('🗑️ User Reset')
      .setDescription(`**${targetUser.username}** has been reset:\n\n💰 Currency: \`${balance.toLocaleString()}\` → \`0\`\n🎒 Items: \`${itemCount}\` → \`0\``)
      .setFooter({ text: 'This action cannot be undone!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleMultiPurchase(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can configure multi-purchase settings!');
      return;
    }

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?multipurchase <item name> <on|off>');
      return;
    }

    const setting = args.pop()?.toLowerCase();
    if (setting !== 'on' && setting !== 'off') {
      await this.safeReply(message, '❌ Please specify either `on` or `off`!');
      return;
    }

    const searchTerm = args.join(' ');
    const customItems = this.dataManager.getCustomShopItems(message.guild.id);
    const defaultItems = this.dataManager.getDefaultShopItems(message.guild.id);
    
    const customItem = this.findBestMatch(searchTerm, customItems);
    const defaultItem = this.findBestMatch(searchTerm, defaultItems);
    
    const item = customItem || defaultItem;
    const itemId = item?.id;
    
    if (!item || !itemId) {
      await this.safeReply(message, '❌ Item not found! Use `?shop` to see available items.');
      return;
    }

    const multiPurchase = setting === 'on';
    
    if (this.dataManager.setItemMultiPurchase(message.guild.id, itemId, multiPurchase)) {
      const itemEmoji = customItem ? customItem.emoji : '⚡';
      const embed = new EmbedBuilder()
        .setColor(multiPurchase ? 0x2ECC71 : 0xE67E22)
        .setTitle('⚙️ Multi-Purchase Updated')
        .setDescription(`${itemEmoji} **${item.name}**\n\n${multiPurchase ? '✅ Multi-purchase **enabled**' : '🔒 Multi-purchase **disabled**'}\n\nUsers can ${multiPurchase ? 'now buy this item multiple times' : 'only buy this item once'}.`);

      await this.safeReply(message, { embeds: [embed] });
    } else {
      await this.safeReply(message, '❌ Failed to update item settings!');
    }
  }

  private async handleSetItemPrice(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can edit item prices!');
      return;
    }

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?setprice <item name> <price>\nExample: ?setprice 2x boost 10000');
      return;
    }

    const price = parseInt(args[args.length - 1]);
    if (isNaN(price) || price < 0) {
      await this.safeReply(message, '❌ Please provide a valid positive price!');
      return;
    }

    const searchTerm = args.slice(0, -1).join(' ');
    const customItems = this.dataManager.getCustomShopItems(message.guild.id);
    const defaultItems = this.dataManager.getDefaultShopItems(message.guild.id);
    
    const customItem = this.findBestMatch(searchTerm, customItems);
    const defaultItem = this.findBestMatch(searchTerm, defaultItems);
    
    const item = customItem || defaultItem;
    const itemId = item?.id;
    
    if (!item || !itemId) {
      await this.safeReply(message, '❌ Item not found! Use `?shop` to see available items.');
      return;
    }

    if (this.dataManager.setItemPrice(message.guild.id, itemId, price)) {
      const itemEmoji = customItem?.emoji ?? (defaultItem?.type === 'boost' ? '⚡' : '💰');
      const embed = new EmbedBuilder()
        .setColor(0x3498DB)
        .setTitle('💰 Price Updated')
        .setDescription(`${itemEmoji} **${item.name}**\n\n**New price:** ${price.toLocaleString()} currency\n\nThis custom price will be shown in the shop and used for purchases.`);

      await this.safeReply(message, { embeds: [embed] });
    } else {
      await this.safeReply(message, '❌ Failed to update item price!');
    }
  }

  private async handleToggleCoinflip(message: Message): Promise<void> {
    if (!message.guild) return;
    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can toggle coinflip!');
      return;
    }

    const currentStatus = this.dataManager.isCoinflipEnabled(message.guild.id);
    const newStatus = !currentStatus;
    this.dataManager.setCoinflipEnabled(message.guild.id, newStatus);

    const embed = new EmbedBuilder()
      .setColor(newStatus ? 0x2ECC71 : 0xE74C3C)
      .setTitle('🎲 Coinflip Status Updated')
      .setDescription(
        `${newStatus ? '✅ **Coinflip is now ENABLED**' : '🔒 **Coinflip is now DISABLED**'}\n\n` +
        `${newStatus ? 'Users can now gamble with ?coinflip' : 'Users can no longer use ?coinflip'}`
      )
      .setFooter({ text: newStatus ? 'Happy gambling!' : 'Gambling disabled in this server' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleResetServer(message: Message): Promise<void> {
    if (!message.guild) return;
    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can reset the server!');
      return;
    }

    const allUsers = this.dataManager.getAllUsers(message.guild.id);
    const userCount = Object.keys(allUsers).length;

    if (userCount === 0) {
      await this.safeReply(message, '❌ There are no users to reset in this server!');
      return;
    }

    const confirmEmbed = new EmbedBuilder()
      .setColor(0xE74C3C)
      .setTitle('⚠️ RESET SERVER - CONFIRMATION REQUIRED')
      .setDescription(
        `🚨 **WARNING:** This will permanently delete ALL user data in this server!\n\n` +
        `**What will be reset:**\n` +
        `💰 All balances (${userCount} users)\n` +
        `📦 All inventories\n` +
        `⚡ All boosts\n` +
        `📊 All message counts\n` +
        `🎯 All streaks and cooldowns\n` +
        `📜 All purchase history\n\n` +
        `**Type \`CONFIRM RESET\` within 30 seconds to proceed.**`
      )
      .setFooter({ text: '⚠️ THIS ACTION CANNOT BE UNDONE!' });

    await this.safeReply(message, { embeds: [confirmEmbed] });

    const filter = (m: Message) => m.author.id === message.author.id && m.content === 'CONFIRM RESET';
    
    try {
      const channel = message.channel;
      if (!('awaitMessages' in channel)) return;
      
      const collected = await channel.awaitMessages({
        filter,
        max: 1,
        time: 30000,
        errors: ['time']
      });

      if (collected.size > 0) {
        this.dataManager.resetAllUsers(message.guild.id);
        this.dataManager.resetPromotionPurchaseCount(message.guild.id);

        const successEmbed = new EmbedBuilder()
          .setColor(0x2ECC71)
          .setTitle('✅ Server Reset Complete!')
          .setDescription(
            `🗑️ **Successfully reset ${userCount} users**\n\n` +
            `All user progress has been wiped from this server.\n` +
            `Promotion prices have been reset to base price.\n` +
            `Users can start fresh with ?balance or by sending messages!`
          )
          .setFooter({ text: 'Server reset completed successfully!' });

        await this.safeReply(message, { embeds: [successEmbed] });
      }
    } catch (error) {
      const cancelEmbed = new EmbedBuilder()
        .setColor(0x95A5A6)
        .setTitle('❌ Server Reset Cancelled')
        .setDescription('Reset timed out or was cancelled. No data was deleted.')
        .setFooter({ text: 'Server data remains unchanged' });

      await this.safeReply(message, { embeds: [cancelEmbed] });
    }
  }

  private async handleFixBoosts(message: Message): Promise<void> {
    if (!message.guild) return;
    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can fix boosts!');
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(0xFFAA00)
      .setTitle('🔍 Scanning for boost issues...')
      .setDescription('Checking all users who purchased boosts...');

    const statusMsg = await this.safeReply(message, { embeds: [embed] });

    let fixedCount = 0;
    let checkedCount = 0;
    const fixedUsers: string[] = [];

    const guildData = this.dataManager.getAllUsers(message.guild.id);
    const users = Object.keys(guildData);

    for (const userId of users) {
      const user = this.dataManager.getUser(message.guild.id, userId);
      if (!user.purchasedItems || user.purchasedItems.length === 0) continue;

      checkedCount++;
      let highestBoost = 1;

      if (user.purchasedItems.includes('boost_100x')) {
        highestBoost = 100;
      } else if (user.purchasedItems.includes('boost_10x')) {
        highestBoost = 10;
      } else if (user.purchasedItems.includes('boost_2x')) {
        highestBoost = 2;
      } else if (user.purchasedItems.includes('boost_1.5x')) {
        highestBoost = 1.5;
      }

      if (highestBoost > 1 && user.boost !== highestBoost) {
        const member = await message.guild.members.fetch(userId).catch(() => null);
        const username = member?.user.username || `User ${userId}`;
        fixedUsers.push(`${username}: ${user.boost}x → ${highestBoost}x`);
        user.boost = highestBoost;
        fixedCount++;
      }
    }

    if (fixedCount > 0) {
      this.dataManager.saveData();
    }

    const resultEmbed = new EmbedBuilder()
      .setColor(fixedCount > 0 ? 0x2ECC71 : 0x95A5A6)
      .setTitle(fixedCount > 0 ? '✅ Boost Fix Complete!' : '✅ No Issues Found')
      .setDescription(
        `📊 **Scan Results:**\n` +
        `👥 Users checked: ${checkedCount}\n` +
        `🔧 Boosts fixed: ${fixedCount}\n\n` +
        (fixedCount > 0 
          ? `**Fixed Users:**\n${fixedUsers.map((u, i) => `${i+1}. ${u}`).join('\n')}\n\n✅ All boost values have been corrected!`
          : `All users who own boosts already have correct boost values!`)
      )
      .setFooter({ text: 'Boost fix completed' });

    await statusMsg.edit({ embeds: [resultEmbed] });
  }

  private async handleFixPromotionCount(message: Message): Promise<void> {
    if (!message.guild) return;
    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can fix promotion counts!');
      return;
    }

    const config = this.dataManager.getStaffShopConfig(message.guild.id);
    const oldCount = config.totalPurchaseCount;
    const oldPrice = this.dataManager.getCurrentPromotionPrice(message.guild.id, message.author.id);

    const actualCount = this.dataManager.recalculatePromotionPurchaseCount(message.guild.id);
    const newPrice = this.dataManager.getCurrentPromotionPrice(message.guild.id, message.author.id);

    const embed = new EmbedBuilder()
      .setColor(oldCount !== actualCount ? 0x2ECC71 : 0x95A5A6)
      .setTitle(oldCount !== actualCount ? '✅ Promotion Count Fixed!' : '✅ No Issues Found')
      .setDescription(
        `🔍 **Scan Results:**\n\n` +
        `**Old Count:** ${oldCount} purchases\n` +
        `**Actual Count:** ${actualCount} purchases\n` +
        `**Old Price:** ${oldPrice.toLocaleString()} 💰\n` +
        `**New Price:** ${newPrice.toLocaleString()} 💰\n\n` +
        `**Base Price:** ${config.basePrice.toLocaleString()} 💰\n` +
        `**Price Formula:** Base × 2^${actualCount} = ${newPrice.toLocaleString()}\n\n` +
        (oldCount !== actualCount 
          ? `✅ Promotion count has been corrected from historical purchase data!`
          : `The promotion count was already accurate.`)
      )
      .setFooter({ text: 'Promotion count recalculated from purchase history' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleUse(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?use <item name>');
      return;
    }

    // Check if using promotion
    if (args[0].toLowerCase() === 'promotion') {
      await this.handleUsePromotion(message);
      return;
    }

    // Check if it's a token command
    if (args[0].toLowerCase() === 'token') {
      if (args.length < 2) {
        await this.safeReply(message, '❌ Usage: `?use token timeout @user`, `?use token changename @user <new name>`, `?use token slowmode #channel`, `?use token voicemute @user`, or `?use token rolecolor <color>`');
        return;
      }

      const tokenType = args[1].toLowerCase();
      if (tokenType === 'timeout' || tokenType === 'mute') {
        await this.handleTokenMute(message, args.slice(2));
        return;
      } else if (tokenType === 'changename' || tokenType === 'nickname') {
        await this.handleTokenChangeName(message, args.slice(2));
        return;
      } else if (tokenType === 'slowmode') {
        await this.handleTokenSlowmode(message, args.slice(2));
        return;
      } else if (tokenType === 'voicemute') {
        await this.handleTokenVoiceMute(message, args.slice(2));
        return;
      } else if (tokenType === 'rolecolor') {
        await this.handleTokenRoleColor(message, args.slice(2));
        return;
      } else {
        await this.safeReply(message, '❌ Invalid token type! Use `timeout`, `changename`, `slowmode`, `voicemute`, or `rolecolor`');
        return;
      }
    }

    const searchTerm = args.join(' ');
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    
    if (user.inventory.length === 0) {
      await this.safeReply(message, '❌ Your inventory is empty! Buy items from the shop first.');
      return;
    }

    // Find best matching item in inventory
    let bestMatch: string | null = null;
    let bestScore = 0;

    for (const item of user.inventory) {
      const itemName = item.replace(/^[^\s]+\s/, '').toLowerCase(); // Remove emoji prefix
      const search = searchTerm.toLowerCase();
      let score = 0;

      if (itemName === search) score = 1000;
      else if (itemName.includes(search)) score = 500;
      else if (search.includes(itemName)) score = 300;

      if (score > bestScore) {
        bestScore = score;
        bestMatch = item;
      }
    }

    if (!bestMatch || bestScore === 0) {
      await this.safeReply(message, `❌ Item not found in your inventory!\n\n💡 Use \`?inventory\` to see your items.`);
      return;
    }

    // Remove item from inventory
    if (this.dataManager.removeFromInventory(message.guild.id, message.author.id, bestMatch)) {
      const embed = new EmbedBuilder()
        .setColor(0x3498DB)
        .setTitle('✅ Item Used!')
        .setDescription(`🎉 You used: **${bestMatch}**\n\n🎒 It has been removed from your inventory.`)
        .setFooter({ text: `Items remaining: ${user.inventory.length - 1}` });

      await this.safeReply(message, { embeds: [embed] });
    } else {
      await this.safeReply(message, '❌ Failed to use item!');
    }
  }

  private async handleTokenMute(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      await this.safeReply(message, '❌ Please mention a user to timeout! Usage: `?use token timeout @user`');
      return;
    }

    if (targetUser.id === message.author.id) {
      await this.safeReply(message, '❌ You cannot mute yourself!');
      return;
    }

    if (targetUser.bot) {
      await this.safeReply(message, '❌ You cannot mute bots!');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    if (!user.inventory.includes('token_mute')) {
      await this.safeReply(message, '❌ You don\'t have a Timeout Token! Buy one from the shop first.');
      return;
    }

    const tokenConfig = this.dataManager.getRotatingShopConfig(message.guild.id);
    let duration = tokenConfig.muteTokenDuration;
    
    // 22% chance for 10 seconds instead of 5 seconds
    const isLongerDuration = Math.random() < 0.22;
    if (isLongerDuration && duration === 5000) {
      duration = 10000;
    }
    
    const durationText = duration >= 60000
      ? `${Math.floor(duration / 60000)} minute${Math.floor(duration / 60000) !== 1 ? 's' : ''}`
      : `${Math.floor(duration / 1000)} second${Math.floor(duration / 1000) !== 1 ? 's' : ''}`;

    try {
      const member = await message.guild.members.fetch(targetUser.id);
      await member.timeout(duration, `Timed out by ${message.author.tag} using Timeout Token`);

      this.dataManager.removeFromInventory(message.guild.id, message.author.id, 'token_mute');

      const embed = new EmbedBuilder()
        .setColor(isLongerDuration ? 0xFF6600 : 0xFF0000)
        .setTitle(isLongerDuration ? '🔇 Timeout Token Activated! 🎰 BONUS!' : '🔇 Timeout Token Activated!')
        .setDescription(`✅ ${targetUser} has been timed out for **${durationText}**!\n\n⏱️ Expires: <t:${Math.floor((Date.now() + duration) / 1000)}:R>${isLongerDuration ? '\n\n🎲 **Lucky!** You got a bonus duration!' : ''}`)
        .setFooter({ text: `Activated by ${message.author.tag}` });

      await this.safeReply(message, { embeds: [embed] });
    } catch (error) {
      await this.safeReply(message, '❌ Failed to timeout user! I may not have permission or the user may have a higher role than me.');
    }
  }

  private async handleTokenChangeName(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      await this.safeReply(message, '❌ Please mention a user! Usage: `?use token changename @user <new name>`');
      return;
    }

    if (args.length < 2) {
      await this.safeReply(message, '❌ Please provide a new nickname! Usage: `?use token changename @user <new name>`');
      return;
    }

    if (targetUser.bot) {
      await this.safeReply(message, '❌ You cannot change bot nicknames!');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    if (!user.inventory.includes('token_nickname')) {
      await this.safeReply(message, '❌ You don\'t have a Nickname Token! Buy one from the shop first.');
      return;
    }

    const newNickname = args.slice(1).join(' ');
    if (newNickname.length > 32) {
      await this.safeReply(message, '❌ Nickname must be 32 characters or less!');
      return;
    }

    const tokenConfig = this.dataManager.getRotatingShopConfig(message.guild.id);
    const duration = tokenConfig.nicknameTokenDuration;
    
    const durationText = duration >= 60000
      ? `${Math.floor(duration / 60000)} minute${Math.floor(duration / 60000) !== 1 ? 's' : ''}`
      : `${Math.floor(duration / 1000)} second${Math.floor(duration / 1000) !== 1 ? 's' : ''}`;

    try {
      const member = await message.guild.members.fetch(targetUser.id);
      const originalNickname = member.nickname || member.user.username;

      await member.setNickname(newNickname);

      this.dataManager.removeFromInventory(message.guild.id, message.author.id, 'token_nickname');

      const effectId = `${message.guild.id}-${targetUser.id}-${Date.now()}`;
      this.dataManager.addActiveEffect({
        id: effectId,
        guildId: message.guild.id,
        targetUserId: targetUser.id,
        type: 'nickname',
        appliedBy: message.author.id,
        expiresAt: Date.now() + duration,
        originalNickname: originalNickname
      });

      const embed = new EmbedBuilder()
        .setColor(0x9B59B6)
        .setTitle('📝 Nickname Token Activated!')
        .setDescription(`✅ Changed ${targetUser}'s nickname to **${newNickname}**!\n\n⏱️ Will revert in **${durationText}**\n🔙 Original: **${originalNickname}**`)
        .setFooter({ text: `Activated by ${message.author.tag}` });

      await this.safeReply(message, { embeds: [embed] });

      setTimeout(async () => {
        try {
          const stillMember = await message.guild!.members.fetch(targetUser.id);
          await stillMember.setNickname(originalNickname);
          this.dataManager.removeActiveEffect(effectId);
        } catch (error) {
          this.dataManager.removeActiveEffect(effectId);
        }
      }, duration);
    } catch (error) {
      await this.safeReply(message, '❌ Failed to change nickname! I may not have permission or the user may have a higher role than me.');
    }
  }

  private async handleTokenSlowmode(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const targetChannel = message.mentions.channels.first() || message.channel;
    if (!targetChannel || !targetChannel.isTextBased()) {
      await this.safeReply(message, '❌ Please mention a text channel! Usage: `?use token slowmode #channel`');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    if (!user.inventory.includes('token_slowmode')) {
      await this.safeReply(message, '❌ You don\'t have a Slowmode Token! Buy one from the shop first.');
      return;
    }

    const tokenConfig = this.dataManager.getRotatingShopConfig(message.guild.id);
    const duration = tokenConfig.slowmodeTokenDuration;
    
    const durationText = duration >= 60000
      ? `${Math.floor(duration / 60000)} minute${Math.floor(duration / 60000) !== 1 ? 's' : ''}`
      : `${Math.floor(duration / 1000)} second${Math.floor(duration / 1000) !== 1 ? 's' : ''}`;

    try {
      const channel = targetChannel as any;
      const originalSlowmode = channel.rateLimitPerUser || 0;
      
      await channel.setRateLimitPerUser(21600, `Slowmode set by ${message.author.tag} using Slowmode Token`);

      this.dataManager.removeFromInventory(message.guild.id, message.author.id, 'token_slowmode');

      const effectId = `${message.guild.id}-${channel.id}-${Date.now()}`;
      this.dataManager.addActiveEffect({
        id: effectId,
        guildId: message.guild.id,
        targetUserId: channel.id,
        type: 'slowmode',
        appliedBy: message.author.id,
        expiresAt: Date.now() + duration,
        originalSlowmode: originalSlowmode
      });

      const embed = new EmbedBuilder()
        .setColor(0xE67E22)
        .setTitle('⏱️ Slowmode Token Activated!')
        .setDescription(`✅ Set maximum slowmode (6 hours) on ${targetChannel}!\n\n⏱️ Will revert in **${durationText}**\n🔙 Original slowmode: **${originalSlowmode}s**`)
        .setFooter({ text: `Activated by ${message.author.tag}` });

      await this.safeReply(message, { embeds: [embed] });

      setTimeout(async () => {
        try {
          const stillChannel = message.guild!.channels.cache.get(channel.id) as any;
          if (stillChannel) {
            await stillChannel.setRateLimitPerUser(originalSlowmode);
          }
          this.dataManager.removeActiveEffect(effectId);
        } catch (error) {
          this.dataManager.removeActiveEffect(effectId);
        }
      }, duration);
    } catch (error) {
      await this.safeReply(message, '❌ Failed to set slowmode! I may not have permission to manage this channel.');
    }
  }

  private async handleTokenVoiceMute(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      await this.safeReply(message, '❌ Please mention a user to voice mute! Usage: `?use token voicemute @user`');
      return;
    }

    if (targetUser.id === message.author.id) {
      await this.safeReply(message, '❌ You cannot voice mute yourself!');
      return;
    }

    if (targetUser.bot) {
      await this.safeReply(message, '❌ You cannot voice mute bots!');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    if (!user.inventory.includes('token_voice_mute')) {
      await this.safeReply(message, '❌ You don\'t have a Voice Mute Token! Buy one from the shop first.');
      return;
    }

    const tokenConfig = this.dataManager.getRotatingShopConfig(message.guild.id);
    const duration = tokenConfig.voiceMuteTokenDuration;
    
    const durationText = duration >= 60000
      ? `${Math.floor(duration / 60000)} minute${Math.floor(duration / 60000) !== 1 ? 's' : ''}`
      : `${Math.floor(duration / 1000)} second${Math.floor(duration / 1000) !== 1 ? 's' : ''}`;

    try {
      const member = await message.guild.members.fetch(targetUser.id);
      
      await member.voice.setMute(true, `Voice muted by ${message.author.tag} using Voice Mute Token`);

      this.dataManager.removeFromInventory(message.guild.id, message.author.id, 'token_voice_mute');

      const effectId = `${message.guild.id}-${targetUser.id}-${Date.now()}`;
      this.dataManager.addActiveEffect({
        id: effectId,
        guildId: message.guild.id,
        targetUserId: targetUser.id,
        type: 'voice_mute',
        appliedBy: message.author.id,
        expiresAt: Date.now() + duration
      });

      const embed = new EmbedBuilder()
        .setColor(0xE74C3C)
        .setTitle('🎤 Voice Mute Token Activated!')
        .setDescription(`✅ ${targetUser} has been server-muted in voice!\n\n⏱️ Will unmute in **${durationText}**\n🔇 They cannot speak in any voice channel`)
        .setFooter({ text: `Activated by ${message.author.tag}` });

      await this.safeReply(message, { embeds: [embed] });

      setTimeout(async () => {
        try {
          const stillMember = await message.guild!.members.fetch(targetUser.id);
          await stillMember.voice.setMute(false);
          this.dataManager.removeActiveEffect(effectId);
        } catch (error) {
          this.dataManager.removeActiveEffect(effectId);
        }
      }, duration);
    } catch (error) {
      await this.safeReply(message, '❌ Failed to voice mute user! They may not be in a voice channel or I may not have permission.');
    }
  }

  private async handleTokenRoleColor(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (args.length < 1) {
      await this.safeReply(message, '❌ Please provide a color! Usage: `?use token rolecolor <hex color>`\nExample: `?use token rolecolor #FF5733`');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    if (!user.inventory.includes('token_role_color')) {
      await this.safeReply(message, '❌ You don\'t have a Role Color Token! Buy one from the shop first.');
      return;
    }

    let color = args[0].toUpperCase();
    if (!color.startsWith('#')) {
      color = '#' + color;
    }

    if (!/^#[0-9A-F]{6}$/i.test(color)) {
      await this.safeReply(message, '❌ Invalid color format! Use hex format like `#FF5733` or `FF5733`');
      return;
    }

    const tokenConfig = this.dataManager.getRotatingShopConfig(message.guild.id);
    const duration = tokenConfig.roleColorTokenDuration;
    
    const durationText = duration >= 60000
      ? `${Math.floor(duration / 60000)} minute${Math.floor(duration / 60000) !== 1 ? 's' : ''}`
      : `${Math.floor(duration / 1000)} second${Math.floor(duration / 1000) !== 1 ? 's' : ''}`;

    try {
      const member = await message.guild.members.fetch(message.author.id);
      
      const role = await message.guild.roles.create({
        name: `${message.author.username}'s Color`,
        color: color as any,
        reason: `Custom color role created by ${message.author.tag} using Role Color Token`
      });

      await member.roles.add(role);

      this.dataManager.removeFromInventory(message.guild.id, message.author.id, 'token_role_color');

      const effectId = `${message.guild.id}-${message.author.id}-${Date.now()}`;
      this.dataManager.addActiveEffect({
        id: effectId,
        guildId: message.guild.id,
        targetUserId: message.author.id,
        type: 'role_color',
        appliedBy: message.author.id,
        expiresAt: Date.now() + duration,
        customRoleId: role.id
      });

      const embed = new EmbedBuilder()
        .setColor(color as any)
        .setTitle('🎨 Role Color Token Activated!')
        .setDescription(`✅ Created custom colored role for you!\n\n🎨 **Color:** ${color}\n⏱️ **Duration:** ${durationText}\n🗑️ Role will be auto-deleted after`)
        .setFooter({ text: `Activated by ${message.author.tag}` });

      await this.safeReply(message, { embeds: [embed] });

      setTimeout(async () => {
        try {
          const stillRole = message.guild!.roles.cache.get(role.id);
          if (stillRole) {
            await stillRole.delete();
          }
          this.dataManager.removeActiveEffect(effectId);
        } catch (error) {
          this.dataManager.removeActiveEffect(effectId);
        }
      }, duration);
    } catch (error) {
      await this.safeReply(message, '❌ Failed to create role! I may not have permission to manage roles.');
    }
  }

  private async handleLeaderboard(message: Message): Promise<void> {
    if (!message.guild) return;

    const guildData = this.dataManager.getAllUsers(message.guild.id);
    const users = Object.values(guildData) as UserData[];
    
    const sorted = users.sort((a, b) => b.balance - a.balance).slice(0, 10);

    const embed = new EmbedBuilder()
      .setColor(0xFFD700)
      .setTitle('🏆 Server Leaderboard - Top 10')
      .setDescription(
        sorted.length > 0
          ? sorted.map((user, index) => {
              const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`;
              return `${medal} <@${user.userId}> - **${user.balance.toLocaleString()}** 💰 (${user.boost}x boost)`;
            }).join('\n')
          : 'No users yet! Start earning currency to appear on the leaderboard!'
      )
      .setFooter({ text: 'Keep earning to climb the ranks!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleDaily(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const now = Date.now();
    const DAY_MS = 24 * 60 * 60 * 1000;

    if (user.lastDaily && now - user.lastDaily < DAY_MS) {
      const timeLeft = DAY_MS - (now - user.lastDaily);
      const hours = Math.floor(timeLeft / (60 * 60 * 1000));
      const minutes = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));
      
      await this.safeReply(message, `⏰ Daily reward already claimed!\n\nCome back in **${hours}h ${minutes}m**`);
      return;
    }

    // Calculate streak
    const lastClaim = user.lastStreakClaim || 0;
    const daysSinceLastClaim = (now - lastClaim) / DAY_MS;
    
    let streak = user.dailyStreak || 0;
    if (daysSinceLastClaim <= 1.5) {
      streak += 1;
    } else {
      streak = 1;
    }

    const baseReward = 1000;
    const streakBonus = Math.min(streak * 100, 2000);
    const totalReward = baseReward + streakBonus;

    user.lastDaily = now;
    user.dailyStreak = streak;
    user.lastStreakClaim = now;
    
    this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, totalReward);
    const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('🎁 Daily Reward Claimed!')
      .setDescription(
        `✨ **Base reward:** ${baseReward.toLocaleString()} 💰\n` +
        `🔥 **Streak bonus:** ${streakBonus.toLocaleString()} 💰 (${streak} day${streak > 1 ? 's' : ''})\n\n` +
        `💵 **Total earned:** ${totalReward.toLocaleString()} 💰\n` +
        `💰 **New balance:** ${updatedUser.balance.toLocaleString()}`
      )
      .setFooter({ text: `Come back tomorrow to keep your streak! 🔥` });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleWork(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const now = Date.now();
    const HOUR_MS = 60 * 60 * 1000;

    if (user.lastWork && now - user.lastWork < HOUR_MS) {
      const timeLeft = HOUR_MS - (now - user.lastWork);
      const minutes = Math.floor(timeLeft / (60 * 1000));
      
      await this.safeReply(message, `⏰ You're tired! Rest for **${minutes} minute(s)** before working again.`);
      return;
    }

    const jobs = [
      { name: 'delivering packages', min: 100, max: 300 },
      { name: 'streaming', min: 150, max: 400 },
      { name: 'coding a website', min: 200, max: 500 },
      { name: 'mining crypto', min: 250, max: 600 },
      { name: 'trading stocks', min: 300, max: 700 }
    ];

    const job = jobs[Math.floor(Math.random() * jobs.length)];
    const reward = Math.floor(Math.random() * (job.max - job.min + 1)) + job.min;

    user.lastWork = now;
    this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, reward);
    const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);

    const embed = new EmbedBuilder()
      .setColor(0x3498DB)
      .setTitle('💼 Work Complete!')
      .setDescription(`You spent an hour **${job.name}** and earned **${reward.toLocaleString()}** 💰!\n\n💰 **New balance:** ${updatedUser.balance.toLocaleString()}`)
      .setFooter({ text: 'Come back in 1 hour to work again!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleCoinflip(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (!this.dataManager.isCoinflipEnabled(message.guild.id)) {
      await this.safeReply(message, '❌ Coinflip is currently disabled in this server!');
      return;
    }

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?coinflip <amount> <heads|tails>');
      return;
    }

    const amount = parseInt(args[0]);
    const choice = args[1].toLowerCase();
    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    if (isNaN(amount) || amount <= 0) {
      await this.safeReply(message, '❌ Please provide a valid positive amount!');
      return;
    }

    if (choice !== 'heads' && choice !== 'tails' && choice !== 'h' && choice !== 't') {
      await this.safeReply(message, '❌ Please choose **heads** or **tails** (or **h**/**t**)!');
      return;
    }

    if (amount > user.balance) {
      await this.safeReply(message, `❌ Insufficient funds! You only have **${user.balance.toLocaleString()}** 💰`);
      return;
    }

    // Normalize choice
    const userChoice = (choice === 'h' || choice === 'heads') ? 'HEADS' : 'TAILS';
    
    // Flip the coin
    const result = Math.random() < 0.5 ? 'HEADS' : 'TAILS';
    const won = userChoice === result;

    if (won) {
      this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, amount);
      const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);
      const embed = new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('🪙 Coinflip - YOU WON!')
        .setDescription(
          `🎯 **Your choice:** ${userChoice}\n` +
          `🪙 **Result:** ${result}\n\n` +
          `🎉 You guessed correctly!\n\n` +
          `💰 **Won:** +${amount.toLocaleString()}\n` +
          `💵 **New balance:** ${updatedUser.balance.toLocaleString()}`
        )
        .setFooter({ text: 'Lucky! Try again? Boosts don\'t apply to gambling!' });
      
      await this.safeReply(message, { embeds: [embed] });
    } else {
      this.dataManager.removeCurrency(message.guild.id, message.author.id, amount);
      const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);
      const embed = new EmbedBuilder()
        .setColor(0xE74C3C)
        .setTitle('🪙 Coinflip - YOU LOST!')
        .setDescription(
          `🎯 **Your choice:** ${userChoice}\n` +
          `🪙 **Result:** ${result}\n\n` +
          `😢 Wrong guess!\n\n` +
          `❌ **Lost:** -${amount.toLocaleString()}\n` +
          `💰 **New balance:** ${updatedUser.balance.toLocaleString()}`
        )
        .setFooter({ text: 'Better luck next time!' });
      
      await this.safeReply(message, { embeds: [embed] });
    }
  }

  private async handleGiveUser(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?give <@user> <amount>');
      return;
    }

    const targetUser = message.mentions.users.first();
    if (!targetUser || targetUser.bot) {
      await this.safeReply(message, '❌ Please mention a valid user (not a bot)!');
      return;
    }

    if (targetUser.id === message.author.id) {
      await this.safeReply(message, '❌ You cannot give currency to yourself!');
      return;
    }

    const parsedAmount = parseFloat(args[1]);
    const amount = Math.floor(parsedAmount);
    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    if (isNaN(parsedAmount) || parsedAmount <= 0 || !Number.isInteger(parsedAmount) || amount < 1) {
      await this.safeReply(message, '❌ Please provide a valid positive whole number!');
      return;
    }

    if (amount > user.balance) {
      await this.safeReply(message, `❌ Insufficient funds! You only have **${user.balance.toLocaleString()}** 💰`);
      return;
    }

    this.dataManager.removeCurrency(message.guild.id, message.author.id, amount);
    this.dataManager.addCurrencyRaw(message.guild.id, targetUser.id, amount);

    const embed = new EmbedBuilder()
      .setColor(0x9B59B6)
      .setTitle('💸 Currency Transferred!')
      .setDescription(`${message.author} gave **${amount.toLocaleString()}** 💰 to ${targetUser}!\n\n💰 **Your new balance:** ${(user.balance - amount).toLocaleString()}`)
      .setFooter({ text: 'Generous!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleStats(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const targetUser = args.length > 0 ? message.mentions.users.first() : message.author;
    if (!targetUser) {
      await this.safeReply(message, '❌ User not found!');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, targetUser.id);
    const guildData = this.dataManager.getAllUsers(message.guild.id);
    const allUsers = Object.values(guildData) as UserData[];
    const rank = allUsers.sort((a, b) => b.balance - a.balance).findIndex(u => u.userId === targetUser.id) + 1;

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle(`📊 Stats for ${targetUser.username}`)
      .addFields(
        { name: '💰 Balance', value: `${user.balance.toLocaleString()} currency`, inline: true },
        { name: '⚡ Boost', value: `${user.boost}x multiplier`, inline: true },
        { name: '🏆 Rank', value: `#${rank} / ${allUsers.length}`, inline: true },
        { name: '💬 Messages', value: `${user.messageCount.toLocaleString()}`, inline: true },
        { name: '🎒 Items', value: `${user.inventory.length}`, inline: true },
        { name: '🔥 Daily Streak', value: `${user.dailyStreak || 0} day(s)`, inline: true }
      )
      .setFooter({ text: 'Keep earning to improve your stats!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleCooldowns(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const now = Date.now();
    
    const cooldowns = [];
    
    if (user.lastDaily) {
      const timeLeft = 24 * 60 * 60 * 1000 - (now - user.lastDaily);
      if (timeLeft > 0) {
        const hours = Math.floor(timeLeft / (60 * 60 * 1000));
        const minutes = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));
        cooldowns.push(`🎁 **Daily:** ${hours}h ${minutes}m`);
      } else {
        cooldowns.push(`🎁 **Daily:** ✅ Ready!`);
      }
    } else {
      cooldowns.push(`🎁 **Daily:** ✅ Ready!`);
    }

    if (user.lastWork) {
      const timeLeft = 60 * 60 * 1000 - (now - user.lastWork);
      if (timeLeft > 0) {
        const minutes = Math.floor(timeLeft / (60 * 1000));
        cooldowns.push(`💼 **Work:** ${minutes}m`);
      } else {
        cooldowns.push(`💼 **Work:** ✅ Ready!`);
      }
    } else {
      cooldowns.push(`💼 **Work:** ✅ Ready!`);
    }

    if (user.lastWeekly) {
      const timeLeft = 7 * 24 * 60 * 60 * 1000 - (now - user.lastWeekly);
      if (timeLeft > 0) {
        const days = Math.floor(timeLeft / (24 * 60 * 60 * 1000));
        const hours = Math.floor((timeLeft % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
        cooldowns.push(`🎊 **Weekly:** ${days}d ${hours}h`);
      } else {
        cooldowns.push(`🎊 **Weekly:** ✅ Ready!`);
      }
    } else {
      cooldowns.push(`🎊 **Weekly:** ✅ Ready!`);
    }

    const embed = new EmbedBuilder()
      .setColor(0xE67E22)
      .setTitle('⏰ Your Cooldowns')
      .setDescription(cooldowns.join('\n'))
      .setFooter({ text: 'Use these commands to earn currency!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleWeekly(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const now = Date.now();
    const WEEK_MS = 7 * 24 * 60 * 60 * 1000;

    if (user.lastWeekly && now - user.lastWeekly < WEEK_MS) {
      const timeLeft = WEEK_MS - (now - user.lastWeekly);
      const days = Math.floor(timeLeft / (24 * 60 * 60 * 1000));
      const hours = Math.floor((timeLeft % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
      
      await this.safeReply(message, `⏰ Weekly reward already claimed!\n\nCome back in **${days}d ${hours}h**`);
      return;
    }

    const reward = 5000;
    user.lastWeekly = now;
    
    this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, reward);
    const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);

    const embed = new EmbedBuilder()
      .setColor(0x9B59B6)
      .setTitle('🎊 Weekly Reward Claimed!')
      .setDescription(`✨ You earned **${reward.toLocaleString()}** 💰!\n\n💰 **New balance:** ${updatedUser.balance.toLocaleString()}`)
      .setFooter({ text: 'Come back in 7 days for another weekly reward!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleHourly(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const now = Date.now();
    const HOUR_MS = 60 * 60 * 1000;

    if (user.lastHourly && now - user.lastHourly < HOUR_MS) {
      const timeLeft = HOUR_MS - (now - user.lastHourly);
      const minutes = Math.ceil(timeLeft / 60000);
      
      await this.safeReply(message, `⏰ Hourly reward already claimed!\n\nCome back in **${minutes}** minute(s)`);
      return;
    }

    const reward = 1000;
    user.lastHourly = now;
    
    this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, reward);
    const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);

    const embed = new EmbedBuilder()
      .setColor(0x00BFFF)
      .setTitle('⏰ Hourly Reward Claimed!')
      .setDescription(
        `💰 **Earned:** ${reward.toLocaleString()} 💰!\n\n` +
        `💵 **New balance:** ${updatedUser.balance.toLocaleString()}`
      )
      .setFooter({ text: 'Come back in 1 hour for another reward!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleMine(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const now = Date.now();
    
    if (!user.miningLevel) user.miningLevel = 1;
    if (!user.lastMine) user.lastMine = now;

    const timeSinceLastMine = now - user.lastMine;
    const MINE_INTERVAL = 30 * 60 * 1000;

    if (timeSinceLastMine < MINE_INTERVAL) {
      const timeLeft = MINE_INTERVAL - timeSinceLastMine;
      const minutes = Math.ceil(timeLeft / 60000);
      
      await this.safeReply(message, `⛏️ Your miners are still working!\n\nCheck back in **${minutes}** minute(s)`);
      return;
    }

    const passiveEarnings = Math.floor((timeSinceLastMine / 1000) * user.miningLevel * 10);
    const cappedEarnings = Math.min(passiveEarnings, user.miningLevel * 50000);
    user.lastMine = now;
    
    this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, cappedEarnings);
    const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);

    const upgradeCost = user.miningLevel * 10000;
    
    const embed = new EmbedBuilder()
      .setColor(0xFFAA00)
      .setTitle('⛏️ Mining Operation!')
      .setDescription(
        `💎 **Mining Level:** ${user.miningLevel}\n` +
        `💰 **Mined:** ${cappedEarnings.toLocaleString()} 💰!\n` +
        `📈 **Production:** ${(user.miningLevel * 10).toLocaleString()}/second\n\n` +
        `💵 **New balance:** ${updatedUser.balance.toLocaleString()}\n\n` +
        `**Upgrade to Level ${user.miningLevel + 1}:** ${upgradeCost.toLocaleString()} 💰\n` +
        `Use \`?upgrade mine\` to boost production!`
      )
      .setFooter({ text: 'Passive income generates even while offline!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleStreak(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const now = Date.now();
    
    if (!user.activityStreak) user.activityStreak = 1;
    if (!user.lastActivity) user.lastActivity = now;

    const timeSinceActivity = now - user.lastActivity;
    const ONE_DAY = 24 * 60 * 60 * 1000;

    if (timeSinceActivity < ONE_DAY) {
      const hoursLeft = Math.ceil((ONE_DAY - timeSinceActivity) / (60 * 60 * 1000));
      
      const embed = new EmbedBuilder()
        .setColor(0xFF6B6B)
        .setTitle('🔥 Activity Streak')
        .setDescription(
          `**Current streak:** ${user.activityStreak} day(s)\n` +
          `**Multiplier:** ${user.activityStreak}x\n\n` +
          `Come back in **${hoursLeft}h** to claim tomorrow's streak bonus!`
        )
        .setFooter({ text: 'Higher streaks = bigger multipliers on all earnings!' });

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    if (timeSinceActivity > ONE_DAY * 2) {
      user.activityStreak = 1;
    } else {
      user.activityStreak++;
    }

    user.lastActivity = now;
    
    const streakReward = user.activityStreak * 2000;
    this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, streakReward);
    const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);

    const embed = new EmbedBuilder()
      .setColor(0xFF6B6B)
      .setTitle('🔥 Streak Claimed!')
      .setDescription(
        `**Day ${user.activityStreak} streak!**\n\n` +
        `💰 **Earned:** ${streakReward.toLocaleString()} 💰!\n` +
        `⚡ **Multiplier:** ${user.activityStreak}x\n\n` +
        `💵 **New balance:** ${updatedUser.balance.toLocaleString()}\n\n` +
        `Keep coming back daily to build your streak!`
      )
      .setFooter({ text: 'Miss 2 days and your streak resets!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleHeist(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const now = Date.now();
    const HEIST_COOLDOWN = 6 * 60 * 60 * 1000;

    if (user.lastHeist && now - user.lastHeist < HEIST_COOLDOWN) {
      const timeLeft = HEIST_COOLDOWN - (now - user.lastHeist);
      const hours = Math.ceil(timeLeft / (60 * 60 * 1000));
      
      await this.safeReply(message, `🚨 You're laying low after your last heist!\n\nWait **${hours}** hour(s) before attempting another.`);
      return;
    }

    const minBet = 5000;
    if (user.balance < minBet) {
      await this.safeReply(message, `❌ You need at least **${minBet.toLocaleString()}** 💰 to attempt a heist!`);
      return;
    }

    user.lastHeist = now;

    const successChance = 0.60;
    const success = Math.random() < successChance;

    if (success) {
      const multiplier = 2 + Math.random() * 3;
      const wager = Math.floor(user.balance * 0.3);
      const winnings = Math.floor(wager * multiplier);
      
      this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, winnings);
      const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);

      const embed = new EmbedBuilder()
        .setColor(0x00FF00)
        .setTitle('💰 HEIST SUCCESSFUL!')
        .setDescription(
          `🎉 **You pulled it off!**\n\n` +
          `💼 **Haul:** ${winnings.toLocaleString()} 💰!\n` +
          `📊 **Multiplier:** ${multiplier.toFixed(1)}x\n\n` +
          `💵 **New balance:** ${updatedUser.balance.toLocaleString()}`
        )
        .setFooter({ text: 'High risk, high reward! Cooldown: 6 hours' });

      await this.safeReply(message, { embeds: [embed] });
    } else {
      const loss = Math.floor(user.balance * 0.2);
      this.dataManager.removeCurrency(message.guild.id, message.author.id, loss);
      const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);

      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('🚨 HEIST FAILED!')
        .setDescription(
          `😬 **The cops caught you!**\n\n` +
          `💸 **Lost:** ${loss.toLocaleString()} 💰 in bail!\n\n` +
          `💵 **New balance:** ${updatedUser.balance.toLocaleString()}`
        )
        .setFooter({ text: 'Better luck next time! Cooldown: 6 hours' });

      await this.safeReply(message, { embeds: [embed] });
    }
  }

  private async handleSpin(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const now = Date.now();
    const SPIN_COOLDOWN = 2 * 60 * 60 * 1000;

    if (user.lastSpin && now - user.lastSpin < SPIN_COOLDOWN) {
      const timeLeft = SPIN_COOLDOWN - (now - user.lastSpin);
      const minutes = Math.ceil(timeLeft / 60000);
      
      await this.safeReply(message, `🎰 The wheel is cooling down!\n\nCome back in **${minutes}** minute(s)`);
      return;
    }

    user.lastSpin = now;

    const prizes = [
      { emoji: '💎', name: 'JACKPOT', amount: 100000, chance: 0.01 },
      { emoji: '👑', name: 'MEGA WIN', amount: 50000, chance: 0.05 },
      { emoji: '💰', name: 'Big Win', amount: 20000, chance: 0.10 },
      { emoji: '🎉', name: 'Win', amount: 10000, chance: 0.20 },
      { emoji: '🎁', name: 'Small Win', amount: 5000, chance: 0.30 },
      { emoji: '😐', name: 'Nothing', amount: 0, chance: 0.34 }
    ];

    const roll = Math.random();
    let cumulativeChance = 0;
    let wonPrize = prizes[prizes.length - 1];

    for (const prize of prizes) {
      cumulativeChance += prize.chance;
      if (roll <= cumulativeChance) {
        wonPrize = prize;
        break;
      }
    }

    if (wonPrize.amount > 0) {
      this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, wonPrize.amount);
    }

    const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);
    const color = wonPrize.amount === 0 ? 0x808080 : wonPrize.amount >= 50000 ? 0xFFD700 : 0x00FF00;

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle('🎰 Lucky Wheel!')
      .setDescription(
        `${wonPrize.emoji} **${wonPrize.name.toUpperCase()}!** ${wonPrize.emoji}\n\n` +
        (wonPrize.amount > 0 
          ? `💰 **Won:** ${wonPrize.amount.toLocaleString()} 💰!\n\n💵 **New balance:** ${updatedUser.balance.toLocaleString()}`
          : `😐 **Better luck next time!**\n\n💵 **Balance:** ${updatedUser.balance.toLocaleString()}`
        )
      )
      .setFooter({ text: 'Free spin every 2 hours!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handlePay(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?pay <@user> <amount>');
      return;
    }

    const targetUser = message.mentions.users.first();
    if (!targetUser || targetUser.bot) {
      await this.safeReply(message, '❌ Please mention a valid user (not a bot)!');
      return;
    }

    if (targetUser.id === message.author.id) {
      await this.safeReply(message, '❌ You cannot pay yourself!');
      return;
    }

    const parsedAmount = parseFloat(args[1]);
    const amount = Math.floor(parsedAmount);
    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    if (isNaN(parsedAmount) || parsedAmount <= 0 || !Number.isInteger(parsedAmount) || amount < 1) {
      await this.safeReply(message, '❌ Please provide a valid positive whole number!');
      return;
    }

    if (amount > user.balance) {
      await this.safeReply(message, `❌ Insufficient funds! You only have **${user.balance.toLocaleString()}** 💰`);
      return;
    }

    // Same as give - confirmation via embed
    this.dataManager.removeCurrency(message.guild.id, message.author.id, amount);
    this.dataManager.addCurrencyRaw(message.guild.id, targetUser.id, amount);

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('💳 Payment Successful!')
      .setDescription(`✅ Paid **${amount.toLocaleString()}** 💰 to ${targetUser}\n\n💰 **Your new balance:** ${(user.balance - amount).toLocaleString()}`)
      .setFooter({ text: 'Transaction complete!' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleAddRole(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can add roles to the shop!');
      return;
    }

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?role <@role or role name> <price>\n\nExample: ?role @VIP 10000\nExample: ?role Member 5000');
      return;
    }

    const price = parseInt(args[args.length - 1]);
    if (isNaN(price) || price <= 0) {
      await this.safeReply(message, '❌ Please provide a valid positive price!');
      return;
    }

    let role = message.mentions.roles.first();
    
    if (!role) {
      const roleName = args.slice(0, -1).join(' ');
      role = message.guild.roles.cache.find(r => r.name.toLowerCase() === roleName.toLowerCase());
    }

    if (!role) {
      await this.safeReply(message, '❌ Role not found! Please mention a role or use its exact name.');
      return;
    }

    if (role.id === message.guild.id) {
      await this.safeReply(message, '❌ Cannot add @everyone role to the shop!');
      return;
    }

    const existingRole = this.dataManager.getRoleShopItems(message.guild.id).find(r => r.roleId === role!.id);
    if (existingRole) {
      await this.safeReply(message, `❌ **${role.name}** is already in the shop!`);
      return;
    }

    const roleItem = {
      id: `role_${role.id}`,
      guildId: message.guild.id,
      roleId: role.id,
      roleName: role.name,
      price: price
    };

    this.dataManager.addRoleShopItem(roleItem);

    const embed = new EmbedBuilder()
      .setColor(role.color || 0x5865F2)
      .setTitle('✅ Role Added to Shop!')
      .setDescription(`**${role.name}** has been added to the shop!\n\n💵 **Price:** ${price.toLocaleString()} currency\n🎭 Users can now purchase this role with \`?buy ${role.name}\``)
      .setFooter({ text: 'One-time purchase only' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleRemoveRole(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only the server owner or managers can remove roles from the shop!');
      return;
    }

    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?removerole <@role or role name>');
      return;
    }

    let role = message.mentions.roles.first();
    
    if (!role) {
      const roleName = args.join(' ');
      role = message.guild.roles.cache.find(r => r.name.toLowerCase() === roleName.toLowerCase());
    }

    if (!role) {
      await this.safeReply(message, '❌ Role not found! Please mention a role or use its exact name.');
      return;
    }

    const removed = this.dataManager.removeRoleShopItem(message.guild.id, role.id);
    
    if (removed) {
      await this.safeReply(message, `✅ **${role.name}** has been removed from the shop!`);
    } else {
      await this.safeReply(message, `❌ **${role.name}** is not in the shop!`);
    }
  }

  private async handleTrivia(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const cooldown = 300000;
    const now = Date.now();

    if (user.lastTrivia && now - user.lastTrivia < cooldown) {
      const timeLeft = Math.ceil((cooldown - (now - user.lastTrivia)) / 60000);
      await this.safeReply(message, `⏰ You can play trivia again in **${timeLeft}** minute(s)!`);
      return;
    }

    const triviaQuestions = [
      { q: 'What is the capital of France?', a: ['paris'], reward: 500 },
      { q: 'What is 2 + 2?', a: ['4', 'four'], reward: 300 },
      { q: 'What color is the sky?', a: ['blue'], reward: 400 },
      { q: 'How many continents are there?', a: ['7', 'seven'], reward: 600 },
      { q: 'What is the largest ocean?', a: ['pacific'], reward: 700 },
      { q: 'Who painted the Mona Lisa?', a: ['leonardo da vinci', 'da vinci', 'leonardo'], reward: 800 },
      { q: 'What year did World War 2 end?', a: ['1945'], reward: 900 },
      { q: 'What is the fastest land animal?', a: ['cheetah'], reward: 650 },
      { q: 'How many planets are in our solar system?', a: ['8', 'eight'], reward: 550 },
      { q: 'What is H2O commonly known as?', a: ['water'], reward: 450 }
    ];

    const question = triviaQuestions[Math.floor(Math.random() * triviaQuestions.length)];

    const embed = new EmbedBuilder()
      .setColor(0xFF6B9D)
      .setTitle('🎯 Trivia Showdown!')
      .setDescription(`**${question.q}**\n\n💰 Prize: **${question.reward.toLocaleString()}** currency\n⏱️ You have **20 seconds** to answer!`)
      .setFooter({ text: 'Type your answer in chat!' });

    await this.safeReply(message, { embeds: [embed] });

    const filter = (m: Message) => m.author.id === message.author.id;
    const collector = (message.channel as any).createMessageCollector({ filter, time: 20000, max: 1 });

    collector.on('collect', async (m: Message) => {
      const answer = m.content.toLowerCase().trim();
      if (question.a.some(a => answer.includes(a))) {
        const streakBonus = (user.triviaStreak || 0) * 100;
        const totalReward = question.reward + streakBonus;
        this.dataManager.addCurrencyRaw(message.guild!.id, message.author.id, totalReward);
        user.lastTrivia = now;
        user.triviaStreak = (user.triviaStreak || 0) + 1;

        const updatedUser = this.dataManager.getUser(message.guild!.id, message.author.id);
        const winEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('✅ Correct!')
          .setDescription(`🎉 **${question.reward.toLocaleString()}** currency earned!\n${streakBonus > 0 ? `🔥 **Streak bonus:** +${streakBonus}\n` : ''}🏆 **Streak:** ${user.triviaStreak}\n💰 **New balance:** ${updatedUser.balance.toLocaleString()}`);
        
        await this.safeReply(m, { embeds: [winEmbed] });
      } else {
        user.lastTrivia = now;
        user.triviaStreak = 0;
        const loseEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('❌ Wrong!')
          .setDescription(`The correct answer was: **${question.a[0]}**\n💔 Streak reset!`);
        
        await this.safeReply(m, { embeds: [loseEmbed] });
      }
    });

    collector.on('end', async (collected: any) => {
      if (collected.size === 0) {
        user.lastTrivia = now;
        user.triviaStreak = 0;
        await this.safeReply(message, '⏰ Time\'s up! Better luck next time!');
      }
    });
  }

  private async handleAchievements(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const achievements = [
      { id: 'first_message', name: 'First Steps', desc: 'Send your first message', req: 1, reward: 500, emoji: '👣', check: user.messageCount >= 1 },
      { id: 'hundred_messages', name: 'Chatterbox', desc: 'Send 100 messages', req: 100, reward: 2000, emoji: '💬', check: user.messageCount >= 100, title: 'Chatterbox' },
      { id: 'thousand_messages', name: 'Social Butterfly', desc: 'Send 1000 messages', req: 1000, reward: 10000, emoji: '🦋', check: user.messageCount >= 1000, title: 'Social Butterfly' },
      { id: 'millionaire', name: 'Millionaire', desc: 'Earn 1,000,000 currency', req: 1000000, reward: 50000, emoji: '💰', check: user.balance >= 1000000, title: 'Millionaire' },
      { id: 'shopaholic', name: 'Shopaholic', desc: 'Buy 10 items', req: 10, reward: 5000, emoji: '🛍️', check: (user.purchasedItems?.length || 0) >= 10, title: 'Shopaholic' },
      { id: 'gambler', name: 'High Roller', desc: 'Win 10 coinflips', req: 10, reward: 8000, emoji: '🎲', check: false, title: 'High Roller' }
    ];

    if (!user.achievements) user.achievements = [];

    const embed = new EmbedBuilder()
      .setColor(0xFFD700)
      .setTitle('🏆 Achievements')
      .setDescription(`Your current title: **${user.title || 'None'}**\n\`?settitle <name>\` to equip a title!`);

    achievements.forEach(ach => {
      const unlocked = user.achievements!.includes(ach.id) || ach.check;
      const status = unlocked ? '✅ UNLOCKED' : `🔒 ${Math.floor((user.messageCount / ach.req) * 100)}%`;
      
      embed.addFields({
        name: `${ach.emoji} ${ach.name}`,
        value: `${ach.desc}\n${status}${ach.title ? ` • Title: ${ach.title}` : ''}`,
        inline: true
      });

      if (ach.check && !user.achievements!.includes(ach.id)) {
        user.achievements!.push(ach.id);
        this.dataManager.addCurrencyRaw(message.guild!.id, message.author.id, ach.reward);
        this.safeReply(message, `🎉 **Achievement Unlocked:** ${ach.emoji} ${ach.name}! +${ach.reward.toLocaleString()} 💰`);
      }
    });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleSetTitle(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (args.length === 0) {
      await this.safeReply(message, 'Usage: ?settitle <title name>\nExample: ?settitle Chatterbox');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const titleName = args.join(' ');
    
    const validTitles = ['Chatterbox', 'Social Butterfly', 'Millionaire', 'Shopaholic', 'High Roller'];
    
    if (!validTitles.includes(titleName)) {
      await this.safeReply(message, `❌ Invalid title! Available titles:\n${validTitles.map(t => `• ${t}`).join('\n')}`);
      return;
    }

    user.title = titleName;
    await this.safeReply(message, `✅ Title set to **${titleName}**!`);
  }

  private async handleDuel(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?duel <@user> <wager>\nExample: ?duel @friend 1000');
      return;
    }

    const target = message.mentions.users.first();
    if (!target || target.bot || target.id === message.author.id) {
      await this.safeReply(message, '❌ Please mention a valid user (not yourself or a bot)!');
      return;
    }

    const wager = parseInt(args[1]);
    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    if (isNaN(wager) || wager < 100) {
      await this.safeReply(message, '❌ Minimum wager is **100** currency!');
      return;
    }

    if (wager > user.balance) {
      await this.safeReply(message, `❌ You only have **${user.balance.toLocaleString()}** 💰!`);
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(0xFF6B9D)
      .setTitle('⚔️ Duel Challenge!')
      .setDescription(`${target}, ${message.author} has challenged you to a duel!\n\n💰 **Wager:** ${wager.toLocaleString()}\n\nType \`?accept ${message.author.username}\` to accept!`)
      .setFooter({ text: 'Challenge expires in 60 seconds' });

    await this.safeReply(message, { embeds: [embed] });

    const challenge = {
      id: `${message.author.id}_${target.id}_${Date.now()}`,
      guildId: message.guild.id,
      challengerId: message.author.id,
      targetId: target.id,
      wager,
      expiresAt: Date.now() + 60000
    };

    const challenges = this.dataManager.getDuelChallenges();
    challenges.push(challenge);
    this.dataManager.setDuelChallenges(challenges);
  }

  private async handleAcceptDuel(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const challenges = this.dataManager.getDuelChallenges();
    
    if (challenges.length === 0) {
      await this.safeReply(message, '❌ No pending duel challenges!');
      return;
    }

    const challenge = challenges.find(
      c => c.targetId === message.author.id && c.guildId === message.guild!.id && Date.now() < c.expiresAt
    );

    if (!challenge) {
      await this.safeReply(message, '❌ No pending duel challenges for you!');
      return;
    }

    const target = this.dataManager.getUser(message.guild.id, message.author.id);
    const challenger = this.dataManager.getUser(message.guild.id, challenge.challengerId);

    if (target.balance < challenge.wager) {
      await this.safeReply(message, `❌ You need **${challenge.wager.toLocaleString()}** 💰 to accept this duel!`);
      return;
    }

    const winner = Math.random() < 0.5 ? message.author.id : challenge.challengerId;
    const loser = winner === message.author.id ? challenge.challengerId : message.author.id;

    this.dataManager.removeCurrency(message.guild.id, message.author.id, challenge.wager);
    this.dataManager.removeCurrency(message.guild.id, challenge.challengerId, challenge.wager);
    this.dataManager.addCurrencyRaw(message.guild.id, winner, challenge.wager * 2);

    if (winner === message.author.id) {
      if (!target.duelsWon) target.duelsWon = 0;
      target.duelsWon++;
      if (!challenger.duelsLost) challenger.duelsLost = 0;
      challenger.duelsLost++;
    } else {
      if (!challenger.duelsWon) challenger.duelsWon = 0;
      challenger.duelsWon++;
      if (!target.duelsLost) target.duelsLost = 0;
      target.duelsLost++;
    }

    const embed = new EmbedBuilder()
      .setColor(winner === message.author.id ? 0x00FF00 : 0xFF0000)
      .setTitle('⚔️ Duel Complete!')
      .setDescription(`🏆 **Winner:** <@${winner}>\n💰 **Prize:** ${(challenge.wager * 2).toLocaleString()}`);

    await this.safeReply(message, { embeds: [embed] });

    this.dataManager.setDuelChallenges(challenges.filter(c => c.id !== challenge.id));
  }

  private async handleFaceoff(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?faceoff <@user> <wager>\nExample: ?faceoff @friend 1000');
      return;
    }

    const target = message.mentions.users.first();
    if (!target || target.bot || target.id === message.author.id) {
      await this.safeReply(message, '❌ Please mention a valid user (not yourself or a bot)!');
      return;
    }

    const wager = parseInt(args[1]);
    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    if (isNaN(wager) || wager < 100) {
      await this.safeReply(message, '❌ Minimum wager is **100** currency!');
      return;
    }

    if (wager > user.balance) {
      await this.safeReply(message, `❌ You only have **${user.balance.toLocaleString()}** 💰!`);
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(0xFF6B35)
      .setTitle('🔫 Face-Off Challenge!')
      .setDescription(`${target}, ${message.author} has challenged you to a quick draw duel!\n\n💰 **Wager:** ${wager.toLocaleString()}\n\n⚡ **How it works:**\n• Wait for the target emoji to appear (3-20s)\n• First to react wins!\n• 💣 **BOMB WARNING:** If you see 💣, DON'T react or you lose!\n\nType \`?acceptfaceoff\` to accept!`)
      .setFooter({ text: 'Challenge expires in 60 seconds' });

    await this.safeReply(message, { embeds: [embed] });

    const challenge = {
      id: `${message.author.id}_${target.id}_${Date.now()}`,
      guildId: message.guild.id,
      challengerId: message.author.id,
      targetId: target.id,
      wager,
      expiresAt: Date.now() + 60000
    };

    const challenges = this.dataManager.getFaceoffChallenges();
    challenges.push(challenge);
    this.dataManager.setFaceoffChallenges(challenges);
  }

  private async handleAcceptFaceoff(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const challenges = this.dataManager.getFaceoffChallenges();
    
    if (challenges.length === 0) {
      await this.safeReply(message, '❌ No pending face-off challenges!');
      return;
    }

    const challenge = challenges.find(
      c => c.targetId === message.author.id && c.guildId === message.guild!.id && Date.now() < c.expiresAt
    );

    if (!challenge) {
      await this.safeReply(message, '❌ No pending face-off challenges for you!');
      return;
    }

    const target = this.dataManager.getUser(message.guild.id, message.author.id);
    const challenger = this.dataManager.getUser(message.guild.id, challenge.challengerId);

    if (target.balance < challenge.wager) {
      await this.safeReply(message, `❌ You need **${challenge.wager.toLocaleString()}** 💰 to accept this face-off!`);
      return;
    }

    this.dataManager.removeCurrency(message.guild.id, message.author.id, challenge.wager);
    this.dataManager.removeCurrency(message.guild.id, challenge.challengerId, challenge.wager);

    const isBomb = Math.random() < 0.25;
    const delay = Math.floor(Math.random() * 17000) + 3000;
    
    const startEmbed = new EmbedBuilder()
      .setColor(0xFFAA00)
      .setTitle('🔫 Face-Off Started!')
      .setDescription(`⏳ Get ready... wait for the signal!\n\n👥 **Players:**\n<@${challenge.challengerId}> vs <@${challenge.targetId}>\n💰 **Prize:** ${(challenge.wager * 2).toLocaleString()}`)
      .setFooter({ text: 'First to react wins!' });

    const sentMessage = await this.safeReply(message, { embeds: [startEmbed] });

    setTimeout(async () => {
      const targetEmoji = isBomb ? '💣' : '🎯';
      
      try {
        await sentMessage.react(targetEmoji);
      } catch (error) {
        console.error('Failed to add reaction:', error);
        return;
      }

      const filter = (reaction: any, user: any) => {
        return [challenge.challengerId, challenge.targetId].includes(user.id) && reaction.emoji.name === targetEmoji;
      };

      const collector = sentMessage.createReactionCollector({ filter, time: 2000, max: 1 });

      collector.on('collect', async (reaction: any, user: any) => {
        let winner: string;
        let loser: string;

        if (isBomb) {
          winner = user.id === challenge.challengerId ? challenge.targetId : challenge.challengerId;
          loser = user.id;
        } else {
          winner = user.id;
          loser = user.id === challenge.challengerId ? challenge.targetId : challenge.challengerId;
        }

        this.dataManager.addCurrencyRaw(message.guild!.id, winner, challenge.wager * 2);

        const resultEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle(isBomb ? '💣 Bomb Trap!' : '🎯 Quick Draw!')
          .setDescription(`${isBomb ? '💥 ' + `<@${loser}>` + ' hit the bomb!' : '⚡ ' + `<@${winner}>` + ' was faster!'}\n\n🏆 **Winner:** <@${winner}>\n💰 **Prize:** ${(challenge.wager * 2).toLocaleString()}`);

        await sentMessage.reply({ embeds: [resultEmbed] });
      });

      collector.on('end', async (collected: any) => {
        if (collected.size === 0) {
          this.dataManager.addCurrencyRaw(message.guild!.id, challenge.challengerId, challenge.wager);
          this.dataManager.addCurrencyRaw(message.guild!.id, challenge.targetId, challenge.wager);

          const timeoutEmbed = new EmbedBuilder()
            .setColor(0xFF0000)
            .setTitle('⏰ Time\'s Up!')
            .setDescription('Nobody reacted in time! Wagers returned.');

          await sentMessage.reply({ embeds: [timeoutEmbed] });
        }
      });
    }, delay);

    this.dataManager.setFaceoffChallenges(challenges.filter(c => c.id !== challenge.id));
  }

  private async handleRps(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (args.length < 2) {
      await this.safeReply(message, 'Usage: ?rps <@user> <wager>\nExample: ?rps @friend 1000');
      return;
    }

    const target = message.mentions.users.first();
    if (!target || target.bot || target.id === message.author.id) {
      await this.safeReply(message, '❌ Please mention a valid user (not yourself or a bot)!');
      return;
    }

    const wager = parseInt(args[1]);
    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    if (isNaN(wager) || wager < 100) {
      await this.safeReply(message, '❌ Minimum wager is **100** currency!');
      return;
    }

    if (wager > user.balance) {
      await this.safeReply(message, `❌ You only have **${user.balance.toLocaleString()}** 💰!`);
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(0x9B59B6)
      .setTitle('✊✋✌️ Rock Paper Scissors!')
      .setDescription(`${target}, ${message.author} has challenged you to Rock Paper Scissors!\n\n💰 **Wager:** ${wager.toLocaleString()}\n\nType \`?acceptrps\` to accept!`)
      .setFooter({ text: 'Challenge expires in 60 seconds' });

    await this.safeReply(message, { embeds: [embed] });

    const challenge = {
      id: `${message.author.id}_${target.id}_${Date.now()}`,
      guildId: message.guild.id,
      challengerId: message.author.id,
      targetId: target.id,
      wager,
      expiresAt: Date.now() + 60000
    };

    const challenges = this.dataManager.getRpsChallenges();
    challenges.push(challenge);
    this.dataManager.setRpsChallenges(challenges);
  }

  private async handleAcceptRps(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const challenges = this.dataManager.getRpsChallenges();
    
    if (challenges.length === 0) {
      await this.safeReply(message, '❌ No pending RPS challenges!');
      return;
    }

    const challenge = challenges.find(
      c => c.targetId === message.author.id && c.guildId === message.guild!.id && Date.now() < c.expiresAt
    );

    if (!challenge) {
      await this.safeReply(message, '❌ No pending RPS challenges for you!');
      return;
    }

    const target = this.dataManager.getUser(message.guild.id, message.author.id);
    const challenger = this.dataManager.getUser(message.guild.id, challenge.challengerId);

    if (target.balance < challenge.wager) {
      await this.safeReply(message, `❌ You need **${challenge.wager.toLocaleString()}** 💰 to accept this challenge!`);
      return;
    }

    this.dataManager.removeCurrency(message.guild.id, message.author.id, challenge.wager);
    this.dataManager.removeCurrency(message.guild.id, challenge.challengerId, challenge.wager);

    const row = new ActionRowBuilder<ButtonBuilder>()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('rps_rock')
          .setLabel('Rock')
          .setEmoji('🪨')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('rps_paper')
          .setLabel('Paper')
          .setEmoji('📄')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('rps_scissors')
          .setLabel('Scissors')
          .setEmoji('✂️')
          .setStyle(ButtonStyle.Danger)
      );

    const startEmbed = new EmbedBuilder()
      .setColor(0x9B59B6)
      .setTitle('✊✋✌️ Rock Paper Scissors!')
      .setDescription(`**Players:**\n<@${challenge.challengerId}> vs <@${challenge.targetId}>\n\n💰 **Prize:** ${(challenge.wager * 2).toLocaleString()}\n\n⏱️ **30 seconds** to make your choice!\n🔘 Click a button below to choose!\n🔒 Your choice will be hidden until both players choose!`)
      .setFooter({ text: 'Only the two players can click the buttons!' });

    const sentMessage = await this.safeReply(message, { embeds: [startEmbed], components: [row] });

    let challengerChoice: 'rock' | 'paper' | 'scissors' | null = null;
    let targetChoice: 'rock' | 'paper' | 'scissors' | null = null;

    const filter = (interaction: any) => {
      return [challenge.challengerId, challenge.targetId].includes(interaction.user.id) && 
             interaction.customId.startsWith('rps_');
    };

    const collector = sentMessage.createMessageComponentCollector({ 
      filter, 
      time: 30000 
    });

    collector.on('collect', async (interaction: any) => {
      const choice = interaction.customId.replace('rps_', '') as 'rock' | 'paper' | 'scissors';
      
      if (interaction.user.id === challenge.challengerId) {
        if (challengerChoice) {
          await interaction.reply({ content: '❌ You already made your choice!', ephemeral: true });
          return;
        }
        challengerChoice = choice;
        await interaction.reply({ content: `✅ You chose **${choice}**! Waiting for opponent...`, ephemeral: true });
      } else if (interaction.user.id === challenge.targetId) {
        if (targetChoice) {
          await interaction.reply({ content: '❌ You already made your choice!', ephemeral: true });
          return;
        }
        targetChoice = choice;
        await interaction.reply({ content: `✅ You chose **${choice}**! Waiting for opponent...`, ephemeral: true });
      }

      if (challengerChoice && targetChoice) {
        collector.stop('both_chosen');
      }
    });

    collector.on('end', async (collected, reason) => {
      await sentMessage.edit({ components: [] });

      if (reason === 'both_chosen' && challengerChoice && targetChoice) {
        const waitEmbed = new EmbedBuilder()
          .setColor(0xFFAA00)
          .setTitle('⏳ Revealing Results...')
          .setDescription('Both players have chosen! Results in **5 seconds**...');
        
        await sentMessage.edit({ embeds: [waitEmbed] });
        await new Promise(resolve => setTimeout(resolve, 5000));

        const emojis = {
          rock: '🪨',
          paper: '📄',
          scissors: '✂️'
        };

        let result: 'challenger' | 'target' | 'tie';
        
        if (challengerChoice === targetChoice) {
          result = 'tie';
        } else if (
          (challengerChoice === 'rock' && targetChoice === 'scissors') ||
          (challengerChoice === 'paper' && targetChoice === 'rock') ||
          (challengerChoice === 'scissors' && targetChoice === 'paper')
        ) {
          result = 'challenger';
        } else {
          result = 'target';
        }

        let resultEmbed: EmbedBuilder;

        if (result === 'tie') {
          this.dataManager.addCurrencyRaw(message.guild!.id, challenge.challengerId, challenge.wager);
          this.dataManager.addCurrencyRaw(message.guild!.id, challenge.targetId, challenge.wager);

          resultEmbed = new EmbedBuilder()
            .setColor(0xFFAA00)
            .setTitle('🤝 It\'s a Tie!')
            .setDescription(`<@${challenge.challengerId}>: ${emojis[challengerChoice]} **${challengerChoice}**\n<@${challenge.targetId}>: ${emojis[targetChoice]} **${targetChoice}**\n\n💰 Wagers returned!`);
        } else {
          const winner = result === 'challenger' ? challenge.challengerId : challenge.targetId;

          this.dataManager.addCurrencyRaw(message.guild!.id, winner, challenge.wager * 2);

          resultEmbed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('🏆 Winner!')
            .setDescription(`<@${challenge.challengerId}>: ${emojis[challengerChoice]} **${challengerChoice}**\n<@${challenge.targetId}>: ${emojis[targetChoice]} **${targetChoice}**\n\n🎉 **Winner:** <@${winner}>\n💰 **Prize:** ${(challenge.wager * 2).toLocaleString()}`);
        }

        await sentMessage.edit({ embeds: [resultEmbed] });
      } else {
        this.dataManager.addCurrencyRaw(message.guild!.id, challenge.challengerId, challenge.wager);
        this.dataManager.addCurrencyRaw(message.guild!.id, challenge.targetId, challenge.wager);

        const timeoutEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('⏰ Time\'s Up!')
          .setDescription('Not all players made their choice in time! Wagers returned.');

        await sentMessage.edit({ embeds: [timeoutEmbed] });
      }

      this.dataManager.setRpsChallenges(challenges.filter(c => c.id !== challenge.id));
    });
  }

  private async handleTreasureHunt(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const cost = 2000;

    if (user.balance < cost) {
      await this.safeReply(message, `❌ Treasure maps cost **${cost.toLocaleString()}** 💰!`);
      return;
    }

    this.dataManager.removeCurrency(message.guild.id, message.author.id, cost);

    const riddles = [
      { q: 'I have cities, but no houses. I have mountains, but no trees. I have water, but no fish. What am I?', a: ['map'], prize: 5000 },
      { q: 'What has keys but no locks, space but no room, and you can enter but can\'t go inside?', a: ['keyboard'], prize: 6000 },
      { q: 'The more you take, the more you leave behind. What am I?', a: ['footsteps', 'steps'], prize: 7000 },
      { q: 'What can travel around the world while staying in a corner?', a: ['stamp'], prize: 5500 }
    ];

    const riddle = riddles[Math.floor(Math.random() * riddles.length)];

    const embed = new EmbedBuilder()
      .setColor(0xFFD700)
      .setTitle('🗺️ Treasure Hunt!')
      .setDescription(`**Riddle:**\n${riddle.q}\n\n💰 Treasure value: **${riddle.prize.toLocaleString()}**\n⏱️ 30 seconds to solve!`)
      .setFooter({ text: 'Type your answer!' });

    await this.safeReply(message, { embeds: [embed] });

    const filter = (m: Message) => m.author.id === message.author.id;
    const collector = (message.channel as any).createMessageCollector({ filter, time: 30000, max: 1 });

    collector.on('collect', async (m: Message) => {
      if (riddle.a.some(a => m.content.toLowerCase().includes(a))) {
        this.dataManager.addCurrencyRaw(message.guild!.id, message.author.id, riddle.prize);
        if (!user.treasureHuntsCompleted) user.treasureHuntsCompleted = 0;
        user.treasureHuntsCompleted++;

        await this.safeReply(m, `✅ **Treasure found!** +${riddle.prize.toLocaleString()} 💰`);
      } else {
        await this.safeReply(m, `❌ Wrong! The answer was: **${riddle.a[0]}**`);
      }
    });

    collector.on('end', async (collected: any) => {
      if (collected.size === 0) {
        await this.safeReply(message, '⏰ Time\'s up! The treasure was lost!');
      }
    });
  }

  private async handleTrade(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (args.length < 3) {
      await this.safeReply(message, 'Usage: ?trade <@user> <your currency> <their currency>\nExample: ?trade @friend 5000 3000');
      return;
    }

    const target = message.mentions.users.first();
    if (!target || target.bot || target.id === message.author.id) {
      await this.safeReply(message, '❌ Please mention a valid user!');
      return;
    }

    const senderAmount = parseInt(args[1]);
    const receiverAmount = parseInt(args[2]);
    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    if (isNaN(senderAmount) || isNaN(receiverAmount) || senderAmount < 0 || receiverAmount < 0) {
      await this.safeReply(message, '❌ Invalid amounts!');
      return;
    }

    if (senderAmount > user.balance) {
      await this.safeReply(message, `❌ You only have **${user.balance.toLocaleString()}** 💰!`);
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(0x00D9FF)
      .setTitle('🤝 Trade Offer!')
      .setDescription(
        `${target}, ${message.author} wants to trade!\n\n` +
        `💰 **They offer:** ${senderAmount.toLocaleString()}\n` +
        `💵 **They want:** ${receiverAmount.toLocaleString()}\n\n` +
        `Type \`?accepttrade ${message.author.username}\` to accept!`
      )
      .setFooter({ text: 'Offer expires in 60 seconds' });

    await this.safeReply(message, { embeds: [embed] });

    const trade = {
      id: `${message.author.id}_${target.id}_${Date.now()}`,
      guildId: message.guild.id,
      senderId: message.author.id,
      receiverId: target.id,
      senderOffer: { currency: senderAmount, items: [] },
      receiverOffer: { currency: receiverAmount, items: [] },
      expiresAt: Date.now() + 60000,
      status: 'pending' as const
    };

    const offers = this.dataManager.getTradeOffers();
    offers.push(trade);
    this.dataManager.setTradeOffers(offers);
  }

  private async handleAcceptTrade(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const offers = this.dataManager.getTradeOffers();

    if (offers.length === 0) {
      await this.safeReply(message, '❌ No pending trade offers!');
      return;
    }

    const trade = offers.find(
      t => t.receiverId === message.author.id && t.guildId === message.guild!.id && Date.now() < t.expiresAt && t.status === 'pending'
    );

    if (!trade) {
      await this.safeReply(message, '❌ No pending trades for you!');
      return;
    }

    const receiver = this.dataManager.getUser(message.guild.id, message.author.id);
    const sender = this.dataManager.getUser(message.guild.id, trade.senderId);

    if (receiver.balance < trade.receiverOffer.currency) {
      await this.safeReply(message, `❌ You need **${trade.receiverOffer.currency.toLocaleString()}** 💰!`);
      return;
    }

    if (sender.balance < trade.senderOffer.currency) {
      await this.safeReply(message, '❌ The sender no longer has enough currency!');
      return;
    }

    this.dataManager.removeCurrency(message.guild.id, trade.senderId, trade.senderOffer.currency);
    this.dataManager.removeCurrency(message.guild.id, trade.receiverId, trade.receiverOffer.currency);
    this.dataManager.addCurrencyRaw(message.guild.id, trade.senderId, trade.receiverOffer.currency);
    this.dataManager.addCurrencyRaw(message.guild.id, trade.receiverId, trade.senderOffer.currency);

    const tax = Math.floor((trade.senderOffer.currency + trade.receiverOffer.currency) * 0.05);

    await this.safeReply(message, `✅ **Trade complete!**\n💰 5% tax applied: ${tax.toLocaleString()}`);

    this.dataManager.setTradeOffers(offers.filter(t => t.id !== trade.id));
  }

  private async handleQuests(message: Message): Promise<void> {
    if (!message.guild) return;

    let guildQuests = this.dataManager.getDailyQuests(message.guild.id);
    const now = Date.now();

    if (!guildQuests || now - guildQuests.lastRefresh > 86400000) {
      const newQuests = [
        { id: 'q1', type: 'send_messages' as const, requirement: 50, reward: 2000, description: 'Send 50 messages' },
        { id: 'q2', type: 'earn_currency' as const, requirement: 10000, reward: 3000, description: 'Earn 10,000 currency' },
        { id: 'q3', type: 'use_commands' as const, requirement: 10, reward: 1500, description: 'Use 10 commands' }
      ];

      guildQuests = {
        guildId: message.guild.id,
        quests: newQuests,
        lastRefresh: now
      };

      this.dataManager.setDailyQuests(message.guild.id, guildQuests);
    }

    const quests = guildQuests.quests;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    const embed = new EmbedBuilder()
      .setColor(0x00D9FF)
      .setTitle('📋 Daily Quests')
      .setDescription('Complete quests to earn bonus rewards!');

    quests.forEach((q: any) => {
      let progress = 0;
      if (q.type === 'send_messages') progress = user.messageCount;
      if (q.type === 'earn_currency') progress = user.balance;
      
      const percent = Math.min(100, Math.floor((progress / q.requirement) * 100));
      const status = percent >= 100 ? '✅ COMPLETE' : `${percent}%`;

      embed.addFields({
        name: q.description,
        value: `💰 Reward: ${q.reward.toLocaleString()}\n${status}`,
        inline: true
      });
    });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleBattlePass(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    
    if (!user.battlePassXP) user.battlePassXP = 0;
    if (!user.battlePassLevel) user.battlePassLevel = 0;

    const xpNeeded = (user.battlePassLevel + 1) * 1000;

    const embed = new EmbedBuilder()
      .setColor(0xFF6B9D)
      .setTitle('🎟️ Battle Pass')
      .setDescription(
        `**Level:** ${user.battlePassLevel}\n` +
        `**XP:** ${user.battlePassXP}/${xpNeeded}\n\n` +
        `🎁 **Earn XP by:**\n` +
        `• Sending messages (+10 XP)\n` +
        `• Completing quests (+50 XP)\n` +
        `• Using commands (+5 XP)`
      )
      .addFields(
        { name: 'Level 5', value: '🎁 1,000 currency', inline: true },
        { name: 'Level 10', value: '⚡ 1.5x Boost', inline: true },
        { name: 'Level 20', value: '💎 VIP Access', inline: true }
      );

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleScratchCard(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const cost = 500;

    if (user.balance < cost) {
      await this.safeReply(message, `❌ Scratch cards cost **${cost.toLocaleString()}** 💰!`);
      return;
    }

    this.dataManager.removeCurrency(message.guild.id, message.author.id, cost);

    const prizes = [
      { prize: 0, chance: 0.50, emoji: '❌' },
      { prize: 500, chance: 0.25, emoji: '💵' },
      { prize: 1000, chance: 0.15, emoji: '💰' },
      { prize: 5000, chance: 0.08, emoji: '💎' },
      { prize: 10000, chance: 0.02, emoji: '👑' }
    ];

    const roll = Math.random();
    let cumulative = 0;
    let result = prizes[0];

    for (const p of prizes) {
      cumulative += p.chance;
      if (roll < cumulative) {
        result = p;
        break;
      }
    }

    if (result.prize > 0) {
      this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, result.prize);
      if (!user.scratchCardsWon) user.scratchCardsWon = 0;
      user.scratchCardsWon++;
    }

    const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);
    const embed = new EmbedBuilder()
      .setColor(result.prize > 0 ? 0x00FF00 : 0xFF0000)
      .setTitle('🎰 Scratch Card!')
      .setDescription(
        result.prize > 0 
          ? `${result.emoji} **YOU WON ${result.prize.toLocaleString()}** 💰!`
          : `${result.emoji} Better luck next time!`
      )
      .setFooter({ text: `Cost: ${cost} • Balance: ${updatedUser.balance.toLocaleString()}` });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleSlots(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = args.length > 0 ? parseInt(args[0]) : 100;

    if (isNaN(bet) || bet < 50) {
      await this.safeReply(message, '❌ Minimum bet is **50** 💰!\n\nUsage: `?slots <amount>`');
      return;
    }

    if (user.balance < bet) {
      await this.safeReply(message, `❌ Insufficient funds! You need **${bet.toLocaleString()}** 💰 but only have **${user.balance.toLocaleString()}**.`);
      return;
    }

    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);

    const symbols = ['🍒', '🍊', '🍋', '🍇', '⭐', '💎', '7️⃣'];
    const weights = [30, 25, 20, 15, 5, 3, 2]; // Higher = more common
    
    const weightedRandom = () => {
      const totalWeight = weights.reduce((a, b) => a + b, 0);
      let random = Math.random() * totalWeight;
      for (let i = 0; i < symbols.length; i++) {
        random -= weights[i];
        if (random <= 0) return symbols[i];
      }
      return symbols[0];
    };

    const reel1 = weightedRandom();
    const reel2 = weightedRandom();
    const reel3 = weightedRandom();

    let winnings = 0;
    let message_text = '';

    // Check for wins
    if (reel1 === reel2 && reel2 === reel3) {
      // Three of a kind
      const multipliers: { [key: string]: number } = {
        '🍒': 3, '🍊': 4, '🍋': 5, '🍇': 6, '⭐': 10, '💎': 20, '7️⃣': 50
      };
      const multiplier = multipliers[reel1] || 2;
      winnings = bet * multiplier;
      message_text = `🎰 **JACKPOT!** ${reel1}${reel2}${reel3}\n\n💰 **${multiplier}x multiplier!**\n✨ You won **${winnings.toLocaleString()}** 💰!`;
    } else if (reel1 === reel2 || reel2 === reel3) {
      // Two of a kind
      winnings = Math.floor(bet * 1.5);
      message_text = `🎰 ${reel1} ${reel2} ${reel3}\n\n💵 Two matching! You won **${winnings.toLocaleString()}** 💰!`;
    } else {
      message_text = `🎰 ${reel1} ${reel2} ${reel3}\n\n😢 No match! Better luck next time!`;
    }

    if (winnings > 0) {
      this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, winnings);
    }

    const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);
    const embed = new EmbedBuilder()
      .setColor(winnings > 0 ? 0x00FF00 : 0xFF0000)
      .setTitle('🎰 Slot Machine!')
      .setDescription(message_text + `\n\n💰 **Balance:** ${updatedUser.balance.toLocaleString()}`)
      .setFooter({ text: `Bet: ${bet.toLocaleString()} 💰` });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleBlackjack(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = args.length > 0 ? parseInt(args[0]) : 500;

    if (isNaN(bet) || bet < 100) {
      await this.safeReply(message, '❌ Minimum bet is **100** 💰!\n\nUsage: `?blackjack <amount>`');
      return;
    }

    if (user.balance < bet) {
      await this.safeReply(message, `❌ Insufficient funds! You need **${bet.toLocaleString()}** 💰 but only have **${user.balance.toLocaleString()}**.`);
      return;
    }

    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);

    const getCard = () => Math.min(Math.floor(Math.random() * 13) + 1, 10);
    const getHandValue = (cards: number[]) => {
      let value = cards.reduce((a, b) => a + b, 0);
      let aces = cards.filter(c => c === 1).length;
      while (value <= 11 && aces > 0) {
        value += 10;
        aces--;
      }
      return value;
    };

    const playerCards = [getCard(), getCard()];
    const dealerCards = [getCard(), getCard()];

    const playerValue = getHandValue(playerCards);
    const dealerValue = getHandValue(dealerCards);

    let result = '';
    let winnings = 0;
    let color = 0xFF0000;

    if (playerValue === 21) {
      // Blackjack!
      winnings = Math.floor(bet * 2.5);
      result = `🃏 **BLACKJACK!** 🃏\n\n✨ You won **${winnings.toLocaleString()}** 💰!`;
      color = 0xFFD700;
    } else if (playerValue > 21) {
      // Bust
      result = `💥 **BUST!** You went over 21!\n\n😢 Lost **${bet.toLocaleString()}** 💰!`;
      color = 0xFF0000;
    } else if (dealerValue > 21 || playerValue > dealerValue) {
      // Win
      winnings = bet * 2;
      result = `🎉 **YOU WIN!**\n\n💰 Won **${winnings.toLocaleString()}** 💰!`;
      color = 0x00FF00;
    } else if (playerValue === dealerValue) {
      // Push (tie)
      winnings = bet;
      result = `🤝 **PUSH!** It's a tie!\n\n💰 Bet returned: **${bet.toLocaleString()}** 💰`;
      color = 0xFFAA00;
    } else {
      // Lose
      result = `😢 **DEALER WINS!**\n\n💸 Lost **${bet.toLocaleString()}** 💰!`;
      color = 0xFF0000;
    }

    if (winnings > 0) {
      this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, winnings);
    }

    const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);
    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle('🃏 Blackjack!')
      .setDescription(
        `**Your hand:** ${playerValue} 🎴\n` +
        `**Dealer's hand:** ${dealerValue} 🎴\n\n` +
        result +
        `\n\n💰 **Balance:** ${updatedUser.balance.toLocaleString()}`
      )
      .setFooter({ text: `Bet: ${bet.toLocaleString()} 💰` });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleLottery(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const TICKET_COST = 1000;

    if (args.length === 0) {
      // Show lottery info
      const embed = new EmbedBuilder()
        .setColor(0xFFD700)
        .setTitle('🎟️ Lottery System')
        .setDescription(
          `**How to play:**\n` +
          `• Buy tickets for **${TICKET_COST.toLocaleString()}** 💰 each\n` +
          `• Each ticket gives you a chance to win!\n` +
          `• Drawing happens instantly\n\n` +
          `**Prizes:**\n` +
          `🏆 **Grand Prize:** 50,000 💰 (1% chance)\n` +
          `💎 **Big Win:** 10,000 💰 (5% chance)\n` +
          `💰 **Win:** 5,000 💰 (10% chance)\n` +
          `🎁 **Small Win:** 2,000 💰 (15% chance)\n` +
          `😢 **No Prize:** Nothing (69% chance)\n\n` +
          `**Commands:**\n` +
          `\`?lottery buy <amount>\` - Buy tickets\n` +
          `Example: \`?lottery buy 5\``
        )
        .setFooter({ text: 'Good luck!' });

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    if (args[0] === 'buy') {
      const ticketCount = args.length > 1 ? parseInt(args[1]) : 1;

      if (isNaN(ticketCount) || ticketCount < 1) {
        await this.safeReply(message, '❌ Please specify a valid number of tickets!\n\nUsage: `?lottery buy <amount>`');
        return;
      }

      if (ticketCount > 50) {
        await this.safeReply(message, '❌ Maximum 50 tickets per purchase!');
        return;
      }

      const totalCost = TICKET_COST * ticketCount;

      if (user.balance < totalCost) {
        await this.safeReply(message, `❌ Insufficient funds! You need **${totalCost.toLocaleString()}** 💰 but only have **${user.balance.toLocaleString()}**.`);
        return;
      }

      this.dataManager.removeCurrency(message.guild.id, message.author.id, totalCost);

      // Process each ticket
      const prizes = [
        { name: 'Grand Prize', amount: 50000, chance: 0.01, emoji: '🏆' },
        { name: 'Big Win', amount: 10000, chance: 0.05, emoji: '💎' },
        { name: 'Win', amount: 5000, chance: 0.10, emoji: '💰' },
        { name: 'Small Win', amount: 2000, chance: 0.15, emoji: '🎁' },
        { name: 'Nothing', amount: 0, chance: 0.69, emoji: '😢' }
      ];

      let totalWinnings = 0;
      const results: string[] = [];

      for (let i = 0; i < ticketCount; i++) {
        const roll = Math.random();
        let cumulative = 0;
        let won = prizes[prizes.length - 1];

        for (const prize of prizes) {
          cumulative += prize.chance;
          if (roll < cumulative) {
            won = prize;
            break;
          }
        }

        totalWinnings += won.amount;
        if (won.amount > 0) {
          results.push(`${won.emoji} Ticket #${i + 1}: **${won.name}** - ${won.amount.toLocaleString()} 💰`);
        }
      }

      if (totalWinnings > 0) {
        this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, totalWinnings);
      }

      const netProfit = totalWinnings - totalCost;
      const updatedUser = this.dataManager.getUser(message.guild.id, message.author.id);

      const embed = new EmbedBuilder()
        .setColor(totalWinnings > 0 ? 0x00FF00 : 0xFF0000)
        .setTitle('🎟️ Lottery Results!')
        .setDescription(
          `**Tickets purchased:** ${ticketCount}\n` +
          `**Total cost:** ${totalCost.toLocaleString()} 💰\n\n` +
          (results.length > 0 
            ? `**Winning tickets:**\n${results.join('\n')}\n\n`
            : `**No winning tickets** 😢\n\n`) +
          `**Total winnings:** ${totalWinnings.toLocaleString()} 💰\n` +
          `**Net ${netProfit >= 0 ? 'profit' : 'loss'}:** ${Math.abs(netProfit).toLocaleString()} 💰\n\n` +
          `💰 **New balance:** ${updatedUser.balance.toLocaleString()}`
        )
        .setFooter({ text: 'Try your luck again!' });

      await this.safeReply(message, { embeds: [embed] });
    } else {
      await this.safeReply(message, '❌ Invalid command! Use `?lottery` to see info or `?lottery buy <amount>` to buy tickets.');
    }
  }

  private async handleVIP(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    if (args.length === 0) {
      const isVIP = user.vipTier && user.vipExpiry && user.vipExpiry > Date.now();
      
      const embed = new EmbedBuilder()
        .setColor(0xFFD700)
        .setTitle('💎 VIP Membership')
        .setDescription(
          isVIP 
            ? `✅ **Status:** VIP Active\n⏱️ **Expires:** <t:${Math.floor(user.vipExpiry! / 1000)}:R>\n\n**Benefits:**\n• 2x Daily Rewards\n• Access to VIP-only items\n• Exclusive title\n• Priority support`
            : `**Purchase VIP:**\n\`?vip buy 7d\` - 7 days for 50,000\n\`?vip buy 30d\` - 30 days for 150,000`
        );

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    if (args[0] === 'buy') {
      const duration = args[1];
      const costs: { [key: string]: { ms: number; cost: number } } = {
        '7d': { ms: 604800000, cost: 50000 },
        '30d': { ms: 2592000000, cost: 150000 }
      };

      if (!costs[duration]) {
        await this.safeReply(message, '❌ Invalid duration! Use: 7d or 30d');
        return;
      }

      if (user.balance < costs[duration].cost) {
        await this.safeReply(message, `❌ VIP ${duration} costs **${costs[duration].cost.toLocaleString()}** 💰!`);
        return;
      }

      this.dataManager.removeCurrency(message.guild.id, message.author.id, costs[duration].cost);
      user.vipTier = 1;
      user.vipExpiry = Date.now() + costs[duration].ms;

      await this.safeReply(message, `✅ **VIP Activated!**\n⏱️ Expires in ${duration}!`);
    }
  }

  private async handleCurrencySystem(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can toggle the currency system!');
      return;
    }

    if (args.length === 0 || (args[0] !== 'on' && args[0] !== 'off')) {
      await this.safeReply(message, 'Usage: ?currencysystem <on|off>');
      return;
    }

    const enabled = args[0] === 'on';
    this.dataManager.setCurrencySystemEnabled(message.guild.id, enabled);

    await this.safeReply(message, `✅ Currency system ${enabled ? 'ENABLED' : 'DISABLED'}! ${enabled ? 'Users will earn currency from messages.' : 'Users will no longer earn currency from messages.'}`);
  }

  private parseDuration(durationStr: string): number | null {
    const match = durationStr.match(/^(\d+)([dhms])$/i);
    if (!match) return null;

    const amount = parseInt(match[1]);
    const unit = match[2].toLowerCase();

    const multipliers: { [key: string]: number } = {
      's': 1000,
      'm': 60 * 1000,
      'h': 60 * 60 * 1000,
      'd': 24 * 60 * 60 * 1000
    };

    return amount * (multipliers[unit] || 0);
  }

  private getCurrentBaseEarnings(guildId: string): number {
    const settings = this.dataManager.getServerSettings(guildId);
    const baseEarnings = settings.baseCurrencyPerMessage || 100;
    
    // Check if temporary base has expired
    if (settings.baseEarningsExpiry && settings.baseEarningsExpiry <= Date.now()) {
      // Temporary base has expired, reset to default
      return 100;
    }
    
    return baseEarnings;
  }

  private async handleBase(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can change the base earnings!');
      return;
    }

    const settings = this.dataManager.getServerSettings(message.guild.id);

    // View current base
    if (args.length === 0) {
      const currentBase = settings.baseCurrencyPerMessage || 100;
      const isTemporary = settings.baseEarningsExpiry && settings.baseEarningsExpiry > Date.now();
      const timeLeft = isTemporary ? Math.ceil((settings.baseEarningsExpiry! - Date.now()) / 1000) : 0;
      
      let statusText = `**Current Base:** \`${currentBase} currency/message\``;
      if (isTemporary) {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        statusText += ` ⏱️ (Temporary, expires in ${minutes}m ${seconds}s)`;
      }

      const embed = new EmbedBuilder()
        .setColor(0x3498DB)
        .setTitle('💰 Message Base Earnings')
        .setDescription(`${statusText}\n\n**With Boosts:**\n• 1x Boost: ${currentBase * 1} currency/message\n• 2x Boost: ${currentBase * 2} currency/message\n• 10x Boost: ${currentBase * 10} currency/message\n• 100x Boost: ${currentBase * 100} currency/message`)
        .addFields(
          { name: 'Set New Base (Permanent)', value: '`?base set <amount>` • Set base earnings per message permanently', inline: false },
          { name: 'Set Temporary Base', value: '`?base set <amount> <duration>` • Set base for a specific time', inline: false },
          { name: 'Duration Format', value: '`1s`, `30m`, `2h`, `1d` (seconds, minutes, hours, days)', inline: false },
          { name: 'Examples', value: '`?base set 500 1d` • 500 currency/msg for 24 hours\n`?base set 200` • 200 currency/msg permanently', inline: false }
        )
        .setFooter({ text: 'Boosts multiply the base earnings' });
      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    // Handle "set" subcommand
    if (args[0].toLowerCase() !== 'set') {
      await this.safeReply(message, '❌ Usage: `?base set <amount> [duration]`\nExample: `?base set 500 1d`');
      return;
    }

    if (args.length < 2) {
      await this.safeReply(message, '❌ Usage: `?base set <amount> [duration]`\nExample: `?base set 500 1d`');
      return;
    }

    const newBase = parseInt(args[1]);
    if (isNaN(newBase) || newBase < 1) {
      await this.safeReply(message, '❌ Invalid amount! Base must be a positive number.\n\nUsage: `?base set <amount> [duration]`');
      return;
    }

    if (newBase > 1000000) {
      await this.safeReply(message, '❌ Base is too high! Maximum is 1,000,000 currency per message.');
      return;
    }

    settings.baseCurrencyPerMessage = newBase;

    // Handle optional duration
    if (args.length >= 3) {
      const durationMs = this.parseDuration(args[2]);
      if (!durationMs) {
        await this.safeReply(message, '❌ Invalid duration! Use format: `1s`, `30m`, `2h`, `1d`\nExample: `?base set 500 1d`');
        return;
      }
      settings.baseEarningsExpiry = Date.now() + durationMs;
    } else {
      // Permanent - remove expiry
      settings.baseEarningsExpiry = undefined;
    }

    this.dataManager.saveData();

    const durationStr = args.length >= 3 
      ? ` for ${args[2]}`
      : ' permanently';

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('✅ Base Earnings Updated!')
      .setDescription(`**New Base:** \`${newBase} currency/message\`${durationStr}\n\n**Earnings with Boosts:**\n• 1x Boost: ${newBase * 1} currency/message\n• 2x Boost: ${newBase * 2} currency/message\n• 10x Boost: ${newBase * 10} currency/message`)
      .setFooter({ text: 'Changes apply immediately to all users' });
    
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleDismegleToggle(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can toggle Dismegle features!');
      return;
    }

    if (args.length === 0 || (args[0] !== 'on' && args[0] !== 'off')) {
      await this.safeReply(message, 'Usage: ?dismegle <on|off>');
      return;
    }

    const enabled = args[0] === 'on';
    this.dataManager.setDismegleEnabled(message.guild.id, enabled);

    await this.safeReply(message, `✅ Dismegle features ${enabled ? 'ENABLED' : 'DISABLED'}! ${enabled ? 'Users can now use random chat matching!' : 'Random chat features are disabled.'}`);
  }

  private async handleTokenConfig(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can configure token shop!');
      return;
    }

    const config = this.dataManager.getRotatingShopConfig(message.guild.id);

    if (args.length === 0) {
      const muteTimeText = config.muteTokenDuration >= 60000
        ? `${Math.floor(config.muteTokenDuration / 60000)} minute${Math.floor(config.muteTokenDuration / 60000) !== 1 ? 's' : ''}`
        : `${Math.floor(config.muteTokenDuration / 1000)} second${Math.floor(config.muteTokenDuration / 1000) !== 1 ? 's' : ''}`;
      
      const nicknameTimeText = config.nicknameTokenDuration >= 60000
        ? `${Math.floor(config.nicknameTokenDuration / 60000)} minute${Math.floor(config.nicknameTokenDuration / 60000) !== 1 ? 's' : ''}`
        : `${Math.floor(config.nicknameTokenDuration / 1000)} second${Math.floor(config.nicknameTokenDuration / 1000) !== 1 ? 's' : ''}`;

      const timeUntilRestock = config.lastRestock > 0 
        ? (config.lastRestock + 3600000) - Date.now()
        : 0;
      const minutesLeft = Math.floor(timeUntilRestock / 60000);
      const secondsLeft = Math.floor((timeUntilRestock % 60000) / 1000);

      const embed = new EmbedBuilder()
        .setColor(0x9B59B6)
        .setTitle('🎫 Rotating Token Shop Configuration')
        .setDescription(
          `**Status:** ${config.enabled ? '✅ ENABLED' : '❌ DISABLED'}\n` +
          `**Stock:** 2 tokens per hour\n` +
          (config.lastRestock > 0 ? `**Next Restock:** \`${minutesLeft}m ${secondsLeft}s\`\n` : '') +
          `**Current Tokens:** ${config.currentTokens.length > 0 ? config.currentTokens.map(t => t.replace('token_', '')).join(', ') : 'None (not restocked yet)'}`
        )
        .addFields(
          {
            name: '🔇 Timeout Token',
            value: `💰 Price: **${config.muteTokenPrice.toLocaleString()}**\n⏱️ Duration: **${muteTimeText}**\n🎲 22% chance for 10s`,
            inline: true
          },
          {
            name: '📝 Nickname Token',
            value: `💰 Price: **${config.nicknameTokenPrice.toLocaleString()}**\n⏱️ Duration: **${nicknameTimeText}**`,
            inline: true
          }
        )
        .setFooter({ text: 'Use ?tokenconfig <on/off> to toggle | ?tokenconfig <mute/nickname> <price/duration> <value>' });

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    if (args[0] === 'on' || args[0] === 'off') {
      const enabled = args[0] === 'on';
      this.dataManager.setRotatingShopConfig(message.guild.id, { enabled });
      await this.safeReply(message, `✅ Token shop ${enabled ? 'ENABLED' : 'DISABLED'}! ${enabled ? 'Tokens are now available in the shop!' : 'Tokens have been removed from the shop.'}`);
      return;
    }

    if (args.length < 3 || (args[0] !== 'mute' && args[0] !== 'nickname') || (args[1] !== 'price' && args[1] !== 'duration')) {
      await this.safeReply(message, '❌ Usage: `?tokenconfig <mute/nickname> <price/duration> <value>`\nExample: `?tokenconfig mute price 20000` or `?tokenconfig mute duration 5s` or `?tokenconfig nickname duration 1m`');
      return;
    }

    const tokenType = args[0];
    const setting = args[1];
    
    if (setting === 'price') {
      const value = parseInt(args[2]);
      if (isNaN(value) || value <= 0) {
        await this.safeReply(message, '❌ Please provide a valid positive number!');
        return;
      }
      
      if (tokenType === 'mute') {
        this.dataManager.setRotatingShopConfig(message.guild.id, { muteTokenPrice: value });
        await this.safeReply(message, `✅ Timeout token price set to **${value.toLocaleString()}** 💰!`);
      } else {
        this.dataManager.setRotatingShopConfig(message.guild.id, { nicknameTokenPrice: value });
        await this.safeReply(message, `✅ Nickname token price set to **${value.toLocaleString()}** 💰!`);
      }
    } else {
      // Duration setting - support both seconds (s) and minutes (m)
      const durationStr = args[2].toLowerCase();
      let duration: number;
      let durationText: string;
      
      if (durationStr.endsWith('s')) {
        const seconds = parseInt(durationStr.slice(0, -1));
        if (isNaN(seconds) || seconds <= 0) {
          await this.safeReply(message, '❌ Please provide a valid positive number! Format: `5s` for 5 seconds or `1m` for 1 minute');
          return;
        }
        duration = seconds * 1000;
        durationText = `${seconds} second${seconds !== 1 ? 's' : ''}`;
      } else if (durationStr.endsWith('m')) {
        const minutes = parseInt(durationStr.slice(0, -1));
        if (isNaN(minutes) || minutes <= 0) {
          await this.safeReply(message, '❌ Please provide a valid positive number! Format: `5s` for 5 seconds or `1m` for 1 minute');
          return;
        }
        duration = minutes * 60000;
        durationText = `${minutes} minute${minutes !== 1 ? 's' : ''}`;
      } else {
        // Default to minutes if no suffix
        const value = parseInt(durationStr);
        if (isNaN(value) || value <= 0) {
          await this.safeReply(message, '❌ Please provide a valid duration! Format: `5s` for 5 seconds or `1m` for 1 minute');
          return;
        }
        duration = value * 60000;
        durationText = `${value} minute${value !== 1 ? 's' : ''}`;
      }
      
      if (tokenType === 'mute') {
        this.dataManager.setRotatingShopConfig(message.guild.id, { muteTokenDuration: duration });
        await this.safeReply(message, `✅ Timeout token duration set to **${durationText}**!`);
      } else {
        this.dataManager.setRotatingShopConfig(message.guild.id, { nicknameTokenDuration: duration });
        await this.safeReply(message, `✅ Nickname token duration set to **${durationText}**!`);
      }
    }
  }

  private async handleFindChat(message: Message): Promise<void> {
    if (!message.guild) return;

    const settings = this.dataManager.getServerSettings(message.guild.id);
    if (!settings.dismegleEnabled) {
      await this.safeReply(message, '❌ Dismegle features are disabled on this server!');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    if (user.activeChatSession) {
      await this.safeReply(message, '❌ You\'re already in a chat! Use `?leave` to exit first.');
      return;
    }

    const queue = this.dataManager.getMatchQueue(message.guild.id);
    
    if (queue['1v1'].includes(message.author.id)) {
      await this.safeReply(message, '⏳ You\'re already in the queue! Please wait...');
      return;
    }

    if (queue['1v1'].length > 0) {
      const partnerId = queue['1v1'].shift()!;
      this.dataManager.setMatchQueue(message.guild.id, queue);

      if (partnerId === message.author.id) {
        queue['1v1'].push(message.author.id);
        this.dataManager.setMatchQueue(message.guild.id, queue);
        await this.safeReply(message, '⏳ Searching for a chat partner...');
        return;
      }

      await this.createChatSession(message.guild, [message.author.id, partnerId], '1v1');
    } else {
      queue['1v1'].push(message.author.id);
      this.dataManager.setMatchQueue(message.guild.id, queue);
      await this.safeReply(message, '⏳ Searching for a chat partner...');
    }
  }

  private async handleFindGroup(message: Message): Promise<void> {
    if (!message.guild) return;

    const settings = this.dataManager.getServerSettings(message.guild.id);
    if (!settings.dismegleEnabled) {
      await this.safeReply(message, '❌ Dismegle features are disabled on this server!');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    if (user.activeChatSession) {
      await this.safeReply(message, '❌ You\'re already in a chat! Use `?leave` to exit first.');
      return;
    }

    const queue = this.dataManager.getMatchQueue(message.guild.id);

    if (queue['group'].includes(message.author.id)) {
      await this.safeReply(message, '⏳ You\'re already in the queue! Please wait...');
      return;
    }

    queue['group'].push(message.author.id);
    this.dataManager.setMatchQueue(message.guild.id, queue);

    if (queue['group'].length >= 4) {
      const members = queue['group'].splice(0, 4);
      this.dataManager.setMatchQueue(message.guild.id, queue);
      await this.createChatSession(message.guild, members, 'group');
    } else {
      await this.safeReply(message, `⏳ Group chat queue (${queue['group'].length}/4)... Waiting for more users!`);
    }
  }

  private async handleFindVoice(message: Message): Promise<void> {
    if (!message.guild) return;

    const settings = this.dataManager.getServerSettings(message.guild.id);
    if (!settings.dismegleEnabled) {
      await this.safeReply(message, '❌ Dismegle features are disabled on this server!');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    if (user.activeChatSession) {
      await this.safeReply(message, '❌ You\'re already in a chat! Use `?leave` to exit first.');
      return;
    }

    const queue = this.dataManager.getMatchQueue(message.guild.id);

    if (queue['1v1voice'].includes(message.author.id)) {
      await this.safeReply(message, '⏳ You\'re already in the queue! Please wait...');
      return;
    }

    if (queue['1v1voice'].length > 0) {
      const partnerId = queue['1v1voice'].shift()!;
      this.dataManager.setMatchQueue(message.guild.id, queue);

      if (partnerId === message.author.id) {
        queue['1v1voice'].push(message.author.id);
        this.dataManager.setMatchQueue(message.guild.id, queue);
        await this.safeReply(message, '⏳ Searching for a voice chat partner...');
        return;
      }

      await this.createChatSession(message.guild, [message.author.id, partnerId], '1v1voice');
    } else {
      queue['1v1voice'].push(message.author.id);
      this.dataManager.setMatchQueue(message.guild.id, queue);
      await this.safeReply(message, '⏳ Searching for a voice chat partner...');
    }
  }

  private async handleFindGroupVoice(message: Message): Promise<void> {
    if (!message.guild) return;

    const settings = this.dataManager.getServerSettings(message.guild.id);
    if (!settings.dismegleEnabled) {
      await this.safeReply(message, '❌ Dismegle features are disabled on this server!');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    if (user.activeChatSession) {
      await this.safeReply(message, '❌ You\'re already in a chat! Use `?leave` to exit first.');
      return;
    }

    const queue = this.dataManager.getMatchQueue(message.guild.id);

    if (queue['groupvoice'].includes(message.author.id)) {
      await this.safeReply(message, '⏳ You\'re already in the queue! Please wait...');
      return;
    }

    queue['groupvoice'].push(message.author.id);
    this.dataManager.setMatchQueue(message.guild.id, queue);

    if (queue['groupvoice'].length >= 4) {
      const members = queue['groupvoice'].splice(0, 4);
      this.dataManager.setMatchQueue(message.guild.id, queue);
      await this.createChatSession(message.guild, members, 'groupvoice');
    } else {
      await this.safeReply(message, `⏳ Group voice queue (${queue['groupvoice'].length}/4)... Waiting for more users!`);
    }
  }

  private removeUserFromAllQueues(guildId: string, userId: string): void {
    const queue = this.dataManager.getMatchQueue(guildId);
    for (const queueType of ['1v1', 'group', '1v1voice', 'groupvoice']) {
      const index = queue[queueType].indexOf(userId);
      if (index > -1) {
        queue[queueType].splice(index, 1);
      }
    }
    this.dataManager.setMatchQueue(guildId, queue);
  }

  private async createChatSession(guild: any, userIds: string[], type: '1v1' | 'group' | '1v1voice' | 'groupvoice'): Promise<void> {
    for (const userId of userIds) {
      this.removeUserFromAllQueues(guild.id, userId);
    }

    try {
      const panelData = this.dataManager['data'].dismeglePanels?.[guild.id];
      if (!panelData) {
        console.error('No panel channel found for Dismegle');
        return;
      }

      const panelChannel = await guild.channels.fetch(panelData.channelId);
      if (!panelChannel || !panelChannel.isTextBased()) {
        console.error('Panel channel not found or not text-based');
        return;
      }

      const sessionId = Date.now().toString() + Math.random().toString(36).substr(2, 9);
      const isVoice = type === '1v1voice' || type === 'groupvoice';

      const usernames = await Promise.all(
        userIds.map(async id => {
          try {
            const member = await guild.members.fetch(id);
            return member.user.username;
          } catch {
            return 'User';
          }
        })
      );

      const threadName = usernames.join(' & ');
      
      const thread = await panelChannel.threads.create({
        name: `💬 ${threadName.substring(0, 90)}`,
        type: ChannelType.PrivateThread,
        invitable: false,
        reason: 'Dismegle private chat session'
      });

      let voiceChannel = null;
      if (isVoice) {
        try {
          let category = guild.channels.cache.find((c: any) => c.name === 'Dismegle Voice' && c.type === 4);
          if (!category) {
            category = await guild.channels.create({
              name: 'Dismegle Voice',
              type: 4
            });
          }

          voiceChannel = await guild.channels.create({
            name: `🎤 ${threadName.substring(0, 90)}`,
            type: 2,
            parent: category.id,
            permissionOverwrites: [
              {
                id: guild.id,
                deny: ['ViewChannel']
              },
              ...userIds.map(id => ({
                id: id,
                allow: ['ViewChannel', 'Connect', 'Speak']
              }))
            ]
          });
        } catch (error) {
          console.error('Error creating voice channel:', error);
        }
      }

      const sessions = this.dataManager.getChatSessions();
      sessions.push({
        id: sessionId,
        guildId: guild.id,
        type,
        users: userIds,
        channelId: thread.id,
        voiceChannelId: voiceChannel?.id,
        startTime: Date.now(),
        lastActivityTime: Date.now(),
        isThread: true,
        threadId: thread.id,
        messages: []
      });
      this.dataManager.setChatSessions(sessions);

      for (const userId of userIds) {
        const user = this.dataManager.getUser(guild.id, userId);
        user.activeChatSession = sessionId;
      }

      const embed = new EmbedBuilder()
        .setColor(0xFF1493)
        .setTitle('🎲 Chat Session Started!')
        .setDescription(
          `You've been matched!\n\n` +
          `**Type:** ${type === '1v1' ? '1-on-1 Text' : type === 'group' ? 'Group Text' : type === '1v1voice' ? '1-on-1 Voice' : 'Group Voice'}\n` +
          `**Users:** ${userIds.length}\n\n` +
          `💬 Start chatting now!\n` +
          (isVoice ? `🎤 Join the voice channel to talk!\n` : '') +
          `**Commands:**\n` +
          `• \`?save\` - Export chat log to your DMs\n` +
          `• \`?leave\` - End chat and earn rewards!`
        );

      await thread.send({ content: userIds.map(id => `<@${id}>`).join(' '), embeds: [embed] });
    } catch (error) {
      console.error('Error creating chat session:', error);
    }
  }

  private async handleLeaveChat(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    
    if (!user.activeChatSession) {
      this.removeUserFromAllQueues(message.guild.id, message.author.id);
      await this.safeReply(message, '❌ You\'re not in a chat session! (Removed you from any queues)');
      return;
    }

    const sessions = this.dataManager.getChatSessions();
    const sessionIndex = sessions.findIndex(s => s.id === user.activeChatSession);

    if (sessionIndex === -1) {
      user.activeChatSession = undefined;
      await this.safeReply(message, '❌ Chat session not found!');
      return;
    }

    const session = sessions[sessionIndex];
    const duration = Math.floor((Date.now() - session.startTime) / 1000 / 60);
    const reward = Math.max(100, duration * 50);

    try {
      const embed = new EmbedBuilder()
        .setColor(0xFF6B6B)
        .setTitle('👋 Chat Ended')
        .setDescription(`Thanks for chatting!\n⏱️ Duration: ${duration} minute(s)\n💰 Reward: ${reward.toLocaleString()} currency each!`);

      if (session.isThread && session.threadId) {
        const thread = await message.guild.channels.fetch(session.threadId);
        if (thread && thread.isThread()) {
          await thread.send({ embeds: [embed] });
          setTimeout(async () => {
            try {
              await thread.setArchived(true);
              await thread.setLocked(true);
            } catch (err) {
              console.error('Error archiving thread:', err);
            }
          }, 10000);
        }
      } else {
        const channel = await message.guild.channels.fetch(session.channelId);
        if (channel) {
          await (channel as any).send({ embeds: [embed] });
          setTimeout(async () => {
            try {
              await channel.delete();
            } catch (err) {
              console.error('Error deleting channel:', err);
            }
          }, 10000);
        }
      }

      if (session.voiceChannelId) {
        try {
          const voiceChannel = await message.guild.channels.fetch(session.voiceChannelId);
          if (voiceChannel) {
            setTimeout(async () => {
              try {
                await voiceChannel.delete();
              } catch (err) {
                console.error('Error deleting voice channel:', err);
              }
            }, 10000);
          }
        } catch (error) {
          console.error('Error fetching voice channel:', error);
        }
      }
    } catch (error) {
      console.error('Error ending chat:', error);
    }

    const settings = this.dataManager.getServerSettings(message.guild.id);

    for (const userId of session.users) {
      const u = this.dataManager.getUser(message.guild.id, userId);
      u.activeChatSession = undefined;
      if (!u.chatsCompleted) u.chatsCompleted = 0;
      if (!u.totalChatTime) u.totalChatTime = 0;
      u.chatsCompleted++;
      u.totalChatTime += duration;
      
      if (settings.currencySystemEnabled) {
        this.dataManager.addCurrencyRaw(message.guild.id, userId, reward);
      }
    }

    sessions.splice(sessionIndex, 1);
    this.dataManager.setChatSessions(sessions);

    await this.safeReply(message, `✅ Chat ended! You earned **${reward.toLocaleString()}** 💰`);
  }

  private async handlePanel(message: Message): Promise<void> {
    if (!message.guild) return;

    if (!this.isOwnerOrManager(message)) {
      await this.safeReply(message, '❌ Only server owners or managers can create Dismegle panels!');
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(0xFF1493)
      .setTitle('🎲 DISMEGLE - Random Chat Matching')
      .setDescription(
        '**Welcome to Dismegle!**\n\n' +
        'Click a button below to join a queue and get matched with random users!\n\n' +
        '💬 **Text Chat** - Match for text conversations\n' +
        '🎤 **Voice Chat** - Match for voice conversations\n\n' +
        '**How it works:**\n' +
        '1. Click a button to join the queue\n' +
        '2. Wait for a match\n' +
        '3. Chat in a private thread\n' +
        '4. Use `?leave` to end and earn rewards!\n\n' +
        '**Other commands:**\n' +
        '• `?interests add [tags]` - Add interests for better matching\n' +
        '• `?save` - Export chat logs to your DMs\n' +
        '• `?leave` - Leave current chat session'
      )
      .setFooter({ text: 'Earn currency based on chat duration!' });

    const row = new ActionRowBuilder<ButtonBuilder>()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('dismegle_text')
          .setLabel('💬 Text Chat')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('dismegle_voice')
          .setLabel('🎤 Voice Chat')
          .setStyle(ButtonStyle.Success)
      );

    if (!message.channel.isSendable()) {
      await this.safeReply(message, '❌ Cannot send panel in this channel type!');
      return;
    }
    
    const panelMessage = await message.channel.send({ embeds: [embed], components: [row] });

    if (!this.dataManager['data'].dismeglePanels) {
      this.dataManager['data'].dismeglePanels = {};
    }
    this.dataManager['data'].dismeglePanels[message.guild.id] = {
      channelId: message.channel.id,
      messageId: panelMessage.id
    };
    this.dataManager['markDirty']();

    await this.safeReply(message, '✅ Dismegle panel created!');
  }

  private async handleSaveChat(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    
    if (!user.activeChatSession) {
      await this.safeReply(message, '❌ You\'re not in an active chat session!');
      return;
    }

    const sessions = this.dataManager.getChatSessions();
    const session = sessions.find(s => s.id === user.activeChatSession);

    if (!session || !session.messages || session.messages.length === 0) {
      await this.safeReply(message, '❌ No messages to save yet!');
      return;
    }

    try {
      let chatLog = `Dismegle Chat Log\n`;
      chatLog += `Session ID: ${session.id}\n`;
      chatLog += `Started: ${new Date(session.startTime).toLocaleString()}\n`;
      chatLog += `Type: ${session.type}\n`;
      chatLog += `Users: ${session.users.length}\n`;
      chatLog += `\n${'='.repeat(50)}\n\n`;

      for (const msg of session.messages) {
        const timestamp = new Date(msg.timestamp).toLocaleTimeString();
        const username = await message.guild.members.fetch(msg.userId).then(m => m.user.username).catch(() => 'Unknown User');
        chatLog += `[${timestamp}] ${username}: ${msg.content}\n`;
      }

      const buffer = Buffer.from(chatLog, 'utf-8');
      
      await message.author.send({
        content: '📝 Here\'s your chat log!',
        files: [{
          attachment: buffer,
          name: `dismegle-chat-${session.id}.txt`
        }]
      });

      await this.safeReply(message, '✅ Chat log sent to your DMs!');
    } catch (error) {
      console.error('Error saving chat:', error);
      await this.safeReply(message, '❌ Failed to send chat log. Make sure your DMs are open!');
    }
  }

  public async handleFindChatWithInterests(guild: any, userId: string): Promise<void> {
    const user = this.dataManager.getUser(guild.id, userId);
    const queue = this.dataManager.getMatchQueue(guild.id);
    
    if (queue['1v1'].includes(userId)) return;

    const bestMatch = this.findBestInterestMatch(guild.id, userId, queue['1v1']);
    
    if (bestMatch) {
      const partnerId = bestMatch;
      const index = queue['1v1'].indexOf(partnerId);
      queue['1v1'].splice(index, 1);
      this.dataManager.setMatchQueue(guild.id, queue);
      await this.createChatSession(guild, [userId, partnerId], '1v1');
    } else {
      queue['1v1'].push(userId);
      this.dataManager.setMatchQueue(guild.id, queue);
    }
  }

  public async handleFindVoiceWithInterests(guild: any, userId: string): Promise<void> {
    const user = this.dataManager.getUser(guild.id, userId);
    const queue = this.dataManager.getMatchQueue(guild.id);
    
    if (queue['1v1voice'].includes(userId)) return;

    const bestMatch = this.findBestInterestMatch(guild.id, userId, queue['1v1voice']);
    
    if (bestMatch) {
      const partnerId = bestMatch;
      const index = queue['1v1voice'].indexOf(partnerId);
      queue['1v1voice'].splice(index, 1);
      this.dataManager.setMatchQueue(guild.id, queue);
      await this.createChatSession(guild, [userId, partnerId], '1v1voice');
    } else {
      queue['1v1voice'].push(userId);
      this.dataManager.setMatchQueue(guild.id, queue);
    }
  }

  private findBestInterestMatch(guildId: string, userId: string, queue: string[]): string | null {
    if (queue.length === 0) return null;

    const user = this.dataManager.getUser(guildId, userId);
    const userInterests = user.interests || [];
    const userBlockedUsers = user.blockedUsers || [];

    const availableQueue = queue.filter(candidateId => {
      const candidate = this.dataManager.getUser(guildId, candidateId);
      const candidateBlockedUsers = candidate.blockedUsers || [];
      
      return !userBlockedUsers.includes(candidateId) && !candidateBlockedUsers.includes(userId);
    });

    if (availableQueue.length === 0) return null;

    if (userInterests.length === 0) {
      return availableQueue[0];
    }

    let bestMatch: string | null = null;
    let highestScore = -1;

    for (const candidateId of availableQueue) {
      const candidate = this.dataManager.getUser(guildId, candidateId);
      const candidateInterests = candidate.interests || [];
      
      const commonInterests = userInterests.filter(i => candidateInterests.includes(i));
      const score = commonInterests.length;

      if (score > highestScore) {
        highestScore = score;
        bestMatch = candidateId;
      }
    }

    return bestMatch || availableQueue[0];
  }

  private async handleInterests(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    if (!user.interests) {
      user.interests = [];
    }

    if (args.length === 0) {
      const embed = new EmbedBuilder()
        .setColor(0x9B59B6)
        .setTitle('🎯 Your Interests')
        .setDescription(
          user.interests.length > 0
            ? `**Your interests:**\n${user.interests.map(i => `• ${i}`).join('\n')}`
            : 'You haven\'t added any interests yet!\n\n**Add interests to get better matches!**'
        )
        .addFields({
          name: 'Commands',
          value:
            '`?interests add cooking, anime, gaming` - Add interests\n' +
            '`?interests remove cooking` - Remove an interest\n' +
            '`?interests clear` - Clear all interests'
        });

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    const subcommand = args[0].toLowerCase();

    if (subcommand === 'add') {
      const interestsToAdd = args.slice(1).join(' ').split(',').map(i => i.trim().toLowerCase()).filter(i => i.length > 0);

      if (interestsToAdd.length === 0) {
        await this.safeReply(message, '❌ Please provide interests to add!\nExample: `?interests add cooking, anime, gaming`');
        return;
      }

      const added: string[] = [];
      for (const interest of interestsToAdd) {
        if (!user.interests.includes(interest)) {
          user.interests.push(interest);
          added.push(interest);
        }
      }

      if (added.length > 0) {
        await this.safeReply(message, `✅ Added interests: ${added.join(', ')}\n💡 You'll now be matched with users who share these interests!`);
      } else {
        await this.safeReply(message, '❌ All those interests are already in your list!');
      }
    } else if (subcommand === 'remove') {
      const interestToRemove = args.slice(1).join(' ').trim().toLowerCase();

      if (!interestToRemove) {
        await this.safeReply(message, '❌ Please specify an interest to remove!\nExample: `?interests remove cooking`');
        return;
      }

      const index = user.interests.indexOf(interestToRemove);
      if (index > -1) {
        user.interests.splice(index, 1);
        await this.safeReply(message, `✅ Removed interest: **${interestToRemove}**`);
      } else {
        await this.safeReply(message, '❌ That interest is not in your list!');
      }
    } else if (subcommand === 'clear') {
      user.interests = [];
      await this.safeReply(message, '✅ Cleared all your interests!');
    } else {
      await this.safeReply(message, '❌ Invalid subcommand! Use: `add`, `remove`, or `clear`');
    }
  }

  private async handleFlag(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    if (!user.blockedUsers) {
      user.blockedUsers = [];
    }

    if (args.length === 0) {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('🚫 Blocked Users')
        .setDescription(
          user.blockedUsers.length > 0
            ? `**You won't be matched with:**\n${user.blockedUsers.map(id => `• <@${id}>`).join('\n')}`
            : 'You haven\'t blocked anyone yet!\n\n**Block users to avoid being matched with them!**'
        )
        .addFields({
          name: 'Commands',
          value:
            '`?flag @user` - Block a user from matching with you\n' +
            '`?flag <userID>` - Block by user ID\n' +
            '`?flag list` - View your blocked users\n' +
            '`?flag clear` - Unblock all users'
        });

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    const subcommand = args[0].toLowerCase();

    if (subcommand === 'list') {
      const embed = new EmbedBuilder()
        .setColor(0xFF0000)
        .setTitle('🚫 Blocked Users')
        .setDescription(
          user.blockedUsers.length > 0
            ? `**You won't be matched with:**\n${user.blockedUsers.map(id => `• <@${id}>`).join('\n')}`
            : 'You haven\'t blocked anyone yet!'
        );

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    if (subcommand === 'clear') {
      user.blockedUsers = [];
      await this.safeReply(message, '✅ Cleared all blocked users! You can now be matched with anyone.');
      return;
    }

    const mentionedUser = message.mentions.users.first();
    let targetId: string | null = null;

    if (mentionedUser) {
      targetId = mentionedUser.id;
    } else if (args[0].match(/^\d+$/)) {
      targetId = args[0];
    }

    if (!targetId) {
      await this.safeReply(message, '❌ Please mention a user or provide their user ID!\nExample: `?flag @user` or `?flag 123456789`');
      return;
    }

    if (targetId === message.author.id) {
      await this.safeReply(message, '❌ You can\'t block yourself!');
      return;
    }

    try {
      await message.guild.members.fetch(targetId);
    } catch {
      await this.safeReply(message, '❌ User not found in this server!');
      return;
    }

    if (user.blockedUsers.includes(targetId)) {
      user.blockedUsers = user.blockedUsers.filter(id => id !== targetId);
      await this.safeReply(message, `✅ Unblocked <@${targetId}>! You can now be matched with them.`);
    } else {
      user.blockedUsers.push(targetId);
      await this.safeReply(message, `🚫 Blocked <@${targetId}>! You won't be matched with them in Dismegle.`);
    }
  }

  private async handleCode(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (args.length === 0) {
      const embed = new EmbedBuilder()
        .setColor(0xFFD700)
        .setTitle('🎟️ Redeem Code System')
        .setDescription(
          '**Claim codes to earn currency rewards!**\n\n' +
          '**User Commands:**\n' +
          '`?code claim <code>` - Claim a code for rewards\n\n' +
          '**Server Owner Commands:**\n' +
          '`?code create <name> <amount>` - Create a new code\n' +
          '`?code list` - View all active codes\n' +
          '`?code delete <name>` - Delete a code\n\n' +
          '**Example:**\n' +
          '`?code create starter 1000` - Creates "starter" code worth 1000💰\n' +
          '`?code claim starter` - Claims the starter code'
        );
      
      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    const subcommand = args[0].toLowerCase();

    if (subcommand === 'claim') {
      if (args.length < 2) {
        await this.safeReply(message, '❌ Usage: `?code claim <code>`\nExample: `?code claim starter`');
        return;
      }

      const codeName = args[1].toLowerCase();
      const result = this.dataManager.claimRedeemCode(message.guild.id, codeName, message.author.id);

      if (result.success) {
        const embed = new EmbedBuilder()
          .setColor(0x2ECC71)
          .setTitle('🎉 Code Claimed!')
          .setDescription(`${result.message}\n\n💰 **New Balance:** ${this.dataManager.getUser(message.guild.id, message.author.id).balance.toLocaleString()}`);
        
        await this.safeReply(message, { embeds: [embed] });
      } else {
        await this.safeReply(message, result.message);
      }
      return;
    }

    if (subcommand === 'create') {
      if (message.guild.ownerId !== message.author.id) {
        await this.safeReply(message, '❌ Only the server owner can create codes!');
        return;
      }

      if (args.length < 3) {
        await this.safeReply(message, '❌ Usage: `?code create <name> <amount>`\nExample: `?code create starter 1000`');
        return;
      }

      const codeName = args[1].toLowerCase();
      const amount = parseInt(args[2]);

      if (isNaN(amount) || amount <= 0) {
        await this.safeReply(message, '❌ Amount must be a positive number!');
        return;
      }

      if (codeName.length < 2 || codeName.length > 20) {
        await this.safeReply(message, '❌ Code name must be 2-20 characters!');
        return;
      }

      if (!/^[a-z0-9_]+$/.test(codeName)) {
        await this.safeReply(message, '❌ Code name can only contain letters, numbers, and underscores!');
        return;
      }

      const code = this.dataManager.createRedeemCode(message.guild.id, codeName, amount, message.author.id);

      if (!code) {
        await this.safeReply(message, '❌ A code with that name already exists!');
        return;
      }

      const embed = new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('✅ Code Created!')
        .setDescription(
          `**Code Name:** \`${codeName}\`\n` +
          `**Reward:** ${amount.toLocaleString()} 💰\n\n` +
          `Users can claim with: \`?code claim ${codeName}\``
        )
        .setFooter({ text: `Created by ${message.author.username}` });

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    if (subcommand === 'list') {
      if (message.guild.ownerId !== message.author.id) {
        await this.safeReply(message, '❌ Only the server owner can view all codes!');
        return;
      }

      const codes = this.dataManager.getRedeemCodes(message.guild.id);

      if (codes.length === 0) {
        await this.safeReply(message, '❌ No codes have been created yet!\nCreate one with: `?code create <name> <amount>`');
        return;
      }

      const embed = new EmbedBuilder()
        .setColor(0xFFD700)
        .setTitle('🎟️ Active Redeem Codes')
        .setDescription(
          codes.map(c => 
            `**${c.codeName}** - ${c.reward.toLocaleString()} 💰 (${c.claimedBy.length} claims)`
          ).join('\n')
        )
        .setFooter({ text: `Total codes: ${codes.length}` });

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    if (subcommand === 'delete') {
      if (message.guild.ownerId !== message.author.id) {
        await this.safeReply(message, '❌ Only the server owner can delete codes!');
        return;
      }

      if (args.length < 2) {
        await this.safeReply(message, '❌ Usage: `?code delete <name>`\nExample: `?code delete starter`');
        return;
      }

      const codeName = args[1].toLowerCase();
      const success = this.dataManager.deleteRedeemCode(message.guild.id, codeName);

      if (success) {
        await this.safeReply(message, `✅ Deleted code: \`${codeName}\``);
      } else {
        await this.safeReply(message, '❌ Code not found!');
      }
      return;
    }

    await this.safeReply(message, '❌ Invalid subcommand! Use `?code` to see available commands.');
  }

  private async handleSetStaff(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can configure the staff role!');
      return;
    }

    if (args.length === 0) {
      const config = this.dataManager.getStaffShopConfig(message.guild.id);
      
      if (!config.staffRoleId) {
        await this.safeReply(message, '❌ No staff role has been set yet!\n\nUse `?setstaff <role>` to set it.\nExample: `?setstaff @Staff` or `?setstaff Staff`');
        return;
      }

      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle('👔 Staff Shop Configuration')
        .setDescription(
          `**Staff Role:** <@&${config.staffRoleId}>\n` +
          `**Staff Shop:** ${config.enabled ? '✅ Enabled' : '❌ Disabled'}\n\n` +
          `**Commands:**\n` +
          `\`?setstaff <role>\` - Change staff role\n` +
          `\`?staffshop\` - View staff shop (staff only)\n` +
          `\`?setpromotionprice <amount>\` - Set base promotion price\n` +
          `\`?setpromotioncooldown <days>\` - Set promotion cooldown\n` +
          `\`?giftpromotion <@user>\` - Gift a promotion to a user`
        );

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    let roleId: string | undefined;
    const roleArg = args.join(' ');

    const mentionMatch = roleArg.match(/<@&(\d+)>/);
    if (mentionMatch) {
      roleId = mentionMatch[1];
    } else {
      const role = message.guild.roles.cache.find(r => 
        r.name.toLowerCase() === roleArg.toLowerCase()
      );
      if (role) roleId = role.id;
    }

    if (!roleId) {
      await this.safeReply(message, '❌ Role not found! Try mentioning the role or using its exact name.\nExample: `?setstaff @Staff` or `?setstaff Staff`');
      return;
    }

    const role = message.guild.roles.cache.get(roleId);
    if (!role) {
      await this.safeReply(message, '❌ Role not found!');
      return;
    }

    this.dataManager.setStaffShopConfig(message.guild.id, {
      staffRoleId: roleId,
      enabled: true
    });

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('✅ Staff Role Set!')
      .setDescription(
        `**Staff Role:** ${role}\n\n` +
        `Users with this role can now access the staff shop using \`?staffshop\`\n\n` +
        `Staff members can purchase promotions to advance to the next role in the hierarchy.`
      );

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleStaffShop(message: Message): Promise<void> {
    if (!message.guild) return;

    const config = this.dataManager.getStaffShopConfig(message.guild.id);

    if (!config.enabled || !config.staffRoleId) {
      await this.safeReply(message, '❌ The staff shop is not configured!\n\nServer owner can set it up with: `?setstaff <role>`');
      return;
    }

    const member = message.member;
    if (!member) return;

    const hasStaffRole = member.roles.cache.has(config.staffRoleId);
    if (!hasStaffRole && message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ You need the <@&' + config.staffRoleId + '> role to access the staff shop!');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const cooldownCheck = this.dataManager.isPromotionOnCooldown(message.guild.id, message.author.id);

    const memberRoles = Array.from(member.roles.cache.values())
      .filter(r => r.id !== message.guild!.id)
      .sort((a, b) => b.position - a.position);

    let currentRole = memberRoles[0];
    let nextRole = memberRoles.length > 1 ? memberRoles[1] : null;

    const allRoles = Array.from(message.guild.roles.cache.values())
      .filter(r => r.id !== message.guild!.id && !r.managed)
      .sort((a, b) => b.position - a.position);

    if (currentRole) {
      const currentIndex = allRoles.findIndex(r => r.id === currentRole.id);
      if (currentIndex > 0) {
        nextRole = allRoles[currentIndex - 1];
      }
    }

    const promotionPrice = this.dataManager.getCurrentPromotionPrice(message.guild.id, message.author.id);

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('👔 Staff Shop - Role Promotions')
      .setDescription(
        `💰 **Your Balance:** ${user.balance.toLocaleString()}\n\n` +
        `**Current Highest Role:** ${currentRole || 'None'}\n` +
        `**Next Promotion:** ${nextRole ? nextRole.name : 'Max Rank Reached'}\n\n` +
        `**Base Price:** ${config.basePrice.toLocaleString()} 💰\n` +
        `**Total Purchases:** ${config.totalPurchaseCount}\n` +
        `**Cooldown:** ${config.cooldownDays} day${config.cooldownDays !== 1 ? 's' : ''}\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━━`
      );

    if (cooldownCheck.onCooldown && cooldownCheck.timeLeft) {
      const daysLeft = Math.ceil(cooldownCheck.timeLeft / (24 * 60 * 60 * 1000));
      const hoursLeft = Math.ceil((cooldownCheck.timeLeft % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));

      embed.addFields({
        name: '⏳ Promotion Cooldown',
        value: `You are on cooldown!\n**Time Left:** ${daysLeft}d ${hoursLeft}h\n\nYou can purchase another promotion after the cooldown expires.`,
        inline: false
      });
    } else if (!nextRole) {
      embed.addFields({
        name: '⭐ Maximum Rank Achieved',
        value: 'You have reached the highest role available!\nThere are no more promotions to purchase.',
        inline: false
      });
    } else {
      const canAfford = user.balance >= promotionPrice;

      embed.addFields({
        name: '📈 Promotion Available',
        value:
          `💰 **Current Price:** ${promotionPrice.toLocaleString()} ${config.totalPurchaseCount > 0 ? `(Base: ${config.basePrice.toLocaleString()}, 2^${config.totalPurchaseCount})` : ''}\n` +
          `⏱️ **Cooldown:** ${config.cooldownDays} day${config.cooldownDays !== 1 ? 's' : ''} after purchase\n` +
          `🎯 **Next Role:** ${nextRole.name}\n\n` +
          `**To Purchase:** \`?buy promotion\`\n` +
          `**To Activate:** \`?use promotion\`\n\n` +
          `${canAfford ? '✅ You can afford this!' : '🔒 Need more currency'}`,
        inline: false
      });
    }

    embed.setFooter({ text: 'Promotions are purchased with ?buy promotion and activated with ?use promotion' });

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleBuyPromotion(message: Message): Promise<void> {
    if (!message.guild) return;

    const config = this.dataManager.getStaffShopConfig(message.guild.id);

    if (!config.enabled || !config.staffRoleId) {
      await this.safeReply(message, '❌ The staff shop is not configured!\n\nServer owner can set it up with: `?setstaff <role>`');
      return;
    }

    const member = message.member;
    if (!member) return;

    const hasStaffRole = member.roles.cache.has(config.staffRoleId);
    if (!hasStaffRole && message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ You need the <@&' + config.staffRoleId + '> role to purchase promotions!');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const cooldownCheck = this.dataManager.isPromotionOnCooldown(message.guild.id, message.author.id);

    if (cooldownCheck.onCooldown && cooldownCheck.timeLeft) {
      const daysLeft = Math.ceil(cooldownCheck.timeLeft / (24 * 60 * 60 * 1000));
      const hoursLeft = Math.ceil((cooldownCheck.timeLeft % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
      
      await this.safeReply(message, `❌ You are on cooldown!\n\n**Time Left:** ${daysLeft}d ${hoursLeft}h\n\nYou can purchase another promotion after the cooldown expires.`);
      return;
    }

    if (user.inventory.includes('promotion')) {
      await this.safeReply(message, '❌ You already have a promotion in your inventory!\n\nUse it with `?use promotion` before buying another.');
      return;
    }

    const memberRoles = Array.from(member.roles.cache.values())
      .filter(r => r.id !== message.guild!.id)
      .sort((a, b) => b.position - a.position);

    let currentRole = memberRoles[0];
    let nextRole = null;

    const allRoles = Array.from(message.guild.roles.cache.values())
      .filter(r => r.id !== message.guild!.id && !r.managed)
      .sort((a, b) => b.position - a.position);

    if (currentRole) {
      const currentIndex = allRoles.findIndex(r => r.id === currentRole.id);
      if (currentIndex > 0) {
        nextRole = allRoles[currentIndex - 1];
      }
    }

    if (!nextRole) {
      await this.safeReply(message, '❌ You have reached the maximum rank! No more promotions available.');
      return;
    }

    const promotionPrice = this.dataManager.getCurrentPromotionPrice(message.guild.id, message.author.id);

    if (user.balance < promotionPrice) {
      await this.safeReply(message, `❌ You need ${promotionPrice.toLocaleString()} 💰 to buy a promotion!\n\n**Your Balance:** ${user.balance.toLocaleString()}`);
      return;
    }

    this.dataManager.removeCurrency(message.guild.id, message.author.id, promotionPrice);
    this.dataManager.addToInventory(message.guild.id, message.author.id, 'promotion');
    this.dataManager.recordPromotionPurchase(message.guild.id, message.author.id);

    const nextPrice = this.dataManager.getCurrentPromotionPrice(message.guild.id, message.author.id);

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('✅ Promotion Purchased!')
      .setDescription(
        `Successfully purchased a promotion for ${promotionPrice.toLocaleString()} 💰!\n\n` +
        `**Next Role:** ${nextRole.name}\n` +
        `**Cooldown:** ${config.cooldownDays} day${config.cooldownDays !== 1 ? 's' : ''}\n` +
        `**Next Purchase Price:** ${nextPrice.toLocaleString()} 💰 (doubled)\n\n` +
        `Activate your promotion with: \`?use promotion\`\n\n` +
        `💰 **New Balance:** ${user.balance.toLocaleString()}`
      );

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleSetPromotionPrice(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can set promotion prices!');
      return;
    }

    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?setpromotionprice <amount>\n\nExample: `?setpromotionprice 100000`');
      return;
    }

    const price = parseInt(args[0].replace(/,/g, ''));
    if (isNaN(price) || price < 1) {
      await this.safeReply(message, '❌ Please provide a valid price amount (must be 1 or higher)!');
      return;
    }

    this.dataManager.setPromotionBasePrice(message.guild.id, price);

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('✅ Promotion Base Price Updated!')
      .setDescription(
        `**New Base Price:** ${price.toLocaleString()} 💰\n\n` +
        `The price will double after each purchase.\n` +
        `Reset the price multiplier with \`?resetserver\``
      );

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleSetPromotionCooldown(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can set promotion cooldown!');
      return;
    }

    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?setpromotioncooldown <days>\n\nExample: `?setpromotioncooldown 7` for 7 days');
      return;
    }

    const days = parseInt(args[0]);
    if (isNaN(days) || days < 0) {
      await this.safeReply(message, '❌ Please provide a valid number of days (0 or higher)!');
      return;
    }

    this.dataManager.setPromotionCooldown(message.guild.id, days);

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('✅ Promotion Cooldown Updated!')
      .setDescription(
        `**New Cooldown:** ${days} day${days !== 1 ? 's' : ''}\n\n` +
        (days === 0 ? '⚠️ Cooldown disabled! Staff can purchase promotions immediately after using one.' : `Staff must wait ${days} days between promotion purchases.`)
      );

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleGiftPromotion(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can gift promotions!');
      return;
    }

    if (args.length < 1) {
      await this.safeReply(message, 'Usage: ?giftpromotion <@user>\n\nExample: `?giftpromotion @JohnDoe`');
      return;
    }

    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      await this.safeReply(message, '❌ Please mention a user to gift a promotion to!');
      return;
    }

    if (targetUser.bot) {
      await this.safeReply(message, '❌ You cannot gift promotions to bots!');
      return;
    }

    const user = this.dataManager.getUser(message.guild.id, targetUser.id);
    
    if (user.inventory.includes('promotion')) {
      await this.safeReply(message, `❌ ${targetUser.username} already has a promotion in their inventory!`);
      return;
    }

    this.dataManager.addToInventory(message.guild.id, targetUser.id, 'promotion');

    const embed = new EmbedBuilder()
      .setColor(0x2ECC71)
      .setTitle('🎁 Promotion Gifted!')
      .setDescription(
        `Successfully gifted a promotion to ${targetUser}!\n\n` +
        `They can activate it with: \`?use promotion\`\n\n` +
        `This gift does not start a cooldown for the recipient.`
      );

    await this.safeReply(message, { embeds: [embed] });

    try {
      await targetUser.send(
        `🎁 You received a **promotion** from ${message.author.username} in **${message.guild.name}**!\n\n` +
        `Use \`?use promotion\` in the server to activate it and get your next role!`
      );
    } catch (error) {
      // User has DMs disabled, that's okay
    }
  }

  private async handleUsePromotion(message: Message): Promise<void> {
    if (!message.guild) return;

    const user = this.dataManager.getUser(message.guild.id, message.author.id);

    if (!user.inventory.includes('promotion')) {
      await this.safeReply(message, '❌ You don\'t have a promotion in your inventory!\n\nBuy one from the staff shop with `?buy promotion`');
      return;
    }

    const member = message.member;
    if (!member) return;

    const memberRoles = Array.from(member.roles.cache.values())
      .filter(r => r.id !== message.guild!.id)
      .sort((a, b) => b.position - a.position);

    let currentRole = memberRoles[0];
    let nextRole = null;

    const allRoles = Array.from(message.guild.roles.cache.values())
      .filter(r => r.id !== message.guild!.id && !r.managed)
      .sort((a, b) => b.position - a.position);

    if (currentRole) {
      const currentIndex = allRoles.findIndex(r => r.id === currentRole.id);
      if (currentIndex > 0) {
        nextRole = allRoles[currentIndex - 1];
      }
    }

    if (!nextRole) {
      await this.safeReply(message, '❌ No higher role available! You may have already reached maximum rank.');
      return;
    }

    const botMember = await message.guild.members.fetchMe();
    const botHighestRole = botMember.roles.highest;

    if (nextRole.position >= botHighestRole.position) {
      await this.safeReply(message, `❌ I cannot assign the role **${nextRole.name}** because it's higher than or equal to my highest role!\n\nPlease ask an administrator to move my role above **${nextRole.name}**.`);
      return;
    }

    try {
      await member.roles.add(nextRole, `Promotion activated by ${message.author.tag}`);
      
      this.dataManager.removeFromInventory(message.guild.id, message.author.id, 'promotion');

      const embed = new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('🎉 Promotion Activated!')
        .setDescription(
          `Congratulations on your promotion!\n\n` +
          `**New Role:** ${nextRole}\n\n` +
          `You've been promoted from **${currentRole?.name || 'No role'}** to **${nextRole.name}**!`
        )
        .setFooter({ text: 'Keep up the great work!' });

      await this.safeReply(message, { embeds: [embed] });
    } catch (error) {
      console.error('Error assigning promotion role:', error);
      await this.safeReply(message, '❌ Failed to assign the promotion role! Please contact an administrator.');
    }
  }

  private async handleSticker(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (!message.member?.permissions.has(PermissionFlagsBits.ManageGuildExpressions) && 
        !message.member?.permissions.has(PermissionFlagsBits.Administrator)) {
      await this.safeReply(message, '❌ You need **Manage Expressions** or **Administrator** permission to add stickers!');
      return;
    }

    const botMember = await message.guild.members.fetchMe();
    if (!botMember.permissions.has(PermissionFlagsBits.ManageGuildExpressions)) {
      await this.safeReply(message, '❌ I need **Manage Expressions** permission to create stickers!');
      return;
    }

    if (args.length < 2) {
      await this.safeReply(message, '❌ Usage: `?sticker <url> <name>`\nExample: `?sticker https://tenor.com/view/cat-gif funny_cat`');
      return;
    }

    let url = args[0];
    const rawName = args.slice(1).join('_');
    const stickerName = rawName.replace(/[^a-zA-Z0-9_]/g, '_').substring(0, 30);

    if (!stickerName || stickerName.length < 2) {
      await this.safeReply(message, '❌ Sticker name must be at least 2 characters (alphanumeric and underscores only)!');
      return;
    }

    if (!url.match(/^https?:\/\/.+/i)) {
      await this.safeReply(message, '❌ Please provide a valid URL!');
      return;
    }

    if (!message.channel.isSendable()) return;
    
    const statusMsg = await message.channel.send('⏳ Processing animated sticker... This may take a moment!');

    let inputFile: string | null = null;
    let outputFile: string | null = null;

    try {
      if (url.includes('tenor.com') && !url.match(/\.(gif|png|jpg|webp)$/i)) {
        try {
          const pageResponse = await axios.get(url, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
            timeout: 10000
          });
          
          const gifMatch = pageResponse.data.match(/"contentUrl":"([^"]+)"/);
          if (gifMatch) {
            url = JSON.parse(`"${gifMatch[1]}"`);
          } else {
            const altMatch = pageResponse.data.match(/https:\/\/media[0-9]*\.tenor\.com\/[^"]+\.gif/);
            if (altMatch) {
              url = altMatch[0];
            }
          }
        } catch (tenorError) {
          console.error('Tenor extraction error:', tenorError);
        }
      } else if (url.includes('giphy.com') && !url.match(/\.(gif|png|jpg|webp)$/i)) {
        try {
          const pageResponse = await axios.get(url, {
            headers: { 'User-Agent': 'Mozilla/5.0' },
            timeout: 10000
          });
          
          const gifMatch = pageResponse.data.match(/"url":"(https:\/\/media[0-9]*\.giphy\.com\/media\/[^"]+\.gif)"/);
          if (gifMatch) {
            url = JSON.parse(`"${gifMatch[1]}"`);
          }
        } catch (giphyError) {
          console.error('Giphy extraction error:', giphyError);
        }
      }

      const tempDir = path.join(process.cwd(), 'temp_stickers');
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }

      const timestamp = Date.now();
      const randomId = Math.random().toString(36).substring(7);
      inputFile = path.join(tempDir, `input_${timestamp}_${randomId}`);
      outputFile = path.join(tempDir, `output_${timestamp}_${randomId}.gif`);

      const response = await axios.get(url, { 
        responseType: 'arraybuffer',
        timeout: 15000,
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });
      fs.writeFileSync(inputFile, response.data);

      const compressionSettings = [
        { fps: 30, scale: 320, colors: 256 },
        { fps: 30, scale: 320, colors: 200 },
        { fps: 30, scale: 320, colors: 128 },
        { fps: 30, scale: 300, colors: 128 },
        { fps: 30, scale: 280, colors: 96 },
        { fps: 30, scale: 260, colors: 64 },
        { fps: 25, scale: 260, colors: 64 },
        { fps: 20, scale: 240, colors: 48 },
        { fps: 15, scale: 240, colors: 32 },
        { fps: 12, scale: 220, colors: 32 },
        { fps: 10, scale: 200, colors: 24 },
        { fps: 8, scale: 180, colors: 16 },
        { fps: 6, scale: 160, colors: 16 }
      ];

      let stats: any = null;
      let success = false;

      for (const { fps, scale, colors } of compressionSettings) {
        await execPromise(
          `ffmpeg -y -i ${inputFile.replace(/[^a-zA-Z0-9_\/.-]/g, '')} -filter_complex "scale=${scale}:${scale}:force_original_aspect_ratio=increase,crop=${scale}:${scale},fps=${fps},palettegen=max_colors=${colors}[p];[0:v]scale=${scale}:${scale}:force_original_aspect_ratio=increase,crop=${scale}:${scale},fps=${fps}[v];[v][p]paletteuse=dither=bayer:bayer_scale=5" -loop 0 ${outputFile.replace(/[^a-zA-Z0-9_\/.-]/g, '')}`
        );
        stats = fs.statSync(outputFile);
        
        if (stats.size <= 512000) {
          success = true;
          break;
        }
      }

      if (!success) {
        throw new Error('Unable to compress GIF under 512KB - please try a shorter or simpler GIF');
      }

      const stickerData = fs.readFileSync(outputFile);
      
      const sticker = await message.guild.stickers.create({
        file: stickerData,
        name: stickerName,
        tags: 'bot',
        description: `By ${message.author.username}`
      });

      await statusMsg.edit(`✅ Animated sticker **${stickerName}** created successfully! 🎉`);
      try {
        if (message.channel.isSendable()) {
          await message.channel.send({ stickers: [sticker.id] });
        }
      } catch (previewError) {
        console.error('Preview error:', previewError);
      }

    } catch (error: any) {
      console.error('Sticker creation error:', error);
      let errorMsg = 'Unknown error';
      if (error.message?.includes('413') || error.message?.includes('File too large')) {
        errorMsg = 'File too large (>512KB)';
      } else if (error.message?.includes('timeout')) {
        errorMsg = 'Download timeout - URL may be too slow';
      } else if (error.code === 'ENOENT' || error.message?.includes('ENOENT')) {
        errorMsg = 'FFmpeg error - file processing failed';
      } else if (error.message?.includes('End of file') || error.message?.includes('Error opening input')) {
        errorMsg = 'Invalid or corrupted file - please try a different URL';
      } else if (error.message) {
        errorMsg = error.message.substring(0, 200);
      }
      await statusMsg.edit(`❌ Failed to create sticker: ${errorMsg}`);
    } finally {
      try {
        if (inputFile && fs.existsSync(inputFile)) fs.unlinkSync(inputFile);
        if (outputFile && fs.existsSync(outputFile)) fs.unlinkSync(outputFile);
        const tempOutput = `${outputFile}.temp.gif`;
        if (fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
      } catch (cleanupError) {
        console.error('Cleanup error:', cleanupError);
      }
    }
  }

  private async handleDiceGame(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1000;
    
    if (user.balance < bet) {
      await this.safeReply(message, `❌ You need **${bet.toLocaleString()}** 💰 to play!`);
      return;
    }
    
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const dice1 = Math.floor(Math.random() * 6) + 1;
    const dice2 = Math.floor(Math.random() * 6) + 1;
    const total = dice1 + dice2;
    const prediction = args[1]?.toLowerCase() === 'high' ? 'high' : 'low';
    const isHigh = total >= 7;
    const won = (prediction === 'high' && isHigh) || (prediction === 'low' && !isHigh);
    const prize = won ? bet * 2 : 0;
    
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, prize);
    
    const embed = new EmbedBuilder()
      .setColor(won ? 0x00FF00 : 0xFF0000)
      .setTitle(`🎲 Dice Roll: **${total}** ${won ? '(WIN!)' : '(LOSE)'}`)
      .setDescription(`Dice 1: **${dice1}** | Dice 2: **${dice2}**\nYou predicted: **${prediction}** - ${won ? '✅ Correct!' : '❌ Wrong!'}`)
      .addFields({ name: '💰 Result', value: `${won ? '+' : '-'}${Math.abs(won ? prize : bet).toLocaleString()}`, inline: true });
    
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleNumberGuess(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2000;
    
    if (user.balance < bet) {
      await this.safeReply(message, `❌ You need **${bet.toLocaleString()}** 💰 to play!`);
      return;
    }
    
    const secretNumber = Math.floor(Math.random() * 100) + 1;
    await this.safeReply(message, `🔢 I'm thinking of a number 1-100! You have 3 guesses. Bet: **${bet.toLocaleString()}** 💰`);
    
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    let guessesLeft = 3;
    let won = false;
    
    const filter = (m: Message) => m.author.id === message.author.id;
    const collector = (message.channel as any).createMessageCollector({ filter, time: 60000, max: 3 });
    
    collector.on('collect', async (m: Message) => {
      const guess = parseInt(m.content);
      if (isNaN(guess)) return;
      
      if (guess === secretNumber) {
        won = true;
        collector.stop();
        const prize = bet * 5;
        this.dataManager.addCurrencyRaw(message.guild!.id, message.author.id, prize);
        await this.safeReply(m, `🎉 **Correct!** The number was **${secretNumber}**! +${prize.toLocaleString()} 💰`);
      } else {
        guessesLeft--;
        const hint = guess < secretNumber ? 'higher' : 'lower';
        await this.safeReply(m, `❌ Guess **${guess}** is wrong! It's **${hint}**! ${guessesLeft} guesses left.`);
        if (guessesLeft === 0) {
          collector.stop();
          await this.safeReply(message, `😔 Out of guesses! The number was **${secretNumber}**!`);
        }
      }
    });
  }

  private async handleCardGame(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1500;
    
    if (user.balance < bet) {
      await this.safeReply(message, `❌ You need **${bet.toLocaleString()}** 💰 to play!`);
      return;
    }
    
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const cards = ['🂡', '🂢', '🂣', '🂤', '🂥', '🂦', '🂧', '🂨', '🂩', '🂪', '🂫', '🂭', '🂮'];
    const currentCard = cards[Math.floor(Math.random() * cards.length)];
    const currentValue = cards.indexOf(currentCard);
    const nextCard = cards[Math.floor(Math.random() * cards.length)];
    const nextValue = cards.indexOf(nextCard);
    
    const prediction = args[1]?.toLowerCase() === 'higher' ? 'higher' : 'lower';
    const won = (prediction === 'higher' && nextValue > currentValue) || (prediction === 'lower' && nextValue < currentValue);
    const prize = won ? bet * 2 : 0;
    
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, prize);
    
    const embed = new EmbedBuilder()
      .setColor(won ? 0x00FF00 : 0xFF0000)
      .setTitle(`🃏 Card Game: ${won ? 'WIN!' : 'LOSE!'}`)
      .setDescription(`Current: ${currentCard} (${currentValue})\nNext: ${nextCard} (${nextValue})\nYou guessed: **${prediction}** - ${won ? '✅' : '❌'}`)
      .addFields({ name: '💰 Prize', value: `${won ? '+' : '-'}${Math.abs(won ? prize : bet).toLocaleString()}`, inline: true });
    
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleSpinWheel(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 3000;
    
    if (user.balance < bet) {
      await this.safeReply(message, `❌ You need **${bet.toLocaleString()}** 💰 to play!`);
      return;
    }
    
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const outcomes = [
      { emoji: '💰', multiplier: 3, name: 'TRIPLE!' },
      { emoji: '🎉', multiplier: 2, name: 'DOUBLE' },
      { emoji: '💎', multiplier: 5, name: 'JACKPOT' },
      { emoji: '😢', multiplier: 0, name: 'LOSE' }
    ];
    const result = outcomes[Math.floor(Math.random() * outcomes.length)];
    const prize = bet * result.multiplier;
    
    if (prize > 0) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, prize);
    
    const embed = new EmbedBuilder()
      .setColor(prize > 0 ? 0x00FF00 : 0xFF0000)
      .setTitle(`🎡 Spin to Win! ${result.emoji} ${result.name}`)
      .setDescription(result.multiplier > 0 ? `🎊 You won **${prize.toLocaleString()}** 💰!` : 'Better luck next time!')
      .addFields({ name: '💸 Total', value: `${user.balance.toLocaleString()} 💰`, inline: true });
    
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleNumberPrediction(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 5000;
    const prediction = parseInt(args[1]) || 0;
    
    if (prediction < 1 || prediction > 100) {
      await this.safeReply(message, '❌ Predict a number between 1-100!');
      return;
    }
    
    if (user.balance < bet) {
      await this.safeReply(message, `❌ You need **${bet.toLocaleString()}** 💰 to play!`);
      return;
    }
    
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const secretNumber = Math.floor(Math.random() * 100) + 1;
    const won = prediction === secretNumber;
    const prize = won ? bet * 10 : 0;
    
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, prize);
    
    const embed = new EmbedBuilder()
      .setColor(won ? 0xFF00FF : 0xFF0000)
      .setTitle(won ? `🎯 PERFECT! Your guess was correct!` : `❌ Wrong prediction...`)
      .setDescription(`Your guess: **${prediction}**\nActual number: **${secretNumber}**`)
      .addFields({ name: '💰 Prize', value: `${won ? '+' : '-'}${Math.abs(won ? prize : bet).toLocaleString()}`, inline: true });
    
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleHorseRace(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2500;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const horses = ['🐎 Speed', '🐎 Thunder', '🐎 Lightning', '🐎 Storm'];
    const winner = horses[Math.floor(Math.random() * horses.length)];
    const yourHorse = parseInt(args[1]) || 1;
    const won = yourHorse === (horses.indexOf(winner) + 1);
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 3);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🏇 Horse Race: ${won ? 'WIN!' : 'LOSE!'}`).setDescription(`Winner: ${winner}\nYou bet on: Horse #${yourHorse}`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 3 : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleEnvelope(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1500;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const envelopes = [bet * 0.5, bet * 1.5, bet * 3, bet * 0.2, bet * 2.5];
    const prize = envelopes[Math.floor(Math.random() * envelopes.length)];
    this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, prize);
    const embed = new EmbedBuilder().setColor(0xFFD700).setTitle('💌 Lucky Envelope Opened!').setDescription(`You found: **${Math.floor(prize).toLocaleString()}** 💰!`).addFields({ name: 'Net', value: `${prize >= bet ? '+' : '-'}${Math.abs(prize - bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleDoubleOrNothing(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 4000;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const won = Math.random() > 0.5;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 2);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🎲 Double Or Nothing: ${won ? 'DOUBLED!' : 'LOST!'}!`).setDescription(won ? `Lucky! Your money was doubled!` : `Unlucky! Your money is gone.`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleJackpot(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 5000;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const roll = Math.random();
    let multiplier = 0;
    if (roll < 0.01) multiplier = 100;
    else if (roll < 0.05) multiplier = 20;
    else if (roll < 0.15) multiplier = 5;
    else if (roll < 0.35) multiplier = 2;
    const prize = bet * multiplier;
    if (prize > 0) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, prize);
    const embed = new EmbedBuilder().setColor(prize > bet ? 0x00FF00 : 0xFF0000).setTitle(`🎰 JACKPOT Machine: ${multiplier}x`).setDescription(`${multiplier > 0 ? `🎊 **${multiplier}x WIN!** +${prize.toLocaleString()} 💰` : 'Better luck next time!'}`).addFields({ name: '💰', value: `${multiplier > 0 ? '+' : '-'}${Math.abs(prize > 0 ? prize : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleKingOfTheHill(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2200;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const rounds = [Math.random() > 0.4, Math.random() > 0.45, Math.random() > 0.5];
    const won = rounds.filter(r => r).length >= 2;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 2.5);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`👑 King of the Hill: ${won ? 'VICTORY!' : 'DEFEATED!'}`).setDescription(`Win 2/3 rounds: ${rounds.map(r => r ? '✅' : '❌').join(' ')}`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 2.5 : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleGoldfish(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1200;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const fish = Math.floor(Math.random() * 5) + 1;
    const guess = parseInt(args[1]) || 3;
    const won = fish === guess;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 4);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🐠 Goldfish Game: ${won ? 'EXACT CATCH!' : 'MISS!'}`).setDescription(`Fish caught: ${fish} | You guessed: ${guess}`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 4 : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleMinesweeper(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1800;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const grid = Array(9).fill(0).map(() => Math.random() > 0.66);
    const reveal = Math.floor(Math.random() * 9);
    const hit = grid[reveal];
    const prize = hit ? 0 : bet * 2.2;
    if (prize > 0) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, prize);
    const embed = new EmbedBuilder().setColor(hit ? 0xFF0000 : 0x00FF00).setTitle(`💣 Minesweeper: ${hit ? 'BOOM!' : 'SAFE!'}`).setDescription(hit ? `You hit a mine!` : `No mines! Lucky!`).addFields({ name: '💰', value: `${hit ? '-' : '+'}${Math.abs(prize > 0 ? prize : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleBombSquad(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2100;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const bombs = Math.floor(Math.random() * 3) + 1;
    const defused = Math.floor(Math.random() * 5) + 2;
    const won = defused > bombs;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 1.8);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`💣 Bomb Squad: ${won ? 'DEFUSED!' : 'EXPLOSION!'}`).setDescription(`Bombs: ${bombs} | Defused: ${defused}`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 1.8 : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleLotteryTicket(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1000;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const roll = Math.random();
    let multiplier = 0;
    if (roll > 0.999) multiplier = 500;
    else if (roll > 0.99) multiplier = 100;
    else if (roll > 0.95) multiplier = 20;
    else if (roll > 0.85) multiplier = 5;
    else if (roll > 0.7) multiplier = 1.5;
    const prize = multiplier > 0 ? bet * multiplier : 0;
    if (prize > 0) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, prize);
    const embed = new EmbedBuilder().setColor(multiplier > 1 ? 0x00FF00 : 0xFF0000).setTitle(`🎰 Lottery: ${multiplier}x`).setDescription(multiplier > 0 ? `🎉 **${multiplier}x WIN!** +${Math.floor(prize).toLocaleString()} 💰` : 'No luck this time!').addFields({ name: '💰', value: `${multiplier > 0 ? '+' : '-'}${Math.abs(prize > 0 ? prize : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleRoulette(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2000;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const spin = Math.floor(Math.random() * 37);
    const guess = parseInt(args[1]) || Math.floor(Math.random() * 37);
    const won = spin === guess;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 36);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🎡 Roulette: ${won ? 'JACKPOT!' : 'NO HIT'}`).setDescription(`Spin: ${spin} | Your number: ${guess}`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 36 : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleQuickPick(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1500;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const winning = [Math.floor(Math.random() * 50) + 1, Math.floor(Math.random() * 50) + 1];
    const matches = parseInt(args[1]) || 0;
    const won = matches === 2;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 15);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🎯 Quick Pick: ${matches === 2 ? 'JACKPOT!' : 'TRY AGAIN'}`).setDescription(`Winning numbers: ${winning.join(', ')}\nYou matched: ${matches}/2`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 15 : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleCoinPile(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1300;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const coins = Math.floor(Math.random() * 20) + 5;
    const guess = parseInt(args[1]) || 10;
    const won = Math.abs(coins - guess) <= 2;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 2.5);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🪙 Coin Pile: ${won ? 'CLOSE ENOUGH!' : 'MISS'}`).setDescription(`Coins: ${coins} | You guessed: ${guess}`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 2.5 : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleDaredevil(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 3500;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const difficulty = parseInt(args[1]) || 1;
    const multiplier = difficulty * 0.8;
    const success = Math.random() > (difficulty * 0.15);
    const prize = success ? bet * multiplier : 0;
    if (prize > 0) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, prize);
    const embed = new EmbedBuilder().setColor(success ? 0x00FF00 : 0xFF0000).setTitle(`🦸 Daredevil: ${success ? 'SURVIVED!' : 'FAILED!'}`).setDescription(`Difficulty: ${difficulty} | Multiplier: ${multiplier}x`).addFields({ name: '💰', value: `${success ? '+' : '-'}${Math.abs(prize > 0 ? prize : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleHiLo(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1700;
    if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet);
    const card1 = Math.floor(Math.random() * 13) + 1;
    const card2 = Math.floor(Math.random() * 13) + 1;
    const prediction = args[1]?.toLowerCase() === 'low' ? 'low' : 'high';
    const won = (prediction === 'high' && card2 > card1) || (prediction === 'low' && card2 < card1);
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 2);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`📊 Hi-Lo: ${won ? 'CORRECT!' : 'WRONG!'}`).setDescription(`Card 1: ${card1} | Card 2: ${card2}\nYou said: **${prediction}**`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 2 : bet).toLocaleString()}`, inline: true });
    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleDiceTower(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1800; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const tower = Math.floor(Math.random() * 30) + 1; const guess = parseInt(args[1]) || 15; const won = Math.abs(tower - guess) <= 3;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 2.5); const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🗼 Dice Tower: ${won ? 'TOWER BUILT!' : 'TOWER FELL'}`).setDescription(`Height: ${tower} | You guessed: ${guess}`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 2.5 : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleCardShuffle(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1900; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const card = Math.floor(Math.random() * 52); const guess = parseInt(args[1]) || 26; const won = Math.abs(card - guess) < 5;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 3); const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🎴 Card Shuffle: ${won ? 'FOUND IT!' : 'NOT FOUND'}`).setDescription(`Card position: ${card} | You guessed: ${guess}`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 3 : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleGemRush(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2300; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const gems = Math.floor(Math.random() * 7); const won = gems >= 4;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * (gems * 0.8)); const prize = bet * (gems * 0.8);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`💎 Gem Rush: ${gems} GEMS!`).setDescription(won ? `Found ${gems} precious gems!` : 'Only collected a few gems...').addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(prize > 0 ? prize : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleMysteryBox(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2500; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const mystery = Math.random();
    let prize = 0; let result = '';
    if (mystery > 0.9) { prize = bet * 5; result = '🌟 LEGENDARY!'; } else if (mystery > 0.75) { prize = bet * 2.5; result = '✨ RARE'; } else if (mystery > 0.5) { prize = bet; result = '💫 COMMON'; }
    if (prize > 0) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, prize);
    const embed = new EmbedBuilder().setColor(prize > 0 ? 0x00FF00 : 0xFF0000).setTitle(`📦 Mystery Box: ${result}`).setDescription(prize > 0 ? `You got something valuable!` : 'Empty box...').addFields({ name: '💰', value: `${prize > 0 ? '+' : '-'}${Math.abs(prize > 0 ? prize : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleLadderClimb(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1600; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const rungs = [Math.random() > 0.4, Math.random() > 0.5, Math.random() > 0.6];
    const climbed = rungs.filter(r => r).length; const won = climbed >= 2;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * (1 + climbed * 0.5));
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🪜 Ladder Climb: ${climbed}/3`).setDescription(`Climbed **${climbed}** rungs: ${rungs.map(r => r ? '✅' : '❌').join(' ')}`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * (1 + climbed * 0.5) : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleCardCombo(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2200; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const cards = [Math.floor(Math.random() * 13), Math.floor(Math.random() * 13), Math.floor(Math.random() * 13)];
    const combo = cards[0] === cards[1] || cards[1] === cards[2]; if (combo) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 3);
    const embed = new EmbedBuilder().setColor(combo ? 0x00FF00 : 0xFF0000).setTitle(`🃏 Card Combo: ${combo ? 'MATCH!' : 'NO MATCH'}`).setDescription(`Cards: ${cards.join(', ')}`).addFields({ name: '💰', value: `${combo ? '+' : '-'}${Math.abs(combo ? bet * 3 : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleExplosiveGame(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2600; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const explosions = Math.floor(Math.random() * 4); const survived = explosions <= 1;
    if (survived) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 2.2);
    const embed = new EmbedBuilder().setColor(survived ? 0x00FF00 : 0xFF0000).setTitle(`💣 Explosive: ${survived ? 'SURVIVED!' : 'KABOOM!'}`).setDescription(`Explosions: ${explosions}`).addFields({ name: '💰', value: `${survived ? '+' : '-'}${Math.abs(survived ? bet * 2.2 : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleRainbowRush(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2000; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const colors = ['🔴', '🟠', '🟡', '🟢', '🔵', '🟣']; const rolled = Math.floor(Math.random() * 6); const won = rolled === 0 || rolled === 3;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 2.8);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🌈 Rainbow Rush: ${colors[rolled]}`).setDescription(won ? 'Lucky color!' : 'Wrong color').addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 2.8 : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleCrystalQuest(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2300; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const crystals = Math.floor(Math.random() * 8); const needed = 4;
    if (crystals >= needed) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * (1 + crystals * 0.4));
    const embed = new EmbedBuilder().setColor(crystals >= needed ? 0x00FF00 : 0xFF0000).setTitle(`🔮 Crystal Quest: ${crystals}/8`).setDescription(crystals >= needed ? `Found enough crystals!` : 'Not enough crystals').addFields({ name: '💰', value: `${crystals >= needed ? '+' : '-'}${Math.abs(crystals >= needed ? bet * (1 + crystals * 0.4) : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleMagicFlip(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1900; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const flips = [Math.random() > 0.5, Math.random() > 0.5, Math.random() > 0.5];
    const heads = flips.filter(f => f).length; const won = heads >= 2;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 2.5);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`✨ Magic Flip: ${heads}/3 heads`).setDescription(`${flips.map(f => f ? '🟢' : '🔴').join('')}`).addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 2.5 : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleThunderRoll(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2100; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const roll = Math.floor(Math.random() * 20) + 1; const won = roll >= 15;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * (roll / 5));
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`⚡ Thunder Roll: ${roll}`).setDescription(won ? 'Lightning strike!' : 'No thunder').addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * (roll / 5) : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handlePhoenixFire(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2800; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const flame = Math.random();
    let mult = 0;
    if (flame > 0.95) mult = 10; else if (flame > 0.8) mult = 4; else if (flame > 0.6) mult = 1.5;
    if (mult > 0) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * mult);
    const embed = new EmbedBuilder().setColor(mult > 0 ? 0x00FF00 : 0xFF0000).setTitle(`🔥 Phoenix Fire: ${mult > 0 ? mult + 'x' : 'EXTINGUISHED'}`).setDescription(mult > 0 ? 'Phoenix rises!' : 'Phoenix sleeps').addFields({ name: '💰', value: `${mult > 0 ? '+' : '-'}${Math.abs(mult > 0 ? bet * mult : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleDragonGold(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 3000; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const gold = Math.floor(Math.random() * 5) + 1; const won = gold >= 3;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * gold);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🐉 Dragon's Gold: ${gold} treasures`).setDescription(won ? 'Dragon\'s hoard claimed!' : 'Dragon guarded it').addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * gold : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleShadowLuck(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 1500; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const shadow = Math.random(); let mult = 1;
    if (shadow > 0.9) mult = 6; else if (shadow > 0.75) mult = 2.5; else mult = 0;
    if (mult > 0) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * mult);
    const embed = new EmbedBuilder().setColor(mult > 0 ? 0x00FF00 : 0xFF0000).setTitle(`🌑 Shadow Luck: ${mult}x`).setDescription(mult > 0 ? 'Shadow blessed you!' : 'Shadow cursed you').addFields({ name: '💰', value: `${mult > 0 ? '+' : '-'}${Math.abs(mult > 0 ? bet * mult : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleVoidEcho(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2400; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const echo = Math.floor(Math.random() * 4); const won = echo === 1;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 4);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🌀 Void Echo: ${echo}`).setDescription(won ? 'The void answered!' : 'Void is silent').addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 4 : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleAncientRunes(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2200; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const rune = Math.floor(Math.random() * 9); const won = rune === 4;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 5);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`ᚱ Ancient Runes: Rune ${rune}`).setDescription(won ? 'The ancient rune glows!' : 'The rune is dim').addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 5 : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleQuantumLeap(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2900; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const leap = Math.floor(Math.random() * 6); const won = leap >= 3;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 2.2);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🌌 Quantum Leap: ${leap}/5`).setDescription(won ? 'Successful leap!' : 'Failed to leap').addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 2.2 : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleNebulaHunt(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2500; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const found = Math.random() > 0.4; if (found) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 3.5);
    const embed = new EmbedBuilder().setColor(found ? 0x00FF00 : 0xFF0000).setTitle(`🌌 Nebula Hunt: ${found ? 'FOUND!' : 'NOT FOUND'}`).setDescription(found ? 'Discovered a nebula!' : 'No nebula found').addFields({ name: '💰', value: `${found ? '+' : '-'}${Math.abs(found ? bet * 3.5 : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleInfinityLoop(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2700; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const loops = Math.floor(Math.random() * 7); const won = loops >= 4;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * loops);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`♾️ Infinity Loop: ${loops}`).setDescription(won ? `You looped ${loops} times!` : 'Loop broke').addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * loops : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleEclipse(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2600; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const eclipse = Math.random();
    let mult = 0;
    if (eclipse > 0.92) mult = 8; else if (eclipse > 0.7) mult = 2; 
    if (mult > 0) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * mult);
    const embed = new EmbedBuilder().setColor(mult > 0 ? 0x00FF00 : 0xFF0000).setTitle(`🌑 Eclipse: ${mult > 0 ? mult + 'x' : 'BLOCKED'}`).setDescription(mult > 0 ? 'Eclipse aligned perfectly!' : 'Eclipse blocked sun').addFields({ name: '💰', value: `${mult > 0 ? '+' : '-'}${Math.abs(mult > 0 ? bet * mult : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleFrostBite(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2300; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const freeze = Math.floor(Math.random() * 5); const survived = freeze <= 2;
    if (survived) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 2.5);
    const embed = new EmbedBuilder().setColor(survived ? 0x00FF00 : 0xFF0000).setTitle(`❄️ Frostbite: ${survived ? 'SURVIVED' : 'FROZEN'}`).setDescription(`Freeze level: ${freeze}`).addFields({ name: '💰', value: `${survived ? '+' : '-'}${Math.abs(survived ? bet * 2.5 : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleInferno(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2800; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const heat = Math.floor(Math.random() * 8); const escaped = heat <= 4;
    if (escaped) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * (heat * 0.35));
    const embed = new EmbedBuilder().setColor(escaped ? 0x00FF00 : 0xFF0000).setTitle(`🔥 Inferno: ${heat}°`).setDescription(escaped ? `Escaped the heat!` : 'Burned by inferno').addFields({ name: '💰', value: `${escaped ? '+' : '-'}${Math.abs(escaped ? bet * (heat * 0.35) : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleTigerPounce(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;
    const user = this.dataManager.getUser(message.guild.id, message.author.id);
    const bet = parseInt(args[0]) || 2900; if (user.balance < bet) { await this.safeReply(message, `❌ Need ${bet.toLocaleString()} 💰!`); return; }
    this.dataManager.removeCurrency(message.guild.id, message.author.id, bet); const pounce = Math.floor(Math.random() * 4); const won = pounce === 1;
    if (won) this.dataManager.addCurrencyRaw(message.guild.id, message.author.id, bet * 6);
    const embed = new EmbedBuilder().setColor(won ? 0x00FF00 : 0xFF0000).setTitle(`🐯 Tiger Pounce: ${won ? 'HIT!' : 'MISSED'}`).setDescription(won ? 'Tiger caught the prey!' : 'Tiger missed').addFields({ name: '💰', value: `${won ? '+' : '-'}${Math.abs(won ? bet * 6 : bet).toLocaleString()}`, inline: true }); await this.safeReply(message, { embeds: [embed] });
  }

  private async handleListBackups(message: Message): Promise<void> {
    if (!message.guild) return;

    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can view backups!');
      return;
    }

    const backups = this.dataManager.getAvailableBackupsWithDates();

    if (backups.length === 0) {
      await this.safeReply(message, '📭 No backups available yet! Backups are created every hour.');
      return;
    }

    const MAX_DESC_LENGTH = 1800;
    const embeds: EmbedBuilder[] = [];
    let currentDescription = '📋 **Available Data Backups (IST Timezone):**\n\n';
    let backupCount = 0;
    let embedCount = 1;

    for (let i = 0; i < backups.length; i++) {
      const backup = backups[i];
      const backupLine = `**${i + 1}.** \`${backup.filename}\`\n   📅 **${backup.istTime}** | 📦 **${backup.fileSize}**\n\n`;

      if ((currentDescription + backupLine).length > MAX_DESC_LENGTH && backupCount > 0) {
        currentDescription += '💡 **To restore data:** `?restore <filename>`';
        
        embeds.push(
          new EmbedBuilder()
            .setColor(0x3498DB)
            .setTitle(`💾 Data Backups (Part ${embedCount})`)
            .setDescription(currentDescription)
            .setFooter({ text: '⚠️ Restoring will replace all current data with the backup' })
        );

        currentDescription = '📋 **Continued from previous:**\n\n';
        embedCount++;
      }

      currentDescription += backupLine;
      backupCount++;
    }

    currentDescription += '💡 **To restore data:** `?restore <filename>`\n';
    currentDescription += '📌 **Only the most recent backup is recommended**';

    embeds.push(
      new EmbedBuilder()
        .setColor(0x3498DB)
        .setTitle(embedCount > 1 ? `💾 Data Backups (Part ${embedCount})` : '💾 Data Backups')
        .setDescription(currentDescription)
        .setFooter({ text: '⚠️ Restoring will replace all current data with the backup' })
    );

    await this.safeReply(message, { embeds });
  }

  private async handleRestore(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can restore backups!');
      return;
    }

    if (args.length === 0) {
      await this.safeReply(message, '❌ Usage: `?restore <filename>`\n\nExample: `?restore backup_2025-11-22_19-57-33.json`\n\n💡 Use `?backups` to see available backups');
      return;
    }

    const backupFilename = args[0];

    // Validate filename format
    if (!backupFilename.startsWith('backup_') || !backupFilename.endsWith('.json')) {
      await this.safeReply(message, '❌ Invalid backup filename! Use `?backups` to see valid backup files.');
      return;
    }

    const backups = this.dataManager.getAvailableBackupsWithDates();
    const backupExists = backups.some(b => b.filename === backupFilename);

    if (!backupExists) {
      await this.safeReply(message, `❌ Backup file not found: \`${backupFilename}\`\n\nUse \`?backups\` to see available backups.`);
      return;
    }

    const backup = backups.find(b => b.filename === backupFilename);

    // Ask for confirmation
    const confirmEmbed = new EmbedBuilder()
      .setColor(0xFF6B6B)
      .setTitle('⚠️ Confirm Data Restoration')
      .setDescription(
        `You are about to restore data from:\n\n` +
        `📁 **File:** \`${backup?.filename}\`\n` +
        `📅 **Timestamp:** **${backup?.istTime}** (IST)\n` +
        `📦 **Size:** **${backup?.fileSize}**\n\n` +
        `**This will replace all current data with this backup!**\n\n` +
        `Type **\`yes\`** to confirm or **\`no\`** to cancel`
      )
      .setFooter({ text: 'Action will auto-cancel in 30 seconds' });

    const confirmMsg = await this.safeReply(message, { embeds: [confirmEmbed] });
    
    try {
      if (!message.channel.isSendable()) {
        await this.safeReply(message, '❌ Cannot create message collector in this channel');
        return;
      }

      const filter = (msg: Message) => msg.author.id === message.author.id;
      const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000 });

      if (collected.size === 0) {
        await confirmMsg.edit({ embeds: [new EmbedBuilder()
          .setColor(0xFF9800)
          .setTitle('⏱️ Restoration Cancelled')
          .setDescription('Action timed out after 30 seconds - no response received')
        ] });
        return;
      }

      const response = collected.first();
      const userInput = response?.content.toLowerCase().trim();

      if (userInput !== 'yes') {
        await confirmMsg.edit({ embeds: [new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('❌ Restoration Cancelled')
          .setDescription(`You typed \`${userInput}\` - restoration cancelled`)
        ] });
        return;
      }

      // Proceed with restoration
      const statusEmbed = new EmbedBuilder()
        .setColor(0xFFD700)
        .setTitle('⏳ Restoring Data...')
        .setDescription(`Loading \`${backupFilename}\`...\n\nDo not close the bot during restoration!`);

      await confirmMsg.edit({ embeds: [statusEmbed] });

      const success = this.dataManager.loadBackupData(backupFilename);

      if (success) {
        // Wait a moment for database sync
        await new Promise(resolve => setTimeout(resolve, 2000));

        const successEmbed = new EmbedBuilder()
          .setColor(0x2ECC71)
          .setTitle('✅ Data Restored Successfully!')
          .setDescription(
            `Data from \`${backupFilename}\` has been restored!\n\n` +
            `📅 **Backup Date:** ${backup?.istTime} (IST)\n` +
            `📦 **File Size:** ${backup?.fileSize}\n\n` +
            `⚠️ **Note:** The bot will now serve data from this backup.\n` +
            `🔄 New data will continue to be saved going forward.`
          );

        await confirmMsg.edit({ embeds: [successEmbed] });
      } else {
        const errorEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('❌ Restoration Failed')
          .setDescription(`Failed to load backup: \`${backupFilename}\``);

        await confirmMsg.edit({ embeds: [errorEmbed] });
      }
    } catch (error) {
      console.error('Error in backup restoration:', error);
      await this.safeReply(message, '❌ An error occurred during restoration. Check logs for details.');
    }
  }

  private async handleCustomBoost(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can manage custom boosts!');
      return;
    }

    const subcommand = args[0]?.toLowerCase();

    // Handle list
    if (subcommand === 'list') {
      const boosts = this.dataManager.getRoleBoosts(message.guild.id);
      if (boosts.length === 0) {
        await this.safeReply(message, '📭 No custom role boosts configured yet!');
        return;
      }

      let description = '🎯 **Custom Role-Based Boosts:**\n\n';
      for (const boost of boosts) {
        const role = message.guild.roles.cache.get(boost.roleId);
        const roleName = role?.name || `Role ${boost.roleId}`;
        description += `• **${roleName}:** ${boost.multiplier}x multiplier\n`;
      }

      const embed = new EmbedBuilder()
        .setColor(0xFFD700)
        .setTitle('⚙️ Custom Boosts')
        .setDescription(description);

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    // Handle clear
    if (subcommand === 'clear') {
      this.dataManager.clearRoleBoosts(message.guild.id);
      await this.safeReply(message, '✅ All custom role boosts have been cleared!');
      return;
    }

    // Show usage if no command provided
    if (!subcommand) {
      await this.safeReply(message, 
        '📋 Usage:\n' +
        '`?customboost <@role> <multiplier>` - Set a boost\n' +
        '`?customboost list` - View all boosts\n' +
        '`?customboost remove <@role>` - Remove a boost\n' +
        '`?customboost clear` - Clear all boosts\n\n' +
        'Example: `?customboost @staff 150` = staff members earn 150x from chat'
      );
      return;
    }

    // Handle remove
    if (subcommand === 'remove') {
      if (args.length < 2) {
        await this.safeReply(message, '❌ Usage: `?customboost remove <@role>`');
        return;
      }

      const roleArg = args[1];
      const role = message.mentions.roles.first() || message.guild.roles.cache.find(r => r.name.toLowerCase() === roleArg.toLowerCase());

      if (!role) {
        await this.safeReply(message, `❌ Could not find role: \`${roleArg}\``);
        return;
      }

      this.dataManager.removeRoleBoost(message.guild.id, role.id);
      await this.safeReply(message, `✅ Boost for **${role.name}** has been removed!`);
      return;
    }

    // Handle set (subcommand is the role)
    if (args.length < 2) {
      await this.safeReply(message, '❌ Usage: `?customboost <@role> <multiplier>`\nExample: `?customboost @staff 150`');
      return;
    }

    const roleArg = args[0];
    const role = message.mentions.roles.first() || message.guild.roles.cache.find(r => r.name.toLowerCase() === roleArg.toLowerCase());

    if (!role) {
      await this.safeReply(message, `❌ Could not find role: \`${roleArg}\``);
      return;
    }

    const multiplier = parseFloat(args[1]);
    if (isNaN(multiplier) || multiplier <= 0) {
      await this.safeReply(message, `❌ Invalid multiplier! Use a positive number (e.g., 150 for 150x)`);
      return;
    }

    if (multiplier > 10000) {
      await this.safeReply(message, `⚠️ Multiplier capped at 10000x (excessive boosts can break economy)`);
    }

    const finalMult = Math.min(multiplier, 10000);
    this.dataManager.setRoleBoost(message.guild.id, role.id, finalMult);

    const embed = new EmbedBuilder()
      .setColor(0x00FF00)
      .setTitle('✅ Custom Boost Set')
      .setDescription(`**${role.name}** members now earn **${finalMult}x** from messages\n\n💡 This applies on top of user boosts`);

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleDisableCommand(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can disable commands!');
      return;
    }

    const commandName = args[0]?.toLowerCase();
    if (!commandName) {
      const disabled = this.dataManager.getDisabledCommands(message.guild.id);
      if (disabled.length === 0) {
        await this.safeReply(message, '📭 No commands are currently disabled!');
        return;
      }

      const embed = new EmbedBuilder()
        .setColor(0xFF6B6B)
        .setTitle('🚫 Disabled Commands')
        .setDescription(disabled.map(cmd => `• \`${cmd}\``).join('\n'));

      await this.safeReply(message, { embeds: [embed] });
      return;
    }

    if (commandName === 'disable' || commandName === 'enable') {
      await this.safeReply(message, '⚠️ Cannot disable the `disable` and `enable` commands - they are protected!');
      return;
    }

    if (this.dataManager.isCommandDisabled(message.guild.id, commandName)) {
      await this.safeReply(message, `⚠️ Command \`${commandName}\` is already disabled!`);
      return;
    }

    this.dataManager.disableCommand(message.guild.id, commandName);

    const embed = new EmbedBuilder()
      .setColor(0xFF0000)
      .setTitle('✅ Command Disabled')
      .setDescription(`**\`${commandName}\`** has been disabled!\n\nNo one can use this command until you enable it with \`?enable ${commandName}\``);

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleEnableCommand(message: Message, args: string[]): Promise<void> {
    if (!message.guild) return;

    if (message.guild.ownerId !== message.author.id) {
      await this.safeReply(message, '❌ Only the server owner can enable commands!');
      return;
    }

    const commandName = args[0]?.toLowerCase();
    if (!commandName) {
      await this.safeReply(message, '📋 Usage: `?enable <command>` - Enable a previously disabled command');
      return;
    }

    if (commandName === 'disable' || commandName === 'enable') {
      await this.safeReply(message, '⚠️ Cannot enable the `disable` and `enable` commands - they are always enabled!');
      return;
    }

    if (!this.dataManager.isCommandDisabled(message.guild.id, commandName)) {
      await this.safeReply(message, `⚠️ Command \`${commandName}\` is not disabled!`);
      return;
    }

    this.dataManager.enableCommand(message.guild.id, commandName);

    const embed = new EmbedBuilder()
      .setColor(0x00FF00)
      .setTitle('✅ Command Enabled')
      .setDescription(`**\`${commandName}\`** has been enabled!\n\nUsers can now use this command again.`);

    await this.safeReply(message, { embeds: [embed] });
  }

  private async handleWouldYouRather(message: Message, args: string[]): Promise<void> {
    const category = args[0]?.toLowerCase();
    const validCategories = ['general', 'dating', 'superpowers', 'intriguing', 'mature', 'silly'];
    
    let question: string;
    if (category && validCategories.includes(category)) {
      question = getWYRQuestionByCategory(category);
    } else if (category) {
      await this.safeReply(message, `❌ Invalid category! Use: \`${validCategories.join(', ')}\`\n\n💡 Or use \`?wyr\` for random questions from all categories`);
      return;
    } else {
      question = getRandomWYRQuestion();
    }

    // Parse the question into two parts (split by 'vs')
    const parts = question.split(' vs ');
    const [option1, option2] = parts.length === 2 ? [parts[0].trim(), parts[1].trim()] : [question, 'The Alternative'];

    const embed = new EmbedBuilder()
      .setColor(0x9C27B0)
      .setTitle('🤔 Would You Rather?')
      .setDescription(`**${option1}** *or* **${option2}**?`)
      .setFooter({ text: '1100+ questions across 6 categories' });

    await this.safeReply(message, { embeds: [embed] });
  }
}
