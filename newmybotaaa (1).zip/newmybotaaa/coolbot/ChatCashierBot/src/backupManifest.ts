import * as fs from 'fs';
import * as path from 'path';

const BACKUP_DIR = path.join(process.cwd(), 'data/backups');
const MANIFEST_FILE = path.join(process.cwd(), 'data/BACKUP_MANIFEST.json');

interface IBackupEntry {
  filename: string;
  istTimestamp: string;
  utcTimestamp: string;
  fileSizeKB: string;
  userCount: number;
  serverCount: number;
  itemCount: number;
  backupIndex: number;
}

interface IBackupManifestData {
  totalBackups: number;
  totalSizeKB: string;
  lastUpdated: string;
  backups: IBackupEntry[];
}

export class BackupManifest {
  static updateManifest(): void {
    try {
      if (!fs.existsSync(BACKUP_DIR)) {
        fs.mkdirSync(BACKUP_DIR, { recursive: true });
      }

      const files = fs.readdirSync(BACKUP_DIR)
        .filter(f => f.startsWith('backup_') && f.endsWith('.json'))
        .map(f => {
          const fullPath = path.join(BACKUP_DIR, f);
          const stats = fs.statSync(fullPath);
          
          // Convert to IST
          const date = new Date(stats.mtime);
          const istDate = new Date(date.getTime() + (5.5 * 60 * 60 * 1000));
          const istTime = istDate.toLocaleString('en-IN', { 
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true,
            timeZone: 'Asia/Kolkata'
          });

          const utcTime = date.toISOString();
          const fileSizeKB = (stats.size / 1024).toFixed(2);
          
          // Read backup to get stats
          const backupData = JSON.parse(fs.readFileSync(fullPath, 'utf-8'));
          let totalUsers = 0;
          for (const guild in backupData.users) {
            totalUsers += Object.keys(backupData.users[guild]).length;
          }
          
          return {
            f,
            istTime,
            utcTime,
            fileSizeKB,
            userCount: totalUsers,
            serverCount: Object.keys(backupData.users).length,
            itemCount: backupData.customShopItems?.length || 0,
            size: stats.size
          };
        })
        .sort((a, b) => b.size - a.size);

      const manifest: IBackupManifestData = {
        totalBackups: files.length,
        totalSizeKB: (files.reduce((a, b) => a + b.size, 0) / 1024).toFixed(2),
        lastUpdated: new Date().toISOString(),
        backups: files.map((file, idx) => ({
          filename: file.f,
          istTimestamp: file.istTime,
          utcTimestamp: file.utcTime,
          fileSizeKB: file.fileSizeKB,
          userCount: file.userCount,
          serverCount: file.serverCount,
          itemCount: file.itemCount,
          backupIndex: idx + 1
        }))
      };

      fs.writeFileSync(MANIFEST_FILE, JSON.stringify(manifest, null, 2));
      console.log(`📋 Backup manifest updated: ${files.length} backups tracked`);
    } catch (error) {
      console.error('❌ Error updating backup manifest:', error);
    }
  }

  static getManifest(): IBackupManifestData | null {
    try {
      if (!fs.existsSync(MANIFEST_FILE)) {
        return null;
      }
      return JSON.parse(fs.readFileSync(MANIFEST_FILE, 'utf-8'));
    } catch (error) {
      console.error('❌ Error reading backup manifest:', error);
      return null;
    }
  }
}
