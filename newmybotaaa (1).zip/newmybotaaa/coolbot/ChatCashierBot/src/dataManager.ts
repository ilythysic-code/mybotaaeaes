import * as fs from 'fs';
import * as path from 'path';
import { AllData, UserData, ShopItem, Lootbox, CustomShopItem, RoleShopItem, RotatingShopItem, RotatingShopStock, GuildData, RotatingShopConfig, ActiveEffect, RedeemCode, StaffShopConfig, PromotionPurchase, RoleBoost } from './types';
import { DbSync } from './dbSync';
import { BackupManifest } from './backupManifest';

const DATA_FILE = path.join(__dirname, '../data/data.json');
// Use project root data directory for persistent backups (survives dist rebuild)
const BACKUP_DIR = path.join(process.cwd(), 'data/backups');

export class DataManager {
  private data: AllData = { users: {}, lootboxes: [], customShopItems: [], roleShopItems: [], rotatingShopItems: [], rotatingShopStock: {}, managers: {}, bannedUsers: {}, defaultItemOverrides: {}, coinflipEnabled: {}, duelChallenges: [], faceoffChallenges: [], rpsChallenges: [], tradeOffers: [], dailyQuests: {}, achievements: [], serverSettings: {}, chatSessions: [], matchQueue: {}, dismeglePanels: {}, rotatingShopConfigs: {}, activeEffects: [], redeemCodes: [], staffShopConfigs: {}, promotionPurchases: [], roleBoosts: {}, disabledCommands: {} };
  private hasUnsavedChanges: boolean = false;
  private dbSync: DbSync;
  private dataInitialized: boolean = false;

  constructor() {
    this.dbSync = new DbSync();
    // Load from PostgreSQL database only - no JSON fallback
    this.loadFromDatabase();
  }

  private async loadFromDatabase(): Promise<void> {
    try {
      const dbData = await this.dbSync.loadDataFromDatabase();
      if (dbData) {
        this.data = dbData;
        console.log('✅ Data loaded from PostgreSQL database');
      } else {
        console.log('⚠️ Database returned no data, using empty state');
      }
    } catch (error) {
      console.error('❌ CRITICAL: Failed to load from database:', error);
      // Use empty data - do NOT fall back to JSON file
    }
    this.dataInitialized = true;
  }


  public saveData(): void {
    if (!this.hasUnsavedChanges) {
      return;
    }

    try {
      // Sync to database FIRST (primary storage)
      this.dbSync.syncAllData(this.data).then(() => {
        this.hasUnsavedChanges = false;
        console.log('💾 Data saved to PostgreSQL database!');
      }).catch(err => {
        console.error('❌ CRITICAL: Database save failed:', err);
        console.error('⚠️ Data changes NOT persisted!');
      });
    } catch (error) {
      console.error('❌ Error saving data:', error);
    }
  }

  public createBackup(): void {
    // Backup is now handled by PostgreSQL - no local JSON backups needed
    console.log('💾 Backup created in PostgreSQL database');
  }

  public exportToJSON(): boolean {
    try {
      // Create backups directory if it doesn't exist
      if (!fs.existsSync(BACKUP_DIR)) {
        fs.mkdirSync(BACKUP_DIR, { recursive: true });
      }

      // Generate timestamped filename
      const now = new Date();
      const timestamp = now.toISOString()
        .replace(/[:.]/g, '-')
        .split('T')[0] + '_' + 
        now.toISOString()
        .split('T')[1]
        .split('.')[0]
        .replace(/:/g, '-');
      
      const backupPath = path.join(BACKUP_DIR, `backup_${timestamp}.json`);

      // Write data to file
      fs.writeFileSync(backupPath, JSON.stringify(this.data, null, 2));
      
      console.log(`📁 Hourly data export saved: ${backupPath}`);

      // Update backup manifest
      BackupManifest.updateManifest();

      // Clean up old backups (keep only last 72 hours worth = ~72 files)
      this.cleanupOldBackups(72);

      return true;
    } catch (error) {
      console.error('❌ Error exporting data to JSON:', error);
      return false;
    }
  }

  private cleanupOldBackups(maxBackups: number): void {
    try {
      if (!fs.existsSync(BACKUP_DIR)) return;

      const files = fs.readdirSync(BACKUP_DIR)
        .filter(f => f.startsWith('backup_') && f.endsWith('.json'))
        .map(f => ({
          name: f,
          path: path.join(BACKUP_DIR, f),
          time: fs.statSync(path.join(BACKUP_DIR, f)).mtime.getTime()
        }))
        .sort((a, b) => b.time - a.time);

      // Delete old backups if we exceed maxBackups
      if (files.length > maxBackups) {
        for (let i = maxBackups; i < files.length; i++) {
          fs.unlinkSync(files[i].path);
          console.log(`🗑️ Deleted old backup: ${files[i].name}`);
        }
      }
    } catch (error) {
      console.error('⚠️ Error cleaning up old backups:', error);
    }
  }

  public getAvailableBackupsWithDates(): { filename: string; istTime: string; fileSize: string }[] {
    try {
      if (!fs.existsSync(BACKUP_DIR)) return [];
      
      return fs.readdirSync(BACKUP_DIR)
        .filter(f => f.startsWith('backup_') && f.endsWith('.json'))
        .map(f => {
          const fullPath = path.join(BACKUP_DIR, f);
          const stats = fs.statSync(fullPath);
          
          // Convert to IST (UTC+5:30)
          const date = new Date(stats.mtime);
          const istDate = new Date(date.getTime() + (5.5 * 60 * 60 * 1000));
          const istTime = istDate.toLocaleString('en-IN', { 
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true,
            timeZone: 'Asia/Kolkata'
          });
          
          const fileSizeKB = (stats.size / 1024).toFixed(2);
          
          return {
            filename: f,
            istTime: istTime,
            fileSize: fileSizeKB + ' KB'
          };
        })
        .sort((a, b) => {
          const aTime = new Date(a.istTime).getTime();
          const bTime = new Date(b.istTime).getTime();
          return bTime - aTime; // Most recent first
        });
    } catch (error) {
      console.error('⚠️ Error reading backups:', error);
      return [];
    }
  }

  public getAvailableBackups(): string[] {
    try {
      if (!fs.existsSync(BACKUP_DIR)) return [];
      
      return fs.readdirSync(BACKUP_DIR)
        .filter(f => f.startsWith('backup_') && f.endsWith('.json'))
        .sort()
        .reverse(); // Most recent first
    } catch (error) {
      console.error('⚠️ Error reading backups:', error);
      return [];
    }
  }

  public loadBackupData(backupFilename: string): boolean {
    try {
      const backupPath = path.join(BACKUP_DIR, backupFilename);
      
      // Security: Ensure path is within BACKUP_DIR
      if (!backupPath.startsWith(BACKUP_DIR)) {
        throw new Error('Invalid backup path');
      }
      
      if (!fs.existsSync(backupPath)) {
        console.error(`❌ Backup file not found: ${backupFilename}`);
        return false;
      }

      const fileContent = fs.readFileSync(backupPath, 'utf-8');
      const backupData = JSON.parse(fileContent) as AllData;
      
      this.data = backupData;
      this.hasUnsavedChanges = true;
      
      // Sync to database
      this.dbSync.syncAllData(this.data).then(() => {
        console.log(`✅ Data restored from backup: ${backupFilename}`);
      }).catch(err => {
        console.error('❌ Error syncing restored data to database:', err);
      });
      
      return true;
    } catch (error) {
      console.error('❌ Error loading backup data:', error);
      return false;
    }
  }

  public restoreFromBackup(backupFile: string): boolean {
    console.log('⚠️ Backup restoration is now handled by PostgreSQL database');
    return false;
  }

  public restoreFromJSON(jsonData: AllData): boolean {
    try {
      this.data = jsonData;
      this.hasUnsavedChanges = true;
      this.saveData();
      console.log('✅ Data restored from provided JSON');
      return true;
    } catch (error) {
      console.error('❌ Error restoring from JSON:', error);
      return false;
    }
  }

  private markDirty(): void {
    this.hasUnsavedChanges = true;
  }

  getUser(guildId: string, userId: string): UserData {
    if (!this.data.users[guildId]) {
      this.data.users[guildId] = {};
    }
    if (!this.data.users[guildId][userId]) {
      this.data.users[guildId][userId] = {
        userId,
        guildId,
        balance: 0,
        boost: 1,
        inventory: [],
        messageCount: 0,
        afkStartTime: undefined,
        purchasedItems: [],
        miningLevel: 1,
        activityStreak: 1
      };
      this.markDirty();
    }
    if (this.data.users[guildId][userId].messageCount === undefined) {
      this.data.users[guildId][userId].messageCount = 0;
    }
    if (!this.data.users[guildId][userId].purchasedItems) {
      this.data.users[guildId][userId].purchasedItems = [];
    }
    if (!this.data.users[guildId][userId].miningLevel) {
      this.data.users[guildId][userId].miningLevel = 1;
    }
    if (!this.data.users[guildId][userId].activityStreak) {
      this.data.users[guildId][userId].activityStreak = 1;
    }
    return this.data.users[guildId][userId];
  }

  getAllUsers(guildId: string): GuildData {
    if (!this.data.users[guildId]) {
      this.data.users[guildId] = {};
    }
    return this.data.users[guildId];
  }

  updateUser(guildId: string, userId: string, updates: Partial<UserData>): void {
    const user = this.getUser(guildId, userId);
    Object.assign(user, updates);
    this.markDirty();
  }

  addCurrency(guildId: string, userId: string, amount: number): void {
    const user = this.getUser(guildId, userId);
    const earnedAmount = Math.floor(amount * user.boost);
    user.balance += earnedAmount;
    this.markDirty();
  }

  addCurrencyRaw(guildId: string, userId: string, amount: number): void {
    const user = this.getUser(guildId, userId);
    user.balance += Math.floor(amount);
    this.markDirty();
  }

  removeCurrency(guildId: string, userId: string, amount: number): boolean {
    const user = this.getUser(guildId, userId);
    if (user.balance >= amount) {
      user.balance -= amount;
      this.markDirty();
      return true;
    }
    return false;
  }

  addToInventory(guildId: string, userId: string, item: string): void {
    const user = this.getUser(guildId, userId);
    user.inventory.push(item);
    this.markDirty();
  }

  getLootboxes(guildId: string): Lootbox[] {
    return this.data.lootboxes.filter(lb => lb.guildId === guildId);
  }

  getLootbox(guildId: string, lootboxId: string): Lootbox | undefined {
    return this.data.lootboxes.find(lb => lb.guildId === guildId && lb.id === lootboxId);
  }

  addLootbox(lootbox: Lootbox): void {
    this.data.lootboxes.push(lootbox);
    this.markDirty();
  }

  removeLootbox(guildId: string, lootboxId: string): boolean {
    const index = this.data.lootboxes.findIndex(lb => lb.guildId === guildId && lb.id === lootboxId);
    if (index !== -1) {
      this.data.lootboxes.splice(index, 1);
      this.markDirty();
      return true;
    }
    return false;
  }

  getDefaultShopItems(guildId?: string): ShopItem[] {
    const defaultItems: ShopItem[] = [
      {
        id: 'boost_1.5x',
        name: '1.5x Currency Boost',
        description: 'Increases currency earning by 1.5x',
        price: 5000,
        type: 'boost' as const,
        value: 1.5,
        multiPurchase: false
      },
      {
        id: 'boost_2x',
        name: '2x Currency Boost',
        description: 'Increases currency earning by 2x',
        price: 9000,
        type: 'boost' as const,
        value: 2,
        multiPurchase: false
      },
      {
        id: 'boost_10x',
        name: '10x Currency Boost',
        description: 'Increases currency earning by 10x',
        price: 15000,
        type: 'boost' as const,
        value: 10,
        multiPurchase: false
      },
      {
        id: 'boost_100x',
        name: '100x Currency Boost',
        description: 'Increases currency earning by 100x',
        price: 30000000,
        type: 'boost' as const,
        value: 100,
        multiPurchase: false
      },
      {
        id: 'passive_income',
        name: '💰 Passive Income Upgrade',
        description: 'Earn +1💰/second passively (stacks with base passive earnings)',
        price: 5000,
        type: 'item' as const,
        multiPurchase: false
      },
      {
        id: 'lucky_charm',
        name: '🍀 Lucky Charm',
        description: 'Increases minigame winnings by 25% for 1 hour',
        price: 20000,
        type: 'item' as const,
        multiPurchase: true
      },
      {
        id: 'cooldown_reset',
        name: '⏰ Cooldown Reset Token',
        description: 'Skip any cooldown for one use (daily/weekly/work/etc)',
        price: 12000,
        type: 'item' as const,
        multiPurchase: true
      },
      {
        id: 'prestige_badge',
        name: '👑 Prestige Badge',
        description: 'Show off your elite status with a special badge',
        price: 18000,
        type: 'item' as const,
        multiPurchase: false
      }
    ];

    // Apply guild-specific overrides if guildId provided
    if (guildId && this.data.defaultItemOverrides[guildId]) {
      return defaultItems.map(item => {
        if (this.data.defaultItemOverrides[guildId][item.id]) {
          const overrides = this.data.defaultItemOverrides[guildId][item.id];
          return { 
            ...item, 
            multiPurchase: overrides.multiPurchase !== undefined ? overrides.multiPurchase : item.multiPurchase,
            price: overrides.price !== undefined ? overrides.price : item.price
          };
        }
        return item;
      });
    }

    return defaultItems;
  }

  getCustomShopItems(guildId: string): CustomShopItem[] {
    return this.data.customShopItems.filter(item => item.guildId === guildId).map(item => {
      if (!item.emoji) {
        item.emoji = '🎁';
      }
      if (item.multiPurchase === undefined) {
        item.multiPurchase = false;
      }
      return item;
    });
  }

  getCustomShopItem(guildId: string, itemId: string): CustomShopItem | undefined {
    return this.data.customShopItems.find(item => item.guildId === guildId && item.id === itemId);
  }

  addCustomShopItem(item: CustomShopItem): void {
    this.data.customShopItems.push(item);
    this.markDirty();
  }

  getRoleShopItems(guildId: string): RoleShopItem[] {
    return this.data.roleShopItems.filter(item => item.guildId === guildId);
  }

  addRoleShopItem(item: RoleShopItem): void {
    this.data.roleShopItems.push(item);
    this.markDirty();
  }

  removeRoleShopItem(guildId: string, roleId: string): boolean {
    const index = this.data.roleShopItems.findIndex(item => item.guildId === guildId && item.roleId === roleId);
    if (index !== -1) {
      this.data.roleShopItems.splice(index, 1);
      this.markDirty();
      return true;
    }
    return false;
  }

  getRotatingShopItems(guildId: string): RotatingShopItem[] {
    return this.data.rotatingShopItems.filter(item => item.guildId === guildId);
  }

  addRotatingShopItem(item: RotatingShopItem): void {
    this.data.rotatingShopItems.push(item);
    this.markDirty();
  }

  removeRotatingShopItem(guildId: string, itemId: string): boolean {
    const index = this.data.rotatingShopItems.findIndex(item => item.guildId === guildId && item.id === itemId);
    if (index !== -1) {
      this.data.rotatingShopItems.splice(index, 1);
      this.markDirty();
      return true;
    }
    return false;
  }

  updateRotatingShopItem(guildId: string, itemId: string, updates: { name?: string; price?: number; chancePercent?: number }): boolean {
    const item = this.data.rotatingShopItems.find(item => item.guildId === guildId && item.id === itemId);
    if (item) {
      if (updates.name !== undefined) item.name = updates.name;
      if (updates.price !== undefined) item.price = updates.price;
      if (updates.chancePercent !== undefined) item.chancePercent = Math.min(100, Math.max(0, updates.chancePercent));
      this.markDirty();
      return true;
    }
    return false;
  }

  getCurrentRotatingStock(guildId: string): string[] {
    const RESTOCK_INTERVAL = 5 * 60 * 1000;
    const now = Date.now();
    
    if (!this.data.rotatingShopStock[guildId]) {
      this.data.rotatingShopStock[guildId] = {
        guildId,
        currentItems: [],
        lastRestock: 0
      };
    }

    const stock = this.data.rotatingShopStock[guildId];
    
    if (now - stock.lastRestock >= RESTOCK_INTERVAL) {
      const availableItems = this.getRotatingShopItems(guildId);
      const selectedItems: string[] = [];
      
      for (const item of availableItems) {
        const roll = Math.random() * 100;
        if (roll < item.chancePercent) {
          selectedItems.push(item.id);
        }
      }
      
      stock.currentItems = selectedItems;
      stock.lastRestock = now;
      this.markDirty();
    }
    
    return stock.currentItems;
  }

  getTimeUntilRestock(guildId: string): number {
    const RESTOCK_INTERVAL = 5 * 60 * 1000;
    if (!this.data.rotatingShopStock[guildId]) {
      return 0;
    }
    const stock = this.data.rotatingShopStock[guildId];
    const elapsed = Date.now() - stock.lastRestock;
    return Math.max(0, RESTOCK_INTERVAL - elapsed);
  }

  removeCustomShopItem(guildId: string, itemId: string): boolean {
    const index = this.data.customShopItems.findIndex(item => item.guildId === guildId && item.id === itemId);
    if (index !== -1) {
      this.data.customShopItems.splice(index, 1);
      this.markDirty();
      return true;
    }
    return false;
  }

  updateCustomShopItem(guildId: string, itemId: string, updates: { name?: string; price?: number }): boolean {
    const item = this.getCustomShopItem(guildId, itemId);
    if (item) {
      if (updates.name !== undefined) item.name = updates.name;
      if (updates.price !== undefined) item.price = updates.price;
      this.markDirty();
      return true;
    }
    return false;
  }

  updateLootbox(guildId: string, lootboxId: string, updates: { name?: string; price?: number }): boolean {
    const lootbox = this.getLootbox(guildId, lootboxId);
    if (lootbox) {
      if (updates.name !== undefined) lootbox.name = updates.name;
      if (updates.price !== undefined) lootbox.price = updates.price;
      this.markDirty();
      return true;
    }
    return false;
  }

  removeLootboxItem(guildId: string, lootboxId: string, itemName: string): boolean {
    const lootbox = this.getLootbox(guildId, lootboxId);
    if (lootbox) {
      const index = lootbox.items.findIndex(item => item.name.toLowerCase() === itemName.toLowerCase());
      if (index !== -1) {
        lootbox.items.splice(index, 1);
        this.markDirty();
        return true;
      }
    }
    return false;
  }

  getManagers(guildId: string): string[] {
    if (!this.data.managers[guildId]) {
      this.data.managers[guildId] = [];
    }
    return this.data.managers[guildId];
  }

  addManager(guildId: string, userId: string): boolean {
    if (!this.data.managers[guildId]) {
      this.data.managers[guildId] = [];
    }
    if (!this.data.managers[guildId].includes(userId)) {
      this.data.managers[guildId].push(userId);
      this.markDirty();
      return true;
    }
    return false;
  }

  removeManager(guildId: string, userId: string): boolean {
    if (!this.data.managers[guildId]) {
      return false;
    }
    const index = this.data.managers[guildId].indexOf(userId);
    if (index !== -1) {
      this.data.managers[guildId].splice(index, 1);
      this.markDirty();
      return true;
    }
    return false;
  }

  isManager(guildId: string, userId: string): boolean {
    if (!this.data.managers[guildId]) {
      return false;
    }
    return this.data.managers[guildId].includes(userId);
  }

  getBannedUsers(guildId: string): string[] {
    if (!this.data.bannedUsers[guildId]) {
      this.data.bannedUsers[guildId] = [];
    }
    return this.data.bannedUsers[guildId];
  }

  banUser(guildId: string, userId: string): boolean {
    if (!this.data.bannedUsers[guildId]) {
      this.data.bannedUsers[guildId] = [];
    }
    if (!this.data.bannedUsers[guildId].includes(userId)) {
      this.data.bannedUsers[guildId].push(userId);
      this.markDirty();
      return true;
    }
    return false;
  }

  unbanUser(guildId: string, userId: string): boolean {
    if (!this.data.bannedUsers[guildId]) {
      return false;
    }
    const index = this.data.bannedUsers[guildId].indexOf(userId);
    if (index !== -1) {
      this.data.bannedUsers[guildId].splice(index, 1);
      this.markDirty();
      return true;
    }
    return false;
  }

  isBanned(guildId: string, userId: string): boolean {
    if (!this.data.bannedUsers[guildId]) {
      return false;
    }
    return this.data.bannedUsers[guildId].includes(userId);
  }

  clearInventory(guildId: string, userId: string): void {
    const user = this.getUser(guildId, userId);
    user.inventory = [];
    user.balance = 0;
    user.boost = 1; // Reset boost to default
    user.purchasedItems = []; // Clear purchase history to reset passive income and other upgrades
    this.markDirty();
  }

  removeFromInventory(guildId: string, userId: string, itemName: string): boolean {
    const user = this.getUser(guildId, userId);
    const index = user.inventory.findIndex(item => item.toLowerCase() === itemName.toLowerCase());
    if (index !== -1) {
      user.inventory.splice(index, 1);
      this.markDirty();
      return true;
    }
    return false;
  }

  markItemAsPurchased(guildId: string, userId: string, itemId: string): void {
    const user = this.getUser(guildId, userId);
    if (!user.purchasedItems.includes(itemId)) {
      user.purchasedItems.push(itemId);
      this.markDirty();
    }
  }

  hasUserPurchased(guildId: string, userId: string, itemId: string): boolean {
    const user = this.getUser(guildId, userId);
    return user.purchasedItems.includes(itemId);
  }

  setItemMultiPurchase(guildId: string, itemId: string, multiPurchase: boolean): boolean {
    // Try custom items first
    const item = this.getCustomShopItem(guildId, itemId);
    if (item) {
      item.multiPurchase = multiPurchase;
      this.markDirty();
      return true;
    }

    // Check if it's a default item
    const defaultItems = this.getDefaultShopItems();
    const defaultItem = defaultItems.find(i => i.id === itemId);
    if (defaultItem) {
      if (!this.data.defaultItemOverrides[guildId]) {
        this.data.defaultItemOverrides[guildId] = {};
      }
      if (!this.data.defaultItemOverrides[guildId][itemId]) {
        this.data.defaultItemOverrides[guildId][itemId] = {};
      }
      this.data.defaultItemOverrides[guildId][itemId].multiPurchase = multiPurchase;
      this.markDirty();
      return true;
    }

    return false;
  }

  setItemPrice(guildId: string, itemId: string, price: number): boolean {
    // Try custom items first
    const item = this.getCustomShopItem(guildId, itemId);
    if (item) {
      item.price = price;
      this.markDirty();
      return true;
    }

    // Check if it's a default item (boost or passive_income)
    const defaultItems = this.getDefaultShopItems();
    const defaultItem = defaultItems.find(i => i.id === itemId);
    if (defaultItem) {
      if (!this.data.defaultItemOverrides[guildId]) {
        this.data.defaultItemOverrides[guildId] = {};
      }
      if (!this.data.defaultItemOverrides[guildId][itemId]) {
        this.data.defaultItemOverrides[guildId][itemId] = {};
      }
      this.data.defaultItemOverrides[guildId][itemId].price = price;
      this.markDirty();
      return true;
    }

    return false;
  }

  isCoinflipEnabled(guildId: string): boolean {
    if (this.data.coinflipEnabled[guildId] === undefined) {
      return true;
    }
    return this.data.coinflipEnabled[guildId];
  }

  setCoinflipEnabled(guildId: string, enabled: boolean): void {
    this.data.coinflipEnabled[guildId] = enabled;
    this.markDirty();
  }

  resetAllUsers(guildId: string): void {
    if (this.data.users[guildId]) {
      this.data.users[guildId] = {};
      this.markDirty();
    }
  }

  public getDuelChallenges(): any[] {
    if (!this.data.duelChallenges) this.data.duelChallenges = [];
    return this.data.duelChallenges;
  }

  public setDuelChallenges(challenges: any[]): void {
    this.data.duelChallenges = challenges;
    this.markDirty();
  }

  public getFaceoffChallenges(): any[] {
    if (!this.data.faceoffChallenges) this.data.faceoffChallenges = [];
    return this.data.faceoffChallenges;
  }

  public setFaceoffChallenges(challenges: any[]): void {
    this.data.faceoffChallenges = challenges;
    this.markDirty();
  }

  public getRpsChallenges(): any[] {
    if (!this.data.rpsChallenges) this.data.rpsChallenges = [];
    return this.data.rpsChallenges;
  }

  public setRpsChallenges(challenges: any[]): void {
    this.data.rpsChallenges = challenges;
    this.markDirty();
  }

  public getTradeOffers(): any[] {
    if (!this.data.tradeOffers) this.data.tradeOffers = [];
    return this.data.tradeOffers;
  }

  public setTradeOffers(offers: any[]): void {
    this.data.tradeOffers = offers;
    this.markDirty();
  }

  public getDailyQuests(guildId: string): any {
    if (!this.data.dailyQuests) this.data.dailyQuests = {};
    return this.data.dailyQuests[guildId];
  }

  public setDailyQuests(guildId: string, quests: any): void {
    if (!this.data.dailyQuests) this.data.dailyQuests = {};
    this.data.dailyQuests[guildId] = quests;
    this.markDirty();
  }

  public getServerSettings(guildId: string): any {
    if (!this.data.serverSettings) this.data.serverSettings = {};
    if (!this.data.serverSettings[guildId]) {
      this.data.serverSettings[guildId] = {
        guildId,
        currencySystemEnabled: true,
        dismegleEnabled: true,
        baseCurrencyPerMessage: 100,
        baseEarningsExpiry: undefined
      };
      this.markDirty();
    }
    // Ensure baseCurrencyPerMessage exists
    if (this.data.serverSettings[guildId].baseCurrencyPerMessage === undefined) {
      this.data.serverSettings[guildId].baseCurrencyPerMessage = 100;
      this.markDirty();
    }
    return this.data.serverSettings[guildId];
  }

  public setCurrencySystemEnabled(guildId: string, enabled: boolean): void {
    const settings = this.getServerSettings(guildId);
    settings.currencySystemEnabled = enabled;
    this.markDirty();
  }

  public setDismegleEnabled(guildId: string, enabled: boolean): void {
    const settings = this.getServerSettings(guildId);
    settings.dismegleEnabled = enabled;
    this.markDirty();
  }

  public getChatSessions(): any[] {
    if (!this.data.chatSessions) this.data.chatSessions = [];
    return this.data.chatSessions;
  }

  public setChatSessions(sessions: any[]): void {
    this.data.chatSessions = sessions;
    this.markDirty();
  }

  public getMatchQueue(guildId: string): any {
    if (!this.data.matchQueue) this.data.matchQueue = {};
    if (!this.data.matchQueue[guildId]) {
      this.data.matchQueue[guildId] = {
        '1v1': [],
        'group': [],
        '1v1voice': [],
        'groupvoice': []
      };
    }
    return this.data.matchQueue[guildId];
  }

  public setMatchQueue(guildId: string, queue: any): void {
    if (!this.data.matchQueue) this.data.matchQueue = {};
    this.data.matchQueue[guildId] = queue;
    this.markDirty();
  }

  public getRotatingShopConfig(guildId: string): RotatingShopConfig {
    if (!this.data.rotatingShopConfigs) this.data.rotatingShopConfigs = {};
    if (!this.data.rotatingShopConfigs[guildId]) {
      this.data.rotatingShopConfigs[guildId] = {
        guildId,
        enabled: true,
        muteTokenPrice: 20000,
        muteTokenDuration: 5000,
        nicknameTokenPrice: 20000,
        nicknameTokenDuration: 60000,
        slowmodeTokenPrice: 15000,
        slowmodeTokenDuration: 10000,
        voiceMuteTokenPrice: 25000,
        voiceMuteTokenDuration: 8000,
        roleColorTokenPrice: 30000,
        roleColorTokenDuration: 30000,
        currentTokens: [],
        lastRestock: 0
      };
      this.markDirty();
    }
    
    // Ensure legacy configs have new fields
    const config = this.data.rotatingShopConfigs[guildId];
    if (!config.currentTokens) config.currentTokens = [];
    if (!config.lastRestock) config.lastRestock = 0;
    if (config.slowmodeTokenPrice === undefined) config.slowmodeTokenPrice = 15000;
    if (config.slowmodeTokenDuration === undefined) config.slowmodeTokenDuration = 10000;
    if (config.voiceMuteTokenPrice === undefined) config.voiceMuteTokenPrice = 25000;
    if (config.voiceMuteTokenDuration === undefined) config.voiceMuteTokenDuration = 8000;
    if (config.roleColorTokenPrice === undefined) config.roleColorTokenPrice = 30000;
    if (config.roleColorTokenDuration === undefined) config.roleColorTokenDuration = 30000;
    
    return this.data.rotatingShopConfigs[guildId];
  }

  public setRotatingShopConfig(guildId: string, config: Partial<RotatingShopConfig>): void {
    if (!this.data.rotatingShopConfigs) this.data.rotatingShopConfigs = {};
    const current = this.getRotatingShopConfig(guildId);
    this.data.rotatingShopConfigs[guildId] = { ...current, ...config };
    this.markDirty();
  }

  public getActiveEffects(): ActiveEffect[] {
    if (!this.data.activeEffects) this.data.activeEffects = [];
    return this.data.activeEffects;
  }

  public addActiveEffect(effect: ActiveEffect): void {
    if (!this.data.activeEffects) this.data.activeEffects = [];
    this.data.activeEffects.push(effect);
    this.markDirty();
  }

  public removeActiveEffect(effectId: string): void {
    if (!this.data.activeEffects) this.data.activeEffects = [];
    this.data.activeEffects = this.data.activeEffects.filter(e => e.id !== effectId);
    this.markDirty();
  }

  public getActiveEffectsByGuild(guildId: string): ActiveEffect[] {
    if (!this.data.activeEffects) this.data.activeEffects = [];
    return this.data.activeEffects.filter(e => e.guildId === guildId);
  }

  public getRedeemCodes(guildId: string): RedeemCode[] {
    if (!this.data.redeemCodes) this.data.redeemCodes = [];
    return this.data.redeemCodes.filter(c => c.guildId === guildId);
  }

  public createRedeemCode(guildId: string, codeName: string, reward: number, createdBy: string): RedeemCode | null {
    if (!this.data.redeemCodes) this.data.redeemCodes = [];
    
    const existing = this.data.redeemCodes.find(c => c.guildId === guildId && c.codeName.toLowerCase() === codeName.toLowerCase());
    if (existing) return null;
    
    const code: RedeemCode = {
      guildId,
      codeName: codeName.toLowerCase(),
      reward,
      createdBy,
      createdAt: Date.now(),
      claimedBy: []
    };
    
    this.data.redeemCodes.push(code);
    this.markDirty();
    return code;
  }

  public getRedeemCode(guildId: string, codeName: string): RedeemCode | undefined {
    if (!this.data.redeemCodes) this.data.redeemCodes = [];
    return this.data.redeemCodes.find(c => c.guildId === guildId && c.codeName.toLowerCase() === codeName.toLowerCase());
  }

  public claimRedeemCode(guildId: string, codeName: string, userId: string): { success: boolean; reward?: number; message: string } {
    const code = this.getRedeemCode(guildId, codeName);
    
    if (!code) {
      return { success: false, message: '❌ Code not found!' };
    }
    
    if (code.claimedBy.includes(userId)) {
      return { success: false, message: '❌ You have already claimed this code!' };
    }
    
    code.claimedBy.push(userId);
    this.addCurrencyRaw(guildId, userId, code.reward);
    this.markDirty();
    
    return { success: true, reward: code.reward, message: `✅ Successfully claimed code! +${code.reward.toLocaleString()} 💰` };
  }

  public deleteRedeemCode(guildId: string, codeName: string): boolean {
    if (!this.data.redeemCodes) this.data.redeemCodes = [];
    const index = this.data.redeemCodes.findIndex(c => c.guildId === guildId && c.codeName.toLowerCase() === codeName.toLowerCase());
    
    if (index === -1) return false;
    
    this.data.redeemCodes.splice(index, 1);
    this.markDirty();
    return true;
  }

  public getStaffShopConfig(guildId: string): StaffShopConfig {
    if (!this.data.staffShopConfigs) this.data.staffShopConfigs = {};
    if (!this.data.staffShopConfigs[guildId]) {
      this.data.staffShopConfigs[guildId] = {
        guildId,
        staffRoleId: '',
        enabled: false,
        basePrice: 50000,
        cooldownDays: 5,
        totalPurchaseCount: 0
      };
      this.markDirty();
    }
    // Ensure backwards compatibility by adding missing fields
    let needsSave = false;
    if (this.data.staffShopConfigs[guildId].basePrice === undefined) {
      this.data.staffShopConfigs[guildId].basePrice = 50000;
      needsSave = true;
    }
    if (this.data.staffShopConfigs[guildId].cooldownDays === undefined) {
      this.data.staffShopConfigs[guildId].cooldownDays = 5;
      needsSave = true;
    }
    if (this.data.staffShopConfigs[guildId].totalPurchaseCount === undefined) {
      this.data.staffShopConfigs[guildId].totalPurchaseCount = 0;
      needsSave = true;
    }
    if (needsSave) {
      this.markDirty();
    }
    return this.data.staffShopConfigs[guildId];
  }

  public setStaffShopConfig(guildId: string, config: Partial<StaffShopConfig>): void {
    if (!this.data.staffShopConfigs) this.data.staffShopConfigs = {};
    const current = this.getStaffShopConfig(guildId);
    this.data.staffShopConfigs[guildId] = { ...current, ...config };
    this.markDirty();
  }

  public getPromotionPurchase(guildId: string, userId: string): PromotionPurchase | undefined {
    if (!this.data.promotionPurchases) this.data.promotionPurchases = [];
    return this.data.promotionPurchases.find(p => p.guildId === guildId && p.userId === userId);
  }

  public recordPromotionPurchase(guildId: string, userId: string): void {
    if (!this.data.promotionPurchases) this.data.promotionPurchases = [];
    
    const config = this.getStaffShopConfig(guildId);
    const existing = this.getPromotionPurchase(guildId, userId);
    const now = Date.now();
    const cooldownMs = config.cooldownDays * 24 * 60 * 60 * 1000;
    
    if (existing) {
      existing.purchasedAt = now;
      existing.cooldownUntil = now + cooldownMs;
    } else {
      this.data.promotionPurchases.push({
        guildId,
        userId,
        purchasedAt: now,
        cooldownUntil: now + cooldownMs
      });
    }
    
    this.markDirty();
  }

  public isPromotionOnCooldown(guildId: string, userId: string): { onCooldown: boolean; timeLeft?: number } {
    const purchase = this.getPromotionPurchase(guildId, userId);
    if (!purchase) return { onCooldown: false };
    
    const now = Date.now();
    if (now < purchase.cooldownUntil) {
      return { onCooldown: true, timeLeft: purchase.cooldownUntil - now };
    }
    
    return { onCooldown: false };
  }

  public getCurrentPromotionPrice(guildId: string, userId?: string): number {
    const config = this.getStaffShopConfig(guildId);
    
    if (!userId) {
      return config.basePrice;
    }
    
    if (!this.data.promotionPurchases) this.data.promotionPurchases = [];
    
    const userPurchaseCount = this.data.promotionPurchases.filter(
      p => p.guildId === guildId && p.userId === userId
    ).length;
    
    return config.basePrice * Math.pow(2, userPurchaseCount);
  }

  public resetPromotionPurchaseCount(guildId: string): void {
    const config = this.getStaffShopConfig(guildId);
    config.totalPurchaseCount = 0;
    this.markDirty();
  }

  public recalculatePromotionPurchaseCount(guildId: string): number {
    if (!this.data.promotionPurchases) this.data.promotionPurchases = [];
    
    const guildPurchases = this.data.promotionPurchases.filter(p => p.guildId === guildId);
    
    const uniquePurchases = new Map<string, typeof guildPurchases[0]>();
    for (const purchase of guildPurchases) {
      const key = `${purchase.guildId}_${purchase.userId}`;
      if (!uniquePurchases.has(key) || purchase.purchasedAt > uniquePurchases.get(key)!.purchasedAt) {
        uniquePurchases.set(key, purchase);
      }
    }
    
    this.data.promotionPurchases = this.data.promotionPurchases.filter(p => p.guildId !== guildId);
    this.data.promotionPurchases.push(...Array.from(uniquePurchases.values()));
    
    const count = uniquePurchases.size;
    const config = this.getStaffShopConfig(guildId);
    config.totalPurchaseCount = count;
    this.markDirty();
    
    return count;
  }

  public setPromotionBasePrice(guildId: string, price: number): void {
    const config = this.getStaffShopConfig(guildId);
    config.basePrice = price;
    this.markDirty();
  }

  public setPromotionCooldown(guildId: string, days: number): void {
    const config = this.getStaffShopConfig(guildId);
    config.cooldownDays = days;
    this.markDirty();
  }

  public setDefaultItemPrice(guildId: string, itemId: string, price: number): void {
    if (!this.data.defaultItemOverrides) this.data.defaultItemOverrides = {};
    if (!this.data.defaultItemOverrides[guildId]) {
      this.data.defaultItemOverrides[guildId] = {};
    }
    if (!this.data.defaultItemOverrides[guildId][itemId]) {
      this.data.defaultItemOverrides[guildId][itemId] = {};
    }
    this.data.defaultItemOverrides[guildId][itemId].price = price;
    this.markDirty();
  }

  public isTokenOnCooldown(guildId: string, userId: string, tokenId: string): { onCooldown: boolean; timeLeft?: number } {
    const user = this.getUser(guildId, userId);
    if (!user.tokenPurchases) {
      user.tokenPurchases = [];
    }

    const purchase = user.tokenPurchases.find(p => p.tokenId === tokenId);
    if (!purchase) {
      return { onCooldown: false };
    }

    const now = Date.now();
    const HOUR_MS = 60 * 60 * 1000;
    const cooldownEnd = purchase.purchasedAt + HOUR_MS;

    if (now < cooldownEnd) {
      return { onCooldown: true, timeLeft: cooldownEnd - now };
    }

    return { onCooldown: false };
  }

  public recordTokenPurchase(guildId: string, userId: string, tokenId: string): void {
    const user = this.getUser(guildId, userId);
    if (!user.tokenPurchases) {
      user.tokenPurchases = [];
    }

    const existingIndex = user.tokenPurchases.findIndex(p => p.tokenId === tokenId);
    const now = Date.now();

    if (existingIndex !== -1) {
      user.tokenPurchases[existingIndex].purchasedAt = now;
    } else {
      user.tokenPurchases.push({
        tokenId,
        purchasedAt: now
      });
    }

    this.markDirty();
  }

  public setRoleBoost(guildId: string, roleId: string, multiplier: number): void {
    if (!this.data.roleBoosts) this.data.roleBoosts = {};
    if (!this.data.roleBoosts[guildId]) {
      this.data.roleBoosts[guildId] = {};
    }
    this.data.roleBoosts[guildId][roleId] = multiplier;
    this.markDirty();
  }

  public getRoleBoost(guildId: string, roleId: string): number {
    if (!this.data.roleBoosts || !this.data.roleBoosts[guildId]) return 1;
    return this.data.roleBoosts[guildId][roleId] || 1;
  }

  public getRoleBoosts(guildId: string): { roleId: string; multiplier: number }[] {
    if (!this.data.roleBoosts || !this.data.roleBoosts[guildId]) return [];
    return Object.entries(this.data.roleBoosts[guildId]).map(([roleId, multiplier]) => ({
      roleId,
      multiplier
    }));
  }

  public removeRoleBoost(guildId: string, roleId: string): void {
    if (!this.data.roleBoosts || !this.data.roleBoosts[guildId]) return;
    delete this.data.roleBoosts[guildId][roleId];
    this.markDirty();
  }

  public clearRoleBoosts(guildId: string): void {
    if (!this.data.roleBoosts) this.data.roleBoosts = {};
    this.data.roleBoosts[guildId] = {};
    this.markDirty();
  }

  public disableCommand(guildId: string, command: string): void {
    if (!this.data.disabledCommands) this.data.disabledCommands = {};
    if (!this.data.disabledCommands[guildId]) {
      this.data.disabledCommands[guildId] = [];
    }
    const cmd = command.toLowerCase();
    if (!this.data.disabledCommands[guildId].includes(cmd)) {
      this.data.disabledCommands[guildId].push(cmd);
    }
    this.markDirty();
  }

  public enableCommand(guildId: string, command: string): void {
    if (!this.data.disabledCommands || !this.data.disabledCommands[guildId]) return;
    const cmd = command.toLowerCase();
    const index = this.data.disabledCommands[guildId].indexOf(cmd);
    if (index > -1) {
      this.data.disabledCommands[guildId].splice(index, 1);
    }
    this.markDirty();
  }

  public isCommandDisabled(guildId: string, command: string): boolean {
    if (!this.data.disabledCommands || !this.data.disabledCommands[guildId]) return false;
    return this.data.disabledCommands[guildId].includes(command.toLowerCase());
  }

  public getDisabledCommands(guildId: string): string[] {
    if (!this.data.disabledCommands || !this.data.disabledCommands[guildId]) return [];
    return [...this.data.disabledCommands[guildId]];
  }

  public clearDisabledCommands(guildId: string): void {
    if (!this.data.disabledCommands) this.data.disabledCommands = {};
    this.data.disabledCommands[guildId] = [];
    this.markDirty();
  }
}
