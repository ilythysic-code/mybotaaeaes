import { Client, GatewayIntentBits, Partials, Message, EmbedBuilder, MessageFlags } from 'discord.js';
import { DataManager } from './dataManager';
import { CommandHandler } from './commands';
import * as fs from 'fs';
import * as path from 'path';

const DISCORD_BOT_TOKEN = process.env.DISCORD_BOT_TOKEN;

if (!DISCORD_BOT_TOKEN) {
  console.error('❌ Error: DISCORD_BOT_TOKEN is not set!');
  console.log('Please add your Discord bot token in the Secrets tab.');
  console.log('You can get your bot token from: https://discord.com/developers/applications');
  process.exit(1);
}

async function startBot() {
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers
    ],
    partials: [Partials.Message, Partials.Channel]
  });

  const dataManager = new DataManager();
  const commandHandler = new CommandHandler(dataManager);
  
  const processedMessages = new Set<string>();
  const MESSAGE_CACHE_DURATION = 10000;

  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;
    if (!interaction.guild) return;

    const settings = dataManager.getServerSettings(interaction.guild.id);
    if (!settings.dismegleEnabled) {
      await interaction.reply({ content: '❌ Dismegle features are disabled on this server!', flags: MessageFlags.Ephemeral });
      return;
    }

    const user = dataManager.getUser(interaction.guild.id, interaction.user.id);
    if (user.activeChatSession) {
      await interaction.reply({ content: '❌ You\'re already in a chat! Use `?leave` to exit first.', flags: MessageFlags.Ephemeral });
      return;
    }

    if (interaction.customId === 'dismegle_text') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      await commandHandler['handleFindChatWithInterests'](interaction.guild, interaction.user.id);
      await interaction.editReply({ content: '✅ Queued for text chat! Waiting for a match...' });
    } else if (interaction.customId === 'dismegle_voice') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      await commandHandler['handleFindVoiceWithInterests'](interaction.guild, interaction.user.id);
      await interaction.editReply({ content: '✅ Queued for voice chat! Waiting for a match...' });
    }
  });

  client.once('clientReady', async (readyClient) => {
    console.log(`✅ Bot is online as ${readyClient.user.tag}!`);
    console.log(`🆔 Bot User ID: ${readyClient.user.id}`);
    console.log(`📊 Connected to ${readyClient.guilds.cache.size} server(s)`);
    readyClient.guilds.cache.forEach(guild => {
      console.log(`   - ${guild.name} (ID: ${guild.id})`);
      const botMembers = guild.members.cache.filter(member => member.user.bot && member.user.tag.includes('yapcord dealer'));
      console.log(`   - yapcord dealer bots in this server: ${botMembers.size}`);
      botMembers.forEach(bot => console.log(`     * ${bot.user.tag} (${bot.user.id})`));
    });
    console.log('💰 Currency system is active!');

    // Set up hourly data export
    const setupHourlyExport = () => {
      // Export immediately on startup
      dataManager.exportToJSON();

      // Then export every hour
      const hourlyTimer = setInterval(() => {
        dataManager.exportToJSON();
      }, 60 * 60 * 1000); // 1 hour in milliseconds

      // Ensure the timer doesn't prevent process termination
      hourlyTimer.unref();
      
      console.log('⏰ Hourly data export enabled');
    };

    setupHourlyExport();

    try {
      if (readyClient.user.username !== 'yapcord dealer') {
        await readyClient.user.setUsername('yapcord dealer');
        console.log('✅ Bot username updated to "yapcord dealer"');
      }

      const avatarPath = path.join(__dirname, '../attached_assets/generated_images/Yapcord_dealer_bot_avatar_3f87118e.png');
      if (fs.existsSync(avatarPath)) {
        const avatar = fs.readFileSync(avatarPath);
        await readyClient.user.setAvatar(avatar);
        console.log('✅ Bot avatar updated with custom profile picture');
      }
    } catch (error: any) {
      if (error.code === 50035) {
        console.log('⚠️ Username change rate limited. Will retry on next restart.');
      } else {
        console.error('⚠️ Could not update bot profile:', error.message);
      }
    }

    setInterval(() => {
      dataManager.saveData();
    }, 5000); // Save every 5 seconds (reduced from 15s) to prevent data loss

    // Create historical backup every 1 minute
    setInterval(() => {
      dataManager.createBackup();
    }, 60000); // 1 minute

    // Passive earnings: Give all users 1 currency per second (+ bonus if they own upgrade)
    setInterval(() => {
      readyClient.guilds.cache.forEach(guild => {
        const settings = dataManager.getServerSettings(guild.id);
        if (settings.currencySystemEnabled) {
          const guildData = dataManager.getAllUsers(guild.id);
          const users = Object.keys(guildData);
          
          users.forEach(userId => {
            const user = dataManager.getUser(guild.id, userId);
            let passiveAmount = 1; // Base passive income
            
            // Check if user owns passive income upgrade
            if (user.purchasedItems?.includes('passive_income')) {
              passiveAmount += 1; // +1 bonus from upgrade (total 2/s)
            }
            
            dataManager.addCurrencyRaw(guild.id, userId, passiveAmount);
          });
        }
      });
    }, 1000); // Run every second

    console.log('💸 Passive earnings enabled: all users earn 1💰/second (2💰/s with upgrade)');
    console.log('💾 Auto-save enabled: saving every 5 seconds');
    console.log('📦 Backup system enabled: creating historical backups every 1 minute');

    // Restore active nickname effects on startup
    setTimeout(() => {
      const activeEffects = dataManager.getActiveEffects();
      const now = Date.now();
      
      for (const effect of activeEffects) {
        if (effect.type !== 'nickname') continue;
        
        if (effect.expiresAt <= now) {
          // Effect has expired, restore nickname immediately
          readyClient.guilds.cache.get(effect.guildId)?.members.fetch(effect.targetUserId)
            .then(member => {
              member.setNickname(effect.originalNickname || null)
                .then(() => dataManager.removeActiveEffect(effect.id))
                .catch(() => dataManager.removeActiveEffect(effect.id));
            })
            .catch(() => dataManager.removeActiveEffect(effect.id));
        } else {
          // Effect is still active, set up timer to restore when it expires
          const timeLeft = effect.expiresAt - now;
          setTimeout(async () => {
            try {
              const guild = readyClient.guilds.cache.get(effect.guildId);
              if (guild) {
                const member = await guild.members.fetch(effect.targetUserId);
                await member.setNickname(effect.originalNickname || null);
              }
              dataManager.removeActiveEffect(effect.id);
            } catch (error) {
              dataManager.removeActiveEffect(effect.id);
            }
          }, timeLeft);
        }
      }
      
      console.log(`✅ Restored ${activeEffects.filter(e => e.type === 'nickname' && e.expiresAt > now).length} active nickname effects`);
    }, 5000);

    // FIX: Retroactively apply boost values to users who purchased boosts before the fix
    setTimeout(() => {
      console.log('🔍 Running boost migration check...');
      let fixedCount = 0;
      readyClient.guilds.cache.forEach(guild => {
        const guildData = dataManager.getAllUsers(guild.id);
        const users = Object.keys(guildData);
        
        users.forEach(userId => {
          const user = dataManager.getUser(guild.id, userId);
          if (!user.purchasedItems) return;
          
          // Find the highest boost they own
          let highestBoost = 1;
          
          if (user.purchasedItems.includes('boost_100x')) {
            highestBoost = 100;
          } else if (user.purchasedItems.includes('boost_10x')) {
            highestBoost = 10;
          } else if (user.purchasedItems.includes('boost_2x')) {
            highestBoost = 2;
          } else if (user.purchasedItems.includes('boost_1.5x')) {
            highestBoost = 1.5;
          }
          
          // Only update if they own a boost but don't have the correct value
          if (highestBoost > 1 && user.boost !== highestBoost) {
            console.log(`  - Fixing ${userId}: boost ${user.boost} -> ${highestBoost}`);
            user.boost = highestBoost;
            fixedCount++;
          }
        });
      });
      
      console.log(`✅ Boost migration complete: ${fixedCount} user(s) fixed`);
      if (fixedCount > 0) {
        dataManager.saveData();
      }
    }, 6000);
  });

  client.on('messageCreate', async (message: Message) => {
    if (message.author.bot || !message.guild) return;
    
    if (processedMessages.has(message.id)) {
      return;
    }
    
    processedMessages.add(message.id);
    setTimeout(() => processedMessages.delete(message.id), MESSAGE_CACHE_DURATION);

    const afkCheck = commandHandler.checkAFKReturn(message.guild.id, message.author.id);
    
    if (afkCheck.wasAFK) {
      const hours = Math.floor(afkCheck.duration / 3600);
      const minutes = Math.floor((afkCheck.duration % 3600) / 60);
      const seconds = afkCheck.duration % 60;
      
      let timeString = '';
      if (hours > 0) timeString += `${hours}h `;
      if (minutes > 0) timeString += `${minutes}m `;
      timeString += `${seconds}s`;
      
      const user = dataManager.getUser(message.guild.id, message.author.id);
      
      const embed = new EmbedBuilder()
        .setColor(0x2ECC71)
        .setTitle('👋 Welcome Back!')
        .setDescription(`😊 ${message.author.username} is no longer AFK!\n\n⏱️ **Time away:** ${timeString}\n💰 **Earned:** ${afkCheck.earned.toLocaleString()} currency`)
        .addFields(
          { name: '💵 New Balance', value: `\`${user.balance.toLocaleString()}\` currency`, inline: true }
        )
        .setFooter({ text: '💤 Use ?afk again to earn more while away!' });
      
      if (message.channel.isSendable()) {
        await message.channel.send({ embeds: [embed] });
      }
      
      return;
    }

    const user = dataManager.getUser(message.guild.id, message.author.id);
    
    if (user.activeChatSession) {
      const sessions = dataManager.getChatSessions();
      const session = sessions.find(s => s.id === user.activeChatSession);
      if (session && (session.channelId === message.channel.id || session.threadId === message.channel.id)) {
        if (!session.messages) session.messages = [];
        session.messages.push({
          userId: message.author.id,
          username: message.author.username,
          content: message.content,
          timestamp: Date.now()
        });
        session.lastActivityTime = Date.now();
        dataManager.setChatSessions(sessions);
      }
    }

    if (message.content.startsWith('?')) {
      await commandHandler.handleCommand(message);
    } else {
      const settings = dataManager.getServerSettings(message.guild.id);
      
      if (settings.currencySystemEnabled && !message.channel.isThread()) {
        const user = dataManager.getUser(message.guild.id, message.author.id);
        // Check if temporary base has expired
        let baseEarnings = settings.baseCurrencyPerMessage || 100;
        if (settings.baseEarningsExpiry && settings.baseEarningsExpiry <= Date.now()) {
          // Temporary base has expired, reset to default
          baseEarnings = 100;
          settings.baseCurrencyPerMessage = 100;
          settings.baseEarningsExpiry = undefined;
        }
        const earnedAmount = baseEarnings * user.boost;
        
        dataManager.addCurrency(message.guild.id, message.author.id, baseEarnings);
        
        user.messageCount++;
        
        if (user.messageCount % 100 === 0) {
          const updatedUser = dataManager.getUser(message.guild.id, message.author.id);
          
          const embed = new EmbedBuilder()
            .setColor(0xFFD700)
            .setTitle('🎉 Milestone Reached!')
            .setDescription(`${message.author}, you've sent **${user.messageCount} messages**!`)
            .addFields(
              { name: '💰 Current Balance', value: `\`${updatedUser.balance.toLocaleString()}\` currency`, inline: true },
              { name: '💵 Last Message Earned', value: `\`${earnedAmount.toLocaleString()}\` currency`, inline: true },
              { name: '⚡ Current Boost', value: `\`${updatedUser.boost}x\``, inline: true }
            )
            .setFooter({ text: '🛒 Check out ?shop to spend your currency on boosts and items!' });
          
          if (message.channel.isSendable()) {
            await message.channel.send({ embeds: [embed] });
          }
        }
      }
    }
  });

  client.on('error', (error) => {
    console.error('Discord client error:', error);
  });

  await client.login(DISCORD_BOT_TOKEN);
  
  return dataManager;
}

let dataManagerInstance: any = null;

async function startBotWrapper() {
  const instance = await startBot();
  dataManagerInstance = instance;
}

startBotWrapper().catch((error) => {
  console.error('Failed to start bot:', error);
  process.exit(1);
});

process.on('unhandledRejection', (error) => {
  console.error('Unhandled promise rejection:', error);
});

process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down bot...');
  if (dataManagerInstance) {
    dataManagerInstance.saveData();
    console.log('💾 Final save completed!');
  }
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Shutting down bot...');
  if (dataManagerInstance) {
    dataManagerInstance.saveData();
    console.log('💾 Final save completed!');
  }
  process.exit(0);
});
