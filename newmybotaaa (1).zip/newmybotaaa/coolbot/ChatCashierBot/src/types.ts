export interface UserData {
  userId: string;
  guildId: string;
  balance: number;
  boost: number;
  inventory: string[];
  messageCount: number;
  afkStartTime?: number;
  purchasedItems: string[];
  lastDaily?: number;
  lastWork?: number;
  lastWeekly?: number;
  dailyStreak?: number;
  lastStreakClaim?: number;
  lastTrivia?: number;
  triviaStreak?: number;
  achievements?: string[];
  title?: string;
  battlePassXP?: number;
  battlePassLevel?: number;
  lastQuest?: number;
  completedQuests?: number;
  vipTier?: number;
  vipExpiry?: number;
  tradeLocked?: boolean;
  scratchCardsWon?: number;
  duelsWon?: number;
  duelsLost?: number;
  treasureHuntsCompleted?: number;
  activeChatSession?: string;
  chatsCompleted?: number;
  totalChatTime?: number;
  interests?: string[];
  blockedUsers?: string[];
  lastHourly?: number;
  miningLevel?: number;
  lastMine?: number;
  activityStreak?: number;
  lastActivity?: number;
  lastHeist?: number;
  lastSpin?: number;
  tokenPurchases?: TokenPurchase[];
}

export interface TokenPurchase {
  tokenId: string;
  purchasedAt: number;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  requirement: number;
  reward: number;
  emoji: string;
  title?: string;
}

export interface DuelChallenge {
  id: string;
  guildId: string;
  challengerId: string;
  targetId: string;
  wager: number;
  expiresAt: number;
}

export interface FaceoffChallenge {
  id: string;
  guildId: string;
  challengerId: string;
  targetId: string;
  wager: number;
  expiresAt: number;
  messageId?: string;
  startTime?: number;
  isBomb?: boolean;
}

export interface RpsChallenge {
  id: string;
  guildId: string;
  challengerId: string;
  targetId: string;
  wager: number;
  expiresAt: number;
  challengerChoice?: 'rock' | 'paper' | 'scissors';
  targetChoice?: 'rock' | 'paper' | 'scissors';
}

export interface TradeOffer {
  id: string;
  guildId: string;
  senderId: string;
  receiverId: string;
  senderOffer: { currency: number; items: string[] };
  receiverOffer: { currency: number; items: string[] };
  expiresAt: number;
  status: 'pending' | 'accepted' | 'rejected' | 'expired';
}

export interface DailyQuest {
  guildId: string;
  quests: Quest[];
  lastRefresh: number;
}

export interface Quest {
  id: string;
  type: 'send_messages' | 'earn_currency' | 'buy_items' | 'use_commands';
  requirement: number;
  reward: number;
  description: string;
}

export interface ShopItem {
  id: string;
  name: string;
  description: string;
  price: number;
  type: 'boost' | 'item';
  value?: number;
  multiPurchase: boolean;
}

export interface LootboxItem {
  name: string;
  chance: number;
}

export interface Lootbox {
  id: string;
  guildId: string;
  name: string;
  price: number;
  items: LootboxItem[];
}

export interface GuildData {
  [userId: string]: UserData;
}

export interface CustomShopItem {
  id: string;
  guildId: string;
  name: string;
  price: number;
  emoji: string;
  multiPurchase: boolean;
}

export interface RoleShopItem {
  id: string;
  guildId: string;
  roleId: string;
  roleName: string;
  price: number;
}

export interface RotatingShopItem {
  id: string;
  guildId: string;
  name: string;
  price: number;
  emoji: string;
  chancePercent: number;
}

export interface RotatingShopStock {
  guildId: string;
  currentItems: string[];
  lastRestock: number;
}

export interface ServerSettings {
  guildId: string;
  currencySystemEnabled: boolean;
  dismegleEnabled: boolean;
  baseCurrencyPerMessage?: number;
  baseEarningsExpiry?: number;
}

export interface RotatingShopConfig {
  guildId: string;
  enabled: boolean;
  muteTokenPrice: number;
  muteTokenDuration: number;
  nicknameTokenPrice: number;
  nicknameTokenDuration: number;
  slowmodeTokenPrice: number;
  slowmodeTokenDuration: number;
  voiceMuteTokenPrice: number;
  voiceMuteTokenDuration: number;
  roleColorTokenPrice: number;
  roleColorTokenDuration: number;
  currentTokens: string[];
  lastRestock: number;
}

export interface ActiveEffect {
  id: string;
  guildId: string;
  targetUserId: string;
  type: 'mute' | 'nickname' | 'slowmode' | 'voice_mute' | 'role_color';
  appliedBy: string;
  expiresAt: number;
  originalNickname?: string;
  originalSlowmode?: number;
  customRoleId?: string;
}

export interface ChatSession {
  id: string;
  guildId: string;
  type: '1v1' | 'group' | '1v1voice' | 'groupvoice';
  users: string[];
  channelId: string;
  voiceChannelId?: string;
  startTime: number;
  lastActivityTime: number;
  categoryId?: string;
  messages?: Array<{ userId: string; username: string; content: string; timestamp: number }>;
  isThread?: boolean;
  threadId?: string;
}

export interface RedeemCode {
  guildId: string;
  codeName: string;
  reward: number;
  createdBy: string;
  createdAt: number;
  claimedBy: string[];
}

export interface StaffShopConfig {
  guildId: string;
  staffRoleId: string;
  enabled: boolean;
  basePrice: number;
  cooldownDays: number;
  totalPurchaseCount: number;
}

export interface PromotionPurchase {
  guildId: string;
  userId: string;
  purchasedAt: number;
  cooldownUntil: number;
}

export interface RoleBoost {
  guildId: string;
  roleId: string;
  multiplier: number;
}

export interface AllData {
  users: { [guildId: string]: GuildData };
  lootboxes: Lootbox[];
  customShopItems: CustomShopItem[];
  roleShopItems: RoleShopItem[];
  rotatingShopItems: RotatingShopItem[];
  rotatingShopStock: { [guildId: string]: RotatingShopStock };
  managers: { [guildId: string]: string[] };
  bannedUsers: { [guildId: string]: string[] };
  defaultItemOverrides: { [guildId: string]: { [itemId: string]: { multiPurchase?: boolean; price?: number } } };
  coinflipEnabled: { [guildId: string]: boolean };
  duelChallenges: DuelChallenge[];
  faceoffChallenges: FaceoffChallenge[];
  rpsChallenges: RpsChallenge[];
  tradeOffers: TradeOffer[];
  dailyQuests: { [guildId: string]: DailyQuest };
  achievements: Achievement[];
  serverSettings: { [guildId: string]: ServerSettings };
  chatSessions: ChatSession[];
  matchQueue: { [guildId: string]: { [type: string]: string[] } };
  dismeglePanels: { [guildId: string]: { channelId: string; messageId: string } };
  rotatingShopConfigs: { [guildId: string]: RotatingShopConfig };
  activeEffects: ActiveEffect[];
  redeemCodes: RedeemCode[];
  staffShopConfigs: { [guildId: string]: StaffShopConfig };
  promotionPurchases: PromotionPurchase[];
  roleBoosts: { [guildId: string]: { [roleId: string]: number } };
  disabledCommands: { [guildId: string]: string[] };
}
