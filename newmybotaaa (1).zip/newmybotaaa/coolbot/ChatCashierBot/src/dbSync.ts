import { db } from './db';
import * as schema from '../shared/schema';
import { AllData, UserData, GuildData } from './types';
import { eq, and } from 'drizzle-orm';

export class DbSync {
  async saveUserData(guildId: string, userId: string, user: UserData): Promise<void> {
    try {
      const existingUser = await db
        .select()
        .from(schema.users)
        .where(and(
          eq(schema.users.userId, userId),
          eq(schema.users.guildId, guildId)
        ))
        .limit(1);

      if (existingUser.length > 0) {
        await db
          .update(schema.users)
          .set({
            balance: user.balance,
            boost: user.boost,
            inventory: user.inventory,
            messageCount: user.messageCount,
            afkStartTime: user.afkStartTime,
            purchasedItems: user.purchasedItems,
            lastDaily: user.lastDaily,
            lastWork: user.lastWork,
            lastWeekly: user.lastWeekly,
            dailyStreak: user.dailyStreak,
            lastStreakClaim: user.lastStreakClaim,
            lastTrivia: user.lastTrivia,
            triviaStreak: user.triviaStreak,
            achievements: user.achievements,
            title: user.title,
            battlePassXP: user.battlePassXP,
            battlePassLevel: user.battlePassLevel,
            lastQuest: user.lastQuest,
            completedQuests: user.completedQuests,
            vipTier: user.vipTier,
            vipExpiry: user.vipExpiry,
            tradeLocked: user.tradeLocked,
            scratchCardsWon: user.scratchCardsWon,
            duelsWon: user.duelsWon,
            duelsLost: user.duelsLost,
            treasureHuntsCompleted: user.treasureHuntsCompleted,
            activeChatSession: user.activeChatSession,
            chatsCompleted: user.chatsCompleted,
            totalChatTime: user.totalChatTime,
            interests: user.interests,
            blockedUsers: user.blockedUsers,
            lastHourly: user.lastHourly,
            miningLevel: user.miningLevel,
            lastMine: user.lastMine,
            activityStreak: user.activityStreak,
            lastActivity: user.lastActivity,
            lastHeist: user.lastHeist,
            lastSpin: user.lastSpin,
          })
          .where(and(
            eq(schema.users.userId, userId),
            eq(schema.users.guildId, guildId)
          ));
      } else {
        await db.insert(schema.users).values({
          userId,
          guildId,
          balance: user.balance,
          boost: user.boost,
          inventory: user.inventory,
          messageCount: user.messageCount,
          afkStartTime: user.afkStartTime,
          purchasedItems: user.purchasedItems,
          lastDaily: user.lastDaily,
          lastWork: user.lastWork,
          lastWeekly: user.lastWeekly,
          dailyStreak: user.dailyStreak,
          lastStreakClaim: user.lastStreakClaim,
          lastTrivia: user.lastTrivia,
          triviaStreak: user.triviaStreak,
          achievements: user.achievements,
          title: user.title,
          battlePassXP: user.battlePassXP,
          battlePassLevel: user.battlePassLevel,
          lastQuest: user.lastQuest,
          completedQuests: user.completedQuests,
          vipTier: user.vipTier,
          vipExpiry: user.vipExpiry,
          tradeLocked: user.tradeLocked,
          scratchCardsWon: user.scratchCardsWon,
          duelsWon: user.duelsWon,
          duelsLost: user.duelsLost,
          treasureHuntsCompleted: user.treasureHuntsCompleted,
          activeChatSession: user.activeChatSession,
          chatsCompleted: user.chatsCompleted,
          totalChatTime: user.totalChatTime,
          interests: user.interests,
          blockedUsers: user.blockedUsers,
          lastHourly: user.lastHourly,
          miningLevel: user.miningLevel,
          lastMine: user.lastMine,
          activityStreak: user.activityStreak,
          lastActivity: user.lastActivity,
          lastHeist: user.lastHeist,
          lastSpin: user.lastSpin,
        });
      }
    } catch (error) {
      console.error('❌ Error syncing user data to database:', error);
    }
  }

  async syncAllData(data: AllData): Promise<void> {
    try {
      // Sync all guild users
      for (const [guildId, guildData] of Object.entries(data.users)) {
        for (const [userId, userData] of Object.entries(guildData)) {
          await this.saveUserData(guildId, userId, userData);
        }
      }

      // Sync lootboxes
      for (const lootbox of data.lootboxes) {
        const existing = await db
          .select()
          .from(schema.lootboxes)
          .where(eq(schema.lootboxes.id, lootbox.id))
          .limit(1);

        if (existing.length > 0) {
          await db
            .update(schema.lootboxes)
            .set({ name: lootbox.name, price: lootbox.price, guildId: lootbox.guildId })
            .where(eq(schema.lootboxes.id, lootbox.id));
        } else {
          await db.insert(schema.lootboxes).values({
            id: lootbox.id,
            guildId: lootbox.guildId,
            name: lootbox.name,
            price: lootbox.price,
          });
        }
      }

      // Sync disabled commands
      if (data.disabledCommands) {
        // Clear existing disabled commands to avoid duplicates or orphaned entries
        await db.delete(schema.disabledCommands);
        for (const [guildId, commands] of Object.entries(data.disabledCommands)) {
          for (const cmd of commands) {
            await db.insert(schema.disabledCommands).values({
              guildId,
              commandName: cmd,
              disabledAt: Date.now()
            });
          }
        }
      }

      console.log('✅ Data synced to database');
    } catch (error) {
      console.error('❌ Error syncing data to database:', error);
    }
  }

  async loadDataFromDatabase(): Promise<AllData | null> {
    try {
      const users = await db.select().from(schema.users);
      
      if (users.length === 0) {
        console.log('📭 No data found in database, will load from JSON');
        return null;
      }

      console.log(`📦 Loading ${users.length} user records from database...`);

      // Reconstruct AllData from database
      const allData: AllData = {
        users: {},
        lootboxes: [],
        customShopItems: [],
        roleShopItems: [],
        rotatingShopItems: [],
        rotatingShopStock: {},
        managers: {},
        bannedUsers: {},
        defaultItemOverrides: {},
        coinflipEnabled: {},
        duelChallenges: [],
        faceoffChallenges: [],
        rpsChallenges: [],
        tradeOffers: [],
        dailyQuests: {},
        achievements: [],
        serverSettings: {},
        chatSessions: [],
        matchQueue: {},
        dismeglePanels: {},
        rotatingShopConfigs: {},
        activeEffects: [],
        redeemCodes: [],
        staffShopConfigs: {},
        promotionPurchases: [],
        roleBoosts: {},
        disabledCommands: {}
      };

      // Load users organized by guildId
      for (const user of users) {
        if (!allData.users[user.guildId]) {
          allData.users[user.guildId] = {};
        }
        
        const userData: UserData = {
          userId: user.userId,
          guildId: user.guildId,
          balance: Number(user.balance) || 0,
          boost: (user.boost as number) || 1,
          inventory: Array.isArray(user.inventory) ? user.inventory : [],
          messageCount: (user.messageCount as number) || 0,
          afkStartTime: (user.afkStartTime as number | undefined),
          purchasedItems: Array.isArray(user.purchasedItems) ? user.purchasedItems : [],
          lastDaily: (user.lastDaily as number | undefined),
          lastWork: (user.lastWork as number | undefined),
          lastWeekly: (user.lastWeekly as number | undefined),
          dailyStreak: (user.dailyStreak as number) || 0,
          lastStreakClaim: (user.lastStreakClaim as number | undefined),
          lastTrivia: (user.lastTrivia as number | undefined),
          triviaStreak: (user.triviaStreak as number) || 0,
          achievements: Array.isArray(user.achievements) ? user.achievements : [],
          title: user.title || undefined,
          battlePassXP: (user.battlePassXP as number) || 0,
          battlePassLevel: (user.battlePassLevel as number) || 0,
          lastQuest: (user.lastQuest as number | undefined),
          completedQuests: (user.completedQuests as number) || 0,
          vipTier: (user.vipTier as number) || 0,
          vipExpiry: (user.vipExpiry as number | undefined),
          tradeLocked: user.tradeLocked || false,
          scratchCardsWon: (user.scratchCardsWon as number) || 0,
          duelsWon: (user.duelsWon as number) || 0,
          duelsLost: (user.duelsLost as number) || 0,
          treasureHuntsCompleted: (user.treasureHuntsCompleted as number) || 0,
          activeChatSession: user.activeChatSession || undefined,
          chatsCompleted: (user.chatsCompleted as number) || 0,
          totalChatTime: (user.totalChatTime as number) || 0,
          interests: Array.isArray(user.interests) ? user.interests : [],
          blockedUsers: Array.isArray(user.blockedUsers) ? user.blockedUsers : [],
          lastHourly: (user.lastHourly as number | undefined),
          miningLevel: (user.miningLevel as number) || 1,
          lastMine: (user.lastMine as number | undefined),
          activityStreak: (user.activityStreak as number) || 1,
          lastActivity: (user.lastActivity as number | undefined),
          lastHeist: (user.lastHeist as number | undefined),
          lastSpin: (user.lastSpin as number | undefined),
        };
        
        allData.users[user.guildId][user.userId] = userData;
      }

      // Load disabled commands
      const dbDisabledCommands = await db.select().from(schema.disabledCommands);
      for (const dc of dbDisabledCommands) {
        if (!allData.disabledCommands[dc.guildId]) {
          allData.disabledCommands[dc.guildId] = [];
        }
        allData.disabledCommands[dc.guildId].push(dc.commandName);
      }

      // Load lootboxes
      const lootboxes = await db.select().from(schema.lootboxes);
      for (const lootbox of lootboxes) {
        const items = await db
          .select()
          .from(schema.lootboxItems)
          .where(eq(schema.lootboxItems.lootboxId, lootbox.id));

        allData.lootboxes.push({
          id: lootbox.id,
          guildId: lootbox.guildId,
          name: lootbox.name,
          price: Number(lootbox.price),
          items: items.map(item => ({ name: item.name, chance: item.chance }))
        });
      }

      console.log('✅ Data restored from database!');
      return allData;
    } catch (error) {
      console.error('⚠️ Could not load from database:', error);
      return null;
    }
  }
}
