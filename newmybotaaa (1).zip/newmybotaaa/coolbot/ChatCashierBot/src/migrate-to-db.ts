import { db } from './db';
import * as schema from '../shared/schema';
import * as fs from 'fs';
import * as path from 'path';
import { AllData } from './types';

async function migrateData() {
  console.log('🔄 Starting migration from JSON to PostgreSQL...');
  
  // Read existing data
  const dataPath = path.join(__dirname, '../data/data.json');
  if (!fs.existsSync(dataPath)) {
    console.log('❌ No data.json found. Nothing to migrate.');
    return;
  }

  const jsonData: AllData = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
  
  try {
    // Migrate users
    console.log('👥 Migrating users...');
    let userCount = 0;
    for (const guildId in jsonData.users) {
      for (const userId in jsonData.users[guildId]) {
        const user = jsonData.users[guildId][userId];
        await db.insert(schema.users).values({
          userId: user.userId,
          guildId: user.guildId,
          balance: user.balance || 0,
          boost: user.boost || 1,
          inventory: user.inventory || [],
          messageCount: user.messageCount || 0,
          afkStartTime: user.afkStartTime,
          purchasedItems: user.purchasedItems || [],
          lastDaily: user.lastDaily,
          lastWork: user.lastWork,
          lastWeekly: user.lastWeekly,
          dailyStreak: user.dailyStreak || 0,
          lastStreakClaim: user.lastStreakClaim,
          lastTrivia: user.lastTrivia,
          triviaStreak: user.triviaStreak || 0,
          achievements: user.achievements || [],
          title: user.title,
          battlePassXP: user.battlePassXP || 0,
          battlePassLevel: user.battlePassLevel || 0,
          lastQuest: user.lastQuest,
          completedQuests: user.completedQuests || 0,
          vipTier: user.vipTier || 0,
          vipExpiry: user.vipExpiry,
          tradeLocked: user.tradeLocked || false,
          scratchCardsWon: user.scratchCardsWon || 0,
          duelsWon: user.duelsWon || 0,
          duelsLost: user.duelsLost || 0,
          treasureHuntsCompleted: user.treasureHuntsCompleted || 0,
          activeChatSession: user.activeChatSession,
          chatsCompleted: user.chatsCompleted || 0,
          totalChatTime: user.totalChatTime || 0,
          interests: user.interests || [],
          blockedUsers: user.blockedUsers || [],
          lastHourly: user.lastHourly,
          miningLevel: user.miningLevel || 1,
          lastMine: user.lastMine,
          activityStreak: user.activityStreak || 1,
          lastActivity: user.lastActivity,
          lastHeist: user.lastHeist,
          lastSpin: user.lastSpin,
        }).onConflictDoNothing();
        userCount++;
      }
    }
    console.log(`✅ Migrated ${userCount} users`);

    // Migrate lootboxes
    console.log('🎁 Migrating lootboxes...');
    if (jsonData.lootboxes) {
      for (const lootbox of jsonData.lootboxes) {
        await db.insert(schema.lootboxes).values({
          id: lootbox.id,
          guildId: lootbox.guildId,
          name: lootbox.name,
          price: lootbox.price,
        }).onConflictDoNothing();

        // Migrate lootbox items
        for (const item of lootbox.items) {
          await db.insert(schema.lootboxItems).values({
            lootboxId: lootbox.id,
            name: item.name,
            chance: item.chance,
          }).onConflictDoNothing();
        }
      }
      console.log(`✅ Migrated ${jsonData.lootboxes.length} lootboxes`);
    }

    // Migrate custom shop items
    console.log('🛒 Migrating custom shop items...');
    if (jsonData.customShopItems) {
      for (const item of jsonData.customShopItems) {
        await db.insert(schema.customShopItems).values({
          id: item.id,
          guildId: item.guildId,
          name: item.name,
          price: item.price,
          emoji: item.emoji,
          multiPurchase: item.multiPurchase || false,
        }).onConflictDoNothing();
      }
      console.log(`✅ Migrated ${jsonData.customShopItems.length} custom items`);
    }

    // Migrate role shop items
    console.log('🎭 Migrating role shop items...');
    if (jsonData.roleShopItems) {
      for (const item of jsonData.roleShopItems) {
        await db.insert(schema.roleShopItems).values({
          id: item.id,
          guildId: item.guildId,
          roleId: item.roleId,
          roleName: item.roleName,
          price: item.price,
        }).onConflictDoNothing();
      }
      console.log(`✅ Migrated ${jsonData.roleShopItems.length} role items`);
    }

    // Migrate rotating shop configs
    console.log('🎫 Migrating rotating shop configs...');
    if (jsonData.rotatingShopConfigs) {
      for (const guildId in jsonData.rotatingShopConfigs) {
        const config = jsonData.rotatingShopConfigs[guildId];
        await db.insert(schema.rotatingShopConfigs).values({
          guildId: config.guildId,
          enabled: config.enabled !== undefined ? config.enabled : true,
          muteTokenPrice: config.muteTokenPrice || 20000,
          muteTokenDuration: config.muteTokenDuration || 5000,
          nicknameTokenPrice: config.nicknameTokenPrice || 20000,
          nicknameTokenDuration: config.nicknameTokenDuration || 60000,
          currentTokens: config.currentTokens || [],
          lastRestock: config.lastRestock || 0,
        }).onConflictDoNothing();
      }
      console.log(`✅ Migrated ${Object.keys(jsonData.rotatingShopConfigs).length} shop configs`);
    }

    // Migrate managers
    console.log('👔 Migrating managers...');
    if (jsonData.managers) {
      for (const guildId in jsonData.managers) {
        for (const userId of jsonData.managers[guildId]) {
          await db.insert(schema.managers).values({
            guildId,
            userId,
          }).onConflictDoNothing();
        }
      }
      console.log(`✅ Migrated managers`);
    }

    // Migrate banned users
    console.log('🚫 Migrating banned users...');
    if (jsonData.bannedUsers) {
      for (const guildId in jsonData.bannedUsers) {
        for (const userId of jsonData.bannedUsers[guildId]) {
          await db.insert(schema.bannedUsers).values({
            guildId,
            userId,
          }).onConflictDoNothing();
        }
      }
      console.log(`✅ Migrated banned users`);
    }

    // Migrate default item overrides
    console.log('⚙️ Migrating item overrides...');
    if (jsonData.defaultItemOverrides) {
      for (const guildId in jsonData.defaultItemOverrides) {
        for (const itemId in jsonData.defaultItemOverrides[guildId]) {
          await db.insert(schema.defaultItemOverrides).values({
            guildId,
            itemId,
            multiPurchase: jsonData.defaultItemOverrides[guildId][itemId].multiPurchase ?? false,
          }).onConflictDoNothing();
        }
      }
      console.log(`✅ Migrated item overrides`);
    }

    // Migrate server settings
    console.log('🔧 Migrating server settings...');
    if (jsonData.serverSettings) {
      for (const guildId in jsonData.serverSettings) {
        const settings = jsonData.serverSettings[guildId];
        const coinflipEnabled = jsonData.coinflipEnabled?.[guildId] !== undefined 
          ? jsonData.coinflipEnabled[guildId] 
          : true;
        
        await db.insert(schema.serverSettings).values({
          guildId: settings.guildId,
          currencySystemEnabled: settings.currencySystemEnabled !== undefined ? settings.currencySystemEnabled : true,
          dismegleEnabled: settings.dismegleEnabled !== undefined ? settings.dismegleEnabled : true,
          coinflipEnabled,
        }).onConflictDoNothing();
      }
      console.log(`✅ Migrated ${Object.keys(jsonData.serverSettings).length} server settings`);
    }

    // Migrate active challenges
    console.log('⚔️ Migrating challenges...');
    if (jsonData.duelChallenges) {
      for (const challenge of jsonData.duelChallenges) {
        await db.insert(schema.duelChallenges).values(challenge).onConflictDoNothing();
      }
      console.log(`✅ Migrated ${jsonData.duelChallenges.length} duel challenges`);
    }

    if (jsonData.faceoffChallenges) {
      for (const challenge of jsonData.faceoffChallenges) {
        await db.insert(schema.faceoffChallenges).values({
          ...challenge,
          isBomb: challenge.isBomb || false,
        }).onConflictDoNothing();
      }
      console.log(`✅ Migrated ${jsonData.faceoffChallenges.length} faceoff challenges`);
    }

    if (jsonData.rpsChallenges) {
      for (const challenge of jsonData.rpsChallenges) {
        await db.insert(schema.rpsChallenges).values(challenge).onConflictDoNothing();
      }
      console.log(`✅ Migrated ${jsonData.rpsChallenges.length} RPS challenges`);
    }

    if (jsonData.tradeOffers) {
      for (const offer of jsonData.tradeOffers) {
        await db.insert(schema.tradeOffers).values(offer).onConflictDoNothing();
      }
      console.log(`✅ Migrated ${jsonData.tradeOffers.length} trade offers`);
    }

    // Migrate daily quests
    console.log('📋 Migrating daily quests...');
    if (jsonData.dailyQuests) {
      for (const guildId in jsonData.dailyQuests) {
        const questData = jsonData.dailyQuests[guildId];
        await db.insert(schema.dailyQuests).values({
          guildId,
          quests: questData.quests,
          lastRefresh: questData.lastRefresh,
        }).onConflictDoNothing();
      }
      console.log(`✅ Migrated ${Object.keys(jsonData.dailyQuests).length} daily quests`);
    }

    // Migrate chat sessions
    console.log('💬 Migrating chat sessions...');
    if (jsonData.chatSessions) {
      for (const session of jsonData.chatSessions) {
        await db.insert(schema.chatSessions).values({
          id: session.id,
          guildId: session.guildId,
          type: session.type,
          users: session.users,
          channelId: session.channelId,
          voiceChannelId: session.voiceChannelId,
          startTime: session.startTime,
          lastActivityTime: session.lastActivityTime,
          categoryId: session.categoryId,
          messages: session.messages || [],
          isThread: session.isThread || false,
          threadId: session.threadId,
        }).onConflictDoNothing();
      }
      console.log(`✅ Migrated ${jsonData.chatSessions.length} chat sessions`);
    }

    // Migrate Dismegle panels
    console.log('🎛️ Migrating Dismegle panels...');
    if (jsonData.dismeglePanels) {
      for (const guildId in jsonData.dismeglePanels) {
        const panel = jsonData.dismeglePanels[guildId];
        await db.insert(schema.dismeglePanels).values({
          guildId,
          channelId: panel.channelId,
          messageId: panel.messageId,
        }).onConflictDoNothing();
      }
      console.log(`✅ Migrated ${Object.keys(jsonData.dismeglePanels).length} panels`);
    }

    // Migrate active effects
    console.log('✨ Migrating active effects...');
    if (jsonData.activeEffects) {
      for (const effect of jsonData.activeEffects) {
        await db.insert(schema.activeEffects).values(effect).onConflictDoNothing();
      }
      console.log(`✅ Migrated ${jsonData.activeEffects.length} active effects`);
    }

    console.log('\n🎉 Migration completed successfully!');
    console.log('📊 Summary:');
    console.log(`   - ${userCount} users migrated`);
    console.log(`   - All shop items, lootboxes, and settings migrated`);
    console.log(`   - All challenges and sessions migrated`);
    console.log('\n💡 Next steps:');
    console.log('   1. Bot is now using PostgreSQL for all data');
    console.log('   2. data.json will be kept as backup but not used');
    console.log('   3. All player progress will persist across updates!');
    
  } catch (error) {
    console.error('❌ Migration failed:', error);
    throw error;
  }
}

migrateData()
  .then(() => {
    console.log('\n✅ Migration script completed');
    process.exit(0);
  })
  .catch((error) => {
    console.error('\n❌ Migration script failed:', error);
    process.exit(1);
  });
