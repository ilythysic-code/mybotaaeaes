#!/bin/bash

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "📊 ALL DATA BACKUPS WITH IST TIMESTAMPS & FILE DETAILS"
echo "═══════════════════════════════════════════════════════════════"
echo ""

if [ ! -d "data/backups" ]; then
    echo "❌ No backups directory found!"
    exit 1
fi

BACKUP_COUNT=$(ls -1 data/backups/backup_*.json 2>/dev/null | wc -l)

if [ "$BACKUP_COUNT" -eq 0 ]; then
    echo "❌ No backup files found in data/backups/"
    exit 1
fi

node << 'NODEEOF'
const fs = require('fs');
const path = require('path');
const backupDir = 'data/backups';

const files = fs.readdirSync(backupDir)
    .filter(f => f.startsWith('backup_') && f.endsWith('.json'))
    .map(f => {
        const fullPath = path.join(backupDir, f);
        const stats = fs.statSync(fullPath);
        
        // Convert to IST
        const date = new Date(stats.mtime);
        const istDate = new Date(date.getTime() + (5.5 * 60 * 60 * 1000));
        const istTime = istDate.toLocaleString('en-IN', { 
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: true,
            timeZone: 'Asia/Kolkata'
        });
        
        const fileSizeKB = (stats.size / 1024).toFixed(2);
        
        // Read backup to get user count
        const backupData = JSON.parse(fs.readFileSync(fullPath, 'utf-8'));
        let totalUsers = 0;
        for (const guild in backupData.users) {
            totalUsers += Object.keys(backupData.users[guild]).length;
        }
        
        return { 
            f, 
            istTime, 
            fileSizeKB, 
            size: stats.size,
            userCount: totalUsers,
            itemCount: backupData.customShopItems?.length || 0,
            guildCount: Object.keys(backupData.users).length
        };
    })
    .sort((a, b) => b.size - a.size);

files.forEach((item, idx) => {
    console.log(`${idx + 1}. 📁 ${item.f}`);
    console.log(`   📅 ${item.istTime} IST`);
    console.log(`   📦 ${item.fileSizeKB} KB`);
    console.log(`   👥 Users: ${item.userCount} | Servers: ${item.guildCount} | Items: ${item.itemCount}`);
    console.log('');
});

console.log('═══════════════════════════════════════════════════════════════');
console.log(`✅ Total Backups: ${files.length}`);
console.log(`📊 Total Size: ${(files.reduce((a, b) => a + b.size, 0) / 1024).toFixed(2)} KB`);
console.log('═══════════════════════════════════════════════════════════════');
NODEEOF
