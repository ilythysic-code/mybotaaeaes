# 💾 Data Backup & Recovery Guide

## Overview
Your bot creates **hourly backups** of all user data automatically. Backups persist even after publishing and closing the workflow.

---

## 📊 Viewing All Backups

### **Option 1: In Discord (Easiest)**
Server owner only:
```
?backups
```
Shows all backups with IST timestamps and file sizes.

---

### **Option 2: From Project Directory**
Run this script anytime (even after publishing):
```bash
bash show-backups.sh
```

**Output shows:**
- Backup filename
- IST Timestamp (India Standard Time)
- File size
- Number of users
- Number of servers
- Number of items

**Example:**
```
═══════════════════════════════════════════════════════════════
📊 ALL DATA BACKUPS WITH IST TIMESTAMPS & FILE DETAILS
═══════════════════════════════════════════════════════════════

1. 📁 backup_2025-11-22_19-57-33.json
   📅 23/11/2025, 06:57:33 am IST
   📦 200.41 KB
   👥 Users: 183 | Servers: 2 | Items: 0
```

---

## 🔄 Restoring Data

### **From Discord:**
Server owner only:
```
?restore backup_2025-11-22_19-57-33.json
```

**Steps:**
1. Bot shows confirmation with backup details
2. React with ✅ to confirm or ❌ to cancel
3. Auto-cancels in 30 seconds if no reaction
4. Restored data syncs to database

### **From Code:**
Manually trigger in bot logs:
```javascript
dataManager.loadBackupData('backup_2025-11-22_19-57-33.json');
```

---

## 📁 Backup Location
All backups are stored in:
```
coolbot/ChatCashierBot/data/backups/
```

**Persists:**
- ✅ After publishing the bot
- ✅ After closing the workflow
- ✅ After restarting the bot
- ✅ Survives `dist/` rebuilds

---

## ⏰ Backup Schedule

| Event | Action |
|-------|--------|
| Bot Startup | Immediate backup created |
| Every 60 minutes | New backup created |
| Auto-cleanup | Keeps last 72 backups (~3 days) |

---

## 📋 Backup File Format

**Filename:** `backup_YYYY-MM-DD_HH-MM-SS.json`

**Contains:**
```json
{
  "users": { /* all user data */ },
  "serverSettings": { /* server configs */ },
  "customShopItems": [ /* shop items */ ],
  "lootboxes": [ /* lootboxes */ ],
  "trades": [ /* trades */ ],
  "achievements": [ /* achievements */ ],
  /* ...more data... */
}
```

---

## 🛡️ Safety Features

- ✅ **Owner-only access**: Only server owner can view/restore backups
- ✅ **Confirmation required**: Must confirm before restoration
- ✅ **Auto-cancel**: Reverts to current data if no confirmation
- ✅ **Database sync**: Restored data updates PostgreSQL
- ✅ **No data loss**: All data continues being saved after restore

---

## 📍 After Publishing

When you publish the bot:
1. ✅ All existing backups persist in `data/backups/`
2. ✅ Bot continues creating hourly backups in production
3. ✅ Use `bash show-backups.sh` anytime to see all backups
4. ✅ Use `?backups` in Discord to see production backups
5. ✅ Can restore from any backup at any time

---

## 🎯 Example Workflow

**Scenario:** Bot deployed, user data accidentally lost

1. **Step 1:** Check available backups
   ```bash
   bash show-backups.sh
   ```

2. **Step 2:** Note the backup timestamp you want (in IST)

3. **Step 3:** Restore in Discord
   ```
   ?restore backup_2025-11-22_19-57-33.json
   ```

4. **Step 4:** React with ✅ to confirm

5. **Step 5:** Data restored! ✅

---

## 💡 Tips

- **Most recent backup first:** Latest backups are most valuable
- **Check regularly:** Run `bash show-backups.sh` weekly to verify backups are working
- **3 days of history:** Keep important business data decisions in mind for 72-hour retention
- **IST timezone:** All timestamps are in India Standard Time for consistency

---

## 🔍 Troubleshooting

**Q: No backups showing?**
- Bot needs to run for at least 1 hour to create a backup
- Check if `data/backups/` directory exists

**Q: Backup restoration failed?**
- Ensure you're using exact filename from `?backups`
- Database might be offline - check logs

**Q: Want to keep old backups longer?**
- Backup limit is 72 backups - modify in code if needed
- Contact developer for changes

---

Generated: November 22, 2025
